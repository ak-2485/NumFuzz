Use the following commands to run individual examples in this directory:

PATH_TO_FPTaylor/fptaylor -c config.cfg EXAMPLE.txt
