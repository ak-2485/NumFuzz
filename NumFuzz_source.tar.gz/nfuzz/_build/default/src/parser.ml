
module MenhirBasics = struct
  
  exception Error
  
  let _eRR =
    fun _s ->
      raise Error
  
  type token = 
    | WITH of (
# 160 "src/parser.mly"
       (Support.FileInfo.info)
# 15 "src/parser.ml"
  )
    | UNPACK of (
# 163 "src/parser.mly"
       (Support.FileInfo.info)
# 20 "src/parser.ml"
  )
    | UNIONCASE of (
# 135 "src/parser.mly"
       (Support.FileInfo.info)
# 25 "src/parser.ml"
  )
    | UNFOLD of (
# 140 "src/parser.mly"
       (Support.FileInfo.info)
# 30 "src/parser.ml"
  )
    | TYPEDEF of (
# 143 "src/parser.mly"
       (Support.FileInfo.info)
# 35 "src/parser.ml"
  )
    | TYPE of (
# 158 "src/parser.mly"
       (Support.FileInfo.info)
# 40 "src/parser.ml"
  )
    | TRUE of (
# 128 "src/parser.mly"
       (Support.FileInfo.info)
# 45 "src/parser.ml"
  )
    | THEN of (
# 150 "src/parser.mly"
       (Support.FileInfo.info)
# 50 "src/parser.ml"
  )
    | SUCC of (
# 176 "src/parser.mly"
       (Support.FileInfo.info)
# 55 "src/parser.ml"
  )
    | SUB of (
# 115 "src/parser.mly"
       (Support.FileInfo.info)
# 60 "src/parser.ml"
  )
    | STRINGV of (
# 185 "src/parser.mly"
       (string Support.FileInfo.withinfo)
# 65 "src/parser.ml"
  )
    | STRING of (
# 155 "src/parser.mly"
       (Support.FileInfo.info)
# 70 "src/parser.ml"
  )
    | SIZE of (
# 156 "src/parser.mly"
       (Support.FileInfo.info)
# 75 "src/parser.ml"
  )
    | SET of (
# 147 "src/parser.mly"
       (Support.FileInfo.info)
# 80 "src/parser.ml"
  )
    | SENS of (
# 157 "src/parser.mly"
       (Support.FileInfo.info)
# 85 "src/parser.ml"
  )
    | SEMI of (
# 109 "src/parser.mly"
       (Support.FileInfo.info)
# 90 "src/parser.ml"
  )
    | SAMPLE of (
# 144 "src/parser.mly"
       (Support.FileInfo.info)
# 95 "src/parser.ml"
  )
    | RPAREN of (
# 119 "src/parser.mly"
       (Support.FileInfo.info)
# 100 "src/parser.ml"
  )
    | RBRACK of (
# 123 "src/parser.mly"
       (Support.FileInfo.info)
# 105 "src/parser.ml"
  )
    | RBRACE of (
# 110 "src/parser.mly"
       (Support.FileInfo.info)
# 110 "src/parser.ml"
  )
    | QUESTION of (
# 108 "src/parser.mly"
       (Support.FileInfo.info)
# 115 "src/parser.ml"
  )
    | PROJ2 of (
# 178 "src/parser.mly"
       (Support.FileInfo.info)
# 120 "src/parser.ml"
  )
    | PROJ1 of (
# 177 "src/parser.mly"
       (Support.FileInfo.info)
# 125 "src/parser.ml"
  )
    | PRINT of (
# 152 "src/parser.mly"
       (Support.FileInfo.info)
# 130 "src/parser.ml"
  )
    | PRIMITIVE of (
# 146 "src/parser.mly"
       (Support.FileInfo.info)
# 135 "src/parser.ml"
  )
    | PRIMITER of (
# 166 "src/parser.mly"
       (Support.FileInfo.info)
# 140 "src/parser.ml"
  )
    | PIPE of (
# 124 "src/parser.mly"
       (Support.FileInfo.info)
# 145 "src/parser.ml"
  )
    | PACK of (
# 159 "src/parser.mly"
       (Support.FileInfo.info)
# 150 "src/parser.ml"
  )
    | OR of (
# 125 "src/parser.mly"
       (Support.FileInfo.info)
# 155 "src/parser.ml"
  )
    | OF of (
# 138 "src/parser.mly"
       (Support.FileInfo.info)
# 160 "src/parser.ml"
  )
    | NUMCASE of (
# 137 "src/parser.mly"
       (Support.FileInfo.info)
# 165 "src/parser.ml"
  )
    | NUM of (
# 154 "src/parser.mly"
       (Support.FileInfo.info)
# 170 "src/parser.ml"
  )
    | NAT of (
# 171 "src/parser.mly"
       (Support.FileInfo.info)
# 175 "src/parser.ml"
  )
    | MUL of (
# 116 "src/parser.mly"
       (Support.FileInfo.info)
# 180 "src/parser.ml"
  )
    | MU of (
# 141 "src/parser.mly"
       (Support.FileInfo.info)
# 185 "src/parser.ml"
  )
    | LT of (
# 120 "src/parser.mly"
       (Support.FileInfo.info)
# 190 "src/parser.ml"
  )
    | LPAREN of (
# 118 "src/parser.mly"
       (Support.FileInfo.info)
# 195 "src/parser.ml"
  )
    | LOLLIPOP of (
# 127 "src/parser.mly"
       (Support.FileInfo.info)
# 200 "src/parser.ml"
  )
    | LISTCASE of (
# 136 "src/parser.mly"
       (Support.FileInfo.info)
# 205 "src/parser.ml"
  )
    | LIST of (
# 169 "src/parser.mly"
       (Support.FileInfo.info)
# 210 "src/parser.ml"
  )
    | LET of (
# 142 "src/parser.mly"
       (Support.FileInfo.info)
# 215 "src/parser.ml"
  )
    | LBRACK of (
# 122 "src/parser.mly"
       (Support.FileInfo.info)
# 220 "src/parser.ml"
  )
    | LBRACE of (
# 107 "src/parser.mly"
       (Support.FileInfo.info)
# 225 "src/parser.ml"
  )
    | INTV of (
# 183 "src/parser.mly"
       (int    Support.FileInfo.withinfo)
# 230 "src/parser.ml"
  )
    | INT of (
# 174 "src/parser.mly"
       (Support.FileInfo.info)
# 235 "src/parser.ml"
  )
    | INR of (
# 132 "src/parser.mly"
       (Support.FileInfo.info)
# 240 "src/parser.ml"
  )
    | INL of (
# 131 "src/parser.mly"
       (Support.FileInfo.info)
# 245 "src/parser.ml"
  )
    | INF of (
# 130 "src/parser.mly"
       (Support.FileInfo.info)
# 250 "src/parser.ml"
  )
    | IN of (
# 161 "src/parser.mly"
       (Support.FileInfo.info)
# 255 "src/parser.ml"
  )
    | IF of (
# 149 "src/parser.mly"
       (Support.FileInfo.info)
# 260 "src/parser.ml"
  )
    | ID of (
# 182 "src/parser.mly"
       (string Support.FileInfo.withinfo)
# 265 "src/parser.ml"
  )
    | HAT of (
# 112 "src/parser.mly"
       (Support.FileInfo.info)
# 270 "src/parser.ml"
  )
    | GT of (
# 121 "src/parser.mly"
       (Support.FileInfo.info)
# 275 "src/parser.ml"
  )
    | FUZZY of (
# 133 "src/parser.mly"
       (Support.FileInfo.info)
# 280 "src/parser.ml"
  )
    | FUZZB of (
# 165 "src/parser.mly"
       (Support.FileInfo.info)
# 285 "src/parser.ml"
  )
    | FUZZ of (
# 164 "src/parser.mly"
       (Support.FileInfo.info)
# 290 "src/parser.ml"
  )
    | FUNCTION of (
# 145 "src/parser.mly"
       (Support.FileInfo.info)
# 295 "src/parser.ml"
  )
    | FUN of (
# 134 "src/parser.mly"
       (Support.FileInfo.info)
# 300 "src/parser.ml"
  )
    | FORALL of (
# 167 "src/parser.mly"
       (Support.FileInfo.info)
# 305 "src/parser.ml"
  )
    | FOR of (
# 162 "src/parser.mly"
       (Support.FileInfo.info)
# 310 "src/parser.ml"
  )
    | FOLD of (
# 139 "src/parser.mly"
       (Support.FileInfo.info)
# 315 "src/parser.ml"
  )
    | FLOATV of (
# 184 "src/parser.mly"
       (float  Support.FileInfo.withinfo)
# 320 "src/parser.ml"
  )
    | FALSE of (
# 129 "src/parser.mly"
       (Support.FileInfo.info)
# 325 "src/parser.ml"
  )
    | EXISTS of (
# 168 "src/parser.mly"
       (Support.FileInfo.info)
# 330 "src/parser.ml"
  )
    | EQUAL of (
# 111 "src/parser.mly"
       (Support.FileInfo.info)
# 335 "src/parser.ml"
  )
    | EOF of (
# 153 "src/parser.mly"
       (Support.FileInfo.info)
# 340 "src/parser.ml"
  )
    | ELSE of (
# 151 "src/parser.mly"
       (Support.FileInfo.info)
# 345 "src/parser.ml"
  )
    | DOT of (
# 175 "src/parser.mly"
       (Support.FileInfo.info)
# 350 "src/parser.ml"
  )
    | DOLLAR of (
# 106 "src/parser.mly"
       (Support.FileInfo.info)
# 355 "src/parser.ml"
  )
    | DIV of (
# 117 "src/parser.mly"
       (Support.FileInfo.info)
# 360 "src/parser.ml"
  )
    | DBSOURCE of (
# 173 "src/parser.mly"
       (Support.FileInfo.info)
# 365 "src/parser.ml"
  )
    | DBLCOLON of (
# 170 "src/parser.mly"
       (Support.FileInfo.info)
# 370 "src/parser.ml"
  )
    | DBLARROW of (
# 114 "src/parser.mly"
       (Support.FileInfo.info)
# 375 "src/parser.ml"
  )
    | CONS of (
# 104 "src/parser.mly"
       (Support.FileInfo.info)
# 380 "src/parser.ml"
  )
    | COMMA of (
# 105 "src/parser.mly"
       (Support.FileInfo.info)
# 385 "src/parser.ml"
  )
    | COLON of (
# 103 "src/parser.mly"
       (Support.FileInfo.info)
# 390 "src/parser.ml"
  )
    | CLIPPED of (
# 172 "src/parser.mly"
       (Support.FileInfo.info)
# 395 "src/parser.ml"
  )
    | BEQUAL of (
# 113 "src/parser.mly"
       (Support.FileInfo.info)
# 400 "src/parser.ml"
  )
    | BANG of (
# 126 "src/parser.mly"
       (Support.FileInfo.info)
# 405 "src/parser.ml"
  )
    | BAG of (
# 148 "src/parser.mly"
       (Support.FileInfo.info)
# 410 "src/parser.ml"
  )
    | AT of (
# 98 "src/parser.mly"
       (Support.FileInfo.info)
# 415 "src/parser.ml"
  )
    | ARROW of (
# 102 "src/parser.mly"
       (Support.FileInfo.info)
# 420 "src/parser.ml"
  )
    | AND of (
# 101 "src/parser.mly"
       (Support.FileInfo.info)
# 425 "src/parser.ml"
  )
    | AMP of (
# 100 "src/parser.mly"
       (Support.FileInfo.info)
# 430 "src/parser.ml"
  )
    | ADD of (
# 99 "src/parser.mly"
       (Support.FileInfo.info)
# 435 "src/parser.ml"
  )
  
end

include MenhirBasics

# 7 "src/parser.mly"
  

open Syntax

open Support.FileInfo

let parser_error   fi = Support.Error.error_msg   Support.Options.Parser fi
(* let parser_warning fi = Support.Error.message   1 Support.Options.Parser fi *)
(* let parser_info    fi = Support.Error.message   2 Support.Options.Parser fi *)

(* let si_zero  = SiConst 0.0 *)
let si_one   = SiConst 1.0
let si_infty = SiInfty
let dummy_ty  = TyPrim PrimUnit

(* look for a variable in the current context *)
let existing_var fi id ctx =
  match Ctx.lookup_var id ctx with
      None            -> parser_error fi "Identifier %s is unbound" id
    | Some (var, _bi) -> var

let existing_tyvar fi id ctx =
  match Ctx.lookup_tyvar id ctx with
      None            -> parser_error fi "Type %s is unbound" id
    | Some (var, bi)  -> (var, bi)

(* Wrap extend here in order to avoid mutually recursive
   dependencies *)
let extend_var id ctx =
  Ctx.extend_var id dummy_ty ctx

let extend_ty_var id ki ctx =
  Ctx.extend_ty_var id ki ctx

(* Create a new binder *)
(* TODO: set the proper b_size !!! *)
let nb_prim  n = {b_name = n; b_type = BiVar;   b_size = -1; b_prim = true;}
let nb_var   n = {b_name = n; b_type = BiVar;   b_size = -1; b_prim = false;}

(* From a list of arguments to a type *)
let qf_to_type qf ty = match qf with
    []               -> ty
  | _ -> ty

let rec list_to_type l ret_ty = match l with
    []                        -> TyLollipop (TyPrim PrimUnit, ret_ty) (* Not yet allowed constant function *)
  | (ty, _n, _i) :: []    -> TyLollipop (ty, ret_ty)
  | (ty,_n, _i) :: tyl   -> TyLollipop (ty, list_to_type tyl ret_ty)

let from_args_to_type qf arg_list ret_ty =
  qf_to_type qf (list_to_type arg_list ret_ty)


let mk_infix ctx info op t1 t2 =
  match Ctx.lookup_var op ctx with
      None      -> parser_error info "The primitive infix operator %s is not in scope" op
    | Some(v,_) -> TmApp(info, TmApp(info, TmVar(info, v), t1), t2)

(* This takes a *reversed* list of arguments *)
let rec mk_prim_app_args info v arglist = match arglist with
  | []        -> v
  | (o :: op) -> TmApp(info, (mk_prim_app_args info v op), o)

let mk_prim_app ctx info prim arglist =
  match Ctx.lookup_var prim ctx with
    None      -> parser_error info "Primitive %s is not in scope" prim
  | Some(v,_) -> mk_prim_app_args info (TmVar(info, v)) (List.rev arglist)

let mk_prim_app_ty_args _ v arglist = match arglist with
  | []        -> v
  | _ -> v

let mk_prim_ty_app ctx info prim arglist =
  match Ctx.lookup_var prim ctx with
    None      -> parser_error info "Primitive %s is not in scope" prim
  | Some(v,_) -> mk_prim_app_ty_args info (TmVar(info, v)) (List.rev arglist)

let mk_lambda info bi oty term = TmAbs(info, bi, oty, None, term)

(*
let rec remove_quantifiers ty = match ty with
    TyForall(_,_,ty_i) -> remove_quantifiers ty_i
  | _ -> ty
*)


# 529 "src/parser.ml"

type ('s, 'r) _menhir_state = 
  | MenhirState000 : ('s, _menhir_box_body) _menhir_state
    (** State 000.
        Stack shape : .
        Start symbol: body. *)

  | MenhirState001 : (('s, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_state
    (** State 001.
        Stack shape : UNIONCASE.
        Start symbol: body. *)

  | MenhirState003 : (('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_state
    (** State 003.
        Stack shape : LPAREN.
        Start symbol: body. *)

  | MenhirState005 : (('s, _menhir_box_body) _menhir_cell1_PROJ2, _menhir_box_body) _menhir_state
    (** State 005.
        Stack shape : PROJ2.
        Start symbol: body. *)

  | MenhirState006 : (('s, _menhir_box_body) _menhir_cell1_PROJ1, _menhir_box_body) _menhir_state
    (** State 006.
        Stack shape : PROJ1.
        Start symbol: body. *)

  | MenhirState010 : (('s, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID _menhir_cell0_FORALL _menhir_cell0_LPAREN, _menhir_box_body) _menhir_state
    (** State 010.
        Stack shape : PRIMITIVE ID FORALL LPAREN.
        Start symbol: body. *)

  | MenhirState020 : (('s, _menhir_box_body) _menhir_cell1_KindAnn _menhir_cell0_COMMA, _menhir_box_body) _menhir_state
    (** State 020.
        Stack shape : KindAnn COMMA.
        Start symbol: body. *)

  | MenhirState022 : (('s, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID _menhir_cell0_Quantifiers, _menhir_box_body) _menhir_state
    (** State 022.
        Stack shape : PRIMITIVE ID Quantifiers.
        Start symbol: body. *)

  | MenhirState026 : (('s, _menhir_box_body) _menhir_cell1_LPAREN _menhir_cell0_ID _menhir_cell0_COLON _menhir_cell0_LBRACK, _menhir_box_body) _menhir_state
    (** State 026.
        Stack shape : LPAREN ID COLON LBRACK.
        Start symbol: body. *)

  | MenhirState032 : (('s, _menhir_box_body) _menhir_cell1_SensTerm _menhir_cell0_ADD, _menhir_box_body) _menhir_state
    (** State 032.
        Stack shape : SensTerm ADD.
        Start symbol: body. *)

  | MenhirState034 : (('s, _menhir_box_body) _menhir_cell1_SensMulTerm _menhir_cell0_MUL, _menhir_box_body) _menhir_state
    (** State 034.
        Stack shape : SensMulTerm MUL.
        Start symbol: body. *)

  | MenhirState038 : (('s, _menhir_box_body) _menhir_cell1_LPAREN _menhir_cell0_ID _menhir_cell0_COLON _menhir_cell0_MaybeSensitivity, _menhir_box_body) _menhir_state
    (** State 038.
        Stack shape : LPAREN ID COLON MaybeSensitivity.
        Start symbol: body. *)

  | MenhirState041 : (('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_state
    (** State 041.
        Stack shape : LPAREN.
        Start symbol: body. *)

  | MenhirState043 : ((('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_state
    (** State 043.
        Stack shape : LPAREN PIPE.
        Start symbol: body. *)

  | MenhirState046 : (('s, _menhir_box_body) _menhir_cell1_FUZZY, _menhir_box_body) _menhir_state
    (** State 046.
        Stack shape : FUZZY.
        Start symbol: body. *)

  | MenhirState052 : (('s, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_LOLLIPOP, _menhir_box_body) _menhir_state
    (** State 052.
        Stack shape : AType LOLLIPOP.
        Start symbol: body. *)

  | MenhirState053 : ((('s, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_LOLLIPOP, _menhir_box_body) _menhir_cell1_LBRACK, _menhir_box_body) _menhir_state
    (** State 053.
        Stack shape : AType LOLLIPOP LBRACK.
        Start symbol: body. *)

  | MenhirState055 : (((('s, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_LOLLIPOP, _menhir_box_body) _menhir_cell1_LBRACK, _menhir_box_body) _menhir_cell1_SensTerm _menhir_cell0_RBRACK, _menhir_box_body) _menhir_state
    (** State 055.
        Stack shape : AType LOLLIPOP LBRACK SensTerm RBRACK.
        Start symbol: body. *)

  | MenhirState058 : (('s, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_ARROW, _menhir_box_body) _menhir_state
    (** State 058.
        Stack shape : AType ARROW.
        Start symbol: body. *)

  | MenhirState060 : (('s, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_ADD, _menhir_box_body) _menhir_state
    (** State 060.
        Stack shape : AType ADD.
        Start symbol: body. *)

  | MenhirState065 : (((('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA, _menhir_box_body) _menhir_state
    (** State 065.
        Stack shape : LPAREN PIPE Type COMMA.
        Start symbol: body. *)

  | MenhirState071 : (('s, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA, _menhir_box_body) _menhir_state
    (** State 071.
        Stack shape : Type COMMA.
        Start symbol: body. *)

  | MenhirState079 : ((('s, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID _menhir_cell0_Quantifiers, _menhir_box_body) _menhir_cell1_Arguments _menhir_cell0_COLON, _menhir_box_body) _menhir_state
    (** State 079.
        Stack shape : PRIMITIVE ID Quantifiers Arguments COLON.
        Start symbol: body. *)

  | MenhirState084 : (((('s, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID _menhir_cell0_Quantifiers, _menhir_box_body) _menhir_cell1_Arguments _menhir_cell0_COLON, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_LBRACE _menhir_cell0_PrimSpec _menhir_cell0_RBRACE, _menhir_box_body) _menhir_state
    (** State 084.
        Stack shape : PRIMITIVE ID Quantifiers Arguments COLON Type LBRACE PrimSpec RBRACE.
        Start symbol: body. *)

  | MenhirState091 : (('s, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL, _menhir_box_body) _menhir_state
    (** State 091.
        Stack shape : LET LPAREN ID COMMA ID RPAREN EQUAL.
        Start symbol: body. *)

  | MenhirState094 : (('s, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_state
    (** State 094.
        Stack shape : IF.
        Start symbol: body. *)

  | MenhirState099 : (('s, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COLON, _menhir_box_body) _menhir_state
    (** State 099.
        Stack shape : FUN LPAREN ID COLON.
        Start symbol: body. *)

  | MenhirState103 : (('s, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_ColType _menhir_cell0_RPAREN _menhir_cell0_COLON, _menhir_box_body) _menhir_state
    (** State 103.
        Stack shape : FUN LPAREN ID ColType RPAREN COLON.
        Start symbol: body. *)

  | MenhirState106 : (('s, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_ColType _menhir_cell0_RPAREN _menhir_cell0_MaybeType _menhir_cell0_LBRACE, _menhir_box_body) _menhir_state
    (** State 106.
        Stack shape : FUN LPAREN ID ColType RPAREN MaybeType LBRACE.
        Start symbol: body. *)

  | MenhirState108 : (('s, _menhir_box_body) _menhir_cell1_ID _menhir_cell0_EQUAL, _menhir_box_body) _menhir_state
    (** State 108.
        Stack shape : ID EQUAL.
        Start symbol: body. *)

  | MenhirState113 : (('s, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_LT, _menhir_box_body) _menhir_state
    (** State 113.
        Stack shape : RelTerm LT.
        Start symbol: body. *)

  | MenhirState114 : ((('s, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_LT, _menhir_box_body) _menhir_cell1_EQUAL, _menhir_box_body) _menhir_state
    (** State 114.
        Stack shape : RelTerm LT EQUAL.
        Start symbol: body. *)

  | MenhirState116 : (('s, _menhir_box_body) _menhir_cell1_MulTerm _menhir_cell0_MUL, _menhir_box_body) _menhir_state
    (** State 116.
        Stack shape : MulTerm MUL.
        Start symbol: body. *)

  | MenhirState120 : (('s, _menhir_box_body) _menhir_cell1_MulTerm _menhir_cell0_DIV, _menhir_box_body) _menhir_state
    (** State 120.
        Stack shape : MulTerm DIV.
        Start symbol: body. *)

  | MenhirState124 : (('s, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_SUB, _menhir_box_body) _menhir_state
    (** State 124.
        Stack shape : AddTerm SUB.
        Start symbol: body. *)

  | MenhirState126 : (('s, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_HAT, _menhir_box_body) _menhir_state
    (** State 126.
        Stack shape : AddTerm HAT.
        Start symbol: body. *)

  | MenhirState129 : (('s, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_DOT _menhir_cell0_SUB, _menhir_box_body) _menhir_state
    (** State 129.
        Stack shape : AddTerm DOT SUB.
        Start symbol: body. *)

  | MenhirState131 : (('s, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_DOT _menhir_cell0_ADD, _menhir_box_body) _menhir_state
    (** State 131.
        Stack shape : AddTerm DOT ADD.
        Start symbol: body. *)

  | MenhirState133 : (('s, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_ADD, _menhir_box_body) _menhir_state
    (** State 133.
        Stack shape : AddTerm ADD.
        Start symbol: body. *)

  | MenhirState136 : (('s, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_GT, _menhir_box_body) _menhir_state
    (** State 136.
        Stack shape : RelTerm GT.
        Start symbol: body. *)

  | MenhirState137 : ((('s, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_GT, _menhir_box_body) _menhir_cell1_EQUAL, _menhir_box_body) _menhir_state
    (** State 137.
        Stack shape : RelTerm GT EQUAL.
        Start symbol: body. *)

  | MenhirState141 : (('s, _menhir_box_body) _menhir_cell1_LogOrTerm _menhir_cell0_OR, _menhir_box_body) _menhir_state
    (** State 141.
        Stack shape : LogOrTerm OR.
        Start symbol: body. *)

  | MenhirState143 : (('s, _menhir_box_body) _menhir_cell1_LogAndTerm _menhir_cell0_AND, _menhir_box_body) _menhir_state
    (** State 143.
        Stack shape : LogAndTerm AND.
        Start symbol: body. *)

  | MenhirState145 : (('s, _menhir_box_body) _menhir_cell1_BequalTerm _menhir_cell0_BEQUAL, _menhir_box_body) _menhir_state
    (** State 145.
        Stack shape : BequalTerm BEQUAL.
        Start symbol: body. *)

  | MenhirState149 : (('s, _menhir_box_body) _menhir_cell1_BequalTerm _menhir_cell0_BANG _menhir_cell0_EQUAL, _menhir_box_body) _menhir_state
    (** State 149.
        Stack shape : BequalTerm BANG EQUAL.
        Start symbol: body. *)

  | MenhirState154 : ((('s, _menhir_box_body) _menhir_cell1_ID _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_SEMI, _menhir_box_body) _menhir_state
    (** State 154.
        Stack shape : ID EQUAL Expr SEMI.
        Start symbol: body. *)

  | MenhirState161 : ((('s, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_THEN _menhir_cell0_LBRACK, _menhir_box_body) _menhir_state
    (** State 161.
        Stack shape : IF Expr THEN LBRACK.
        Start symbol: body. *)

  | MenhirState164 : (((('s, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_THEN _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_RBRACK _menhir_cell0_LBRACE, _menhir_box_body) _menhir_state
    (** State 164.
        Stack shape : IF Expr THEN LBRACK Type RBRACK LBRACE.
        Start symbol: body. *)

  | MenhirState168 : ((((('s, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_THEN _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_RBRACK _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_RBRACE _menhir_cell0_ELSE _menhir_cell0_LBRACE, _menhir_box_body) _menhir_state
    (** State 168.
        Stack shape : IF Expr THEN LBRACK Type RBRACK LBRACE Term RBRACE ELSE LBRACE.
        Start symbol: body. *)

  | MenhirState172 : ((('s, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_SEMI, _menhir_box_body) _menhir_state
    (** State 172.
        Stack shape : LET LPAREN ID COMMA ID RPAREN EQUAL Expr SEMI.
        Start symbol: body. *)

  | MenhirState175 : (('s, _menhir_box_body) _menhir_cell1_Argument, _menhir_box_body) _menhir_state
    (** State 175.
        Stack shape : Argument.
        Start symbol: body. *)

  | MenhirState179 : ((('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_state
    (** State 179.
        Stack shape : LPAREN PIPE.
        Start symbol: body. *)

  | MenhirState181 : (((('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_COMMA, _menhir_box_body) _menhir_state
    (** State 181.
        Stack shape : LPAREN PIPE Term COMMA.
        Start symbol: body. *)

  | MenhirState187 : (('s, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_COMMA, _menhir_box_body) _menhir_state
    (** State 187.
        Stack shape : Term COMMA.
        Start symbol: body. *)

  | MenhirState199 : ((('s, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_state
    (** State 199.
        Stack shape : UNIONCASE Expr OF LBRACE INL LPAREN ID RPAREN DBLARROW.
        Start symbol: body. *)

  | MenhirState206 : (((('s, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_PIPE _menhir_cell0_INR _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_state
    (** State 206.
        Stack shape : UNIONCASE Expr OF LBRACE INL LPAREN ID RPAREN DBLARROW Term PIPE INR LPAREN ID RPAREN DBLARROW.
        Start symbol: body. *)


and ('s, 'r) _menhir_cell1_AType = 
  | MenhirCell1_AType of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.ty)

and ('s, 'r) _menhir_cell1_AddTerm = 
  | MenhirCell1_AddTerm of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.term)

and ('s, 'r) _menhir_cell1_Argument = 
  | MenhirCell1_Argument of 's * ('s, 'r) _menhir_state * (Ctx.context ->
  (Syntax.ty * string * Support.FileInfo.info) list * Ctx.context)

and ('s, 'r) _menhir_cell1_Arguments = 
  | MenhirCell1_Arguments of 's * ('s, 'r) _menhir_state * (Ctx.context ->
  (Syntax.ty * string * Support.FileInfo.info) list * Ctx.context)

and ('s, 'r) _menhir_cell1_BequalTerm = 
  | MenhirCell1_BequalTerm of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.term)

and 's _menhir_cell0_ColType = 
  | MenhirCell0_ColType of 's * (Ctx.context -> Syntax.ty)

and ('s, 'r) _menhir_cell1_Expr = 
  | MenhirCell1_Expr of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.term)

and ('s, 'r) _menhir_cell1_KindAnn = 
  | MenhirCell1_KindAnn of 's * ('s, 'r) _menhir_state * (Ctx.context ->
  (Support.FileInfo.info * string * Syntax.kind) list * Ctx.context)

and ('s, 'r) _menhir_cell1_LogAndTerm = 
  | MenhirCell1_LogAndTerm of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.term)

and ('s, 'r) _menhir_cell1_LogOrTerm = 
  | MenhirCell1_LogOrTerm of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.term)

and 's _menhir_cell0_MaybeSensitivity = 
  | MenhirCell0_MaybeSensitivity of 's * (Ctx.context -> Syntax.si)

and 's _menhir_cell0_MaybeType = 
  | MenhirCell0_MaybeType of 's * (Ctx.context -> Syntax.ty option)

and ('s, 'r) _menhir_cell1_MulTerm = 
  | MenhirCell1_MulTerm of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.term)

and 's _menhir_cell0_PrimSpec = 
  | MenhirCell0_PrimSpec of 's * (string Support.FileInfo.withinfo)

and 's _menhir_cell0_Quantifiers = 
  | MenhirCell0_Quantifiers of 's * (Ctx.context ->
  (Support.FileInfo.info * string * Syntax.kind) list * Ctx.context)

and ('s, 'r) _menhir_cell1_RelTerm = 
  | MenhirCell1_RelTerm of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.term)

and ('s, 'r) _menhir_cell1_SensMulTerm = 
  | MenhirCell1_SensMulTerm of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.si)

and ('s, 'r) _menhir_cell1_SensTerm = 
  | MenhirCell1_SensTerm of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.si)

and ('s, 'r) _menhir_cell1_Term = 
  | MenhirCell1_Term of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.term)

and ('s, 'r) _menhir_cell1_Type = 
  | MenhirCell1_Type of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.ty)

and 's _menhir_cell0_ADD = 
  | MenhirCell0_ADD of 's * (
# 99 "src/parser.mly"
       (Support.FileInfo.info)
# 881 "src/parser.ml"
)

and 's _menhir_cell0_AND = 
  | MenhirCell0_AND of 's * (
# 101 "src/parser.mly"
       (Support.FileInfo.info)
# 888 "src/parser.ml"
)

and 's _menhir_cell0_ARROW = 
  | MenhirCell0_ARROW of 's * (
# 102 "src/parser.mly"
       (Support.FileInfo.info)
# 895 "src/parser.ml"
)

and 's _menhir_cell0_BANG = 
  | MenhirCell0_BANG of 's * (
# 126 "src/parser.mly"
       (Support.FileInfo.info)
# 902 "src/parser.ml"
)

and 's _menhir_cell0_BEQUAL = 
  | MenhirCell0_BEQUAL of 's * (
# 113 "src/parser.mly"
       (Support.FileInfo.info)
# 909 "src/parser.ml"
)

and 's _menhir_cell0_COLON = 
  | MenhirCell0_COLON of 's * (
# 103 "src/parser.mly"
       (Support.FileInfo.info)
# 916 "src/parser.ml"
)

and 's _menhir_cell0_COMMA = 
  | MenhirCell0_COMMA of 's * (
# 105 "src/parser.mly"
       (Support.FileInfo.info)
# 923 "src/parser.ml"
)

and 's _menhir_cell0_DBLARROW = 
  | MenhirCell0_DBLARROW of 's * (
# 114 "src/parser.mly"
       (Support.FileInfo.info)
# 930 "src/parser.ml"
)

and 's _menhir_cell0_DIV = 
  | MenhirCell0_DIV of 's * (
# 117 "src/parser.mly"
       (Support.FileInfo.info)
# 937 "src/parser.ml"
)

and 's _menhir_cell0_DOT = 
  | MenhirCell0_DOT of 's * (
# 175 "src/parser.mly"
       (Support.FileInfo.info)
# 944 "src/parser.ml"
)

and 's _menhir_cell0_ELSE = 
  | MenhirCell0_ELSE of 's * (
# 151 "src/parser.mly"
       (Support.FileInfo.info)
# 951 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_EQUAL = 
  | MenhirCell1_EQUAL of 's * ('s, 'r) _menhir_state * (
# 111 "src/parser.mly"
       (Support.FileInfo.info)
# 958 "src/parser.ml"
)

and 's _menhir_cell0_EQUAL = 
  | MenhirCell0_EQUAL of 's * (
# 111 "src/parser.mly"
       (Support.FileInfo.info)
# 965 "src/parser.ml"
)

and 's _menhir_cell0_FORALL = 
  | MenhirCell0_FORALL of 's * (
# 167 "src/parser.mly"
       (Support.FileInfo.info)
# 972 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_FUN = 
  | MenhirCell1_FUN of 's * ('s, 'r) _menhir_state * (
# 134 "src/parser.mly"
       (Support.FileInfo.info)
# 979 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_FUZZY = 
  | MenhirCell1_FUZZY of 's * ('s, 'r) _menhir_state * (
# 133 "src/parser.mly"
       (Support.FileInfo.info)
# 986 "src/parser.ml"
)

and 's _menhir_cell0_GT = 
  | MenhirCell0_GT of 's * (
# 121 "src/parser.mly"
       (Support.FileInfo.info)
# 993 "src/parser.ml"
)

and 's _menhir_cell0_HAT = 
  | MenhirCell0_HAT of 's * (
# 112 "src/parser.mly"
       (Support.FileInfo.info)
# 1000 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_ID = 
  | MenhirCell1_ID of 's * ('s, 'r) _menhir_state * (
# 182 "src/parser.mly"
       (string Support.FileInfo.withinfo)
# 1007 "src/parser.ml"
)

and 's _menhir_cell0_ID = 
  | MenhirCell0_ID of 's * (
# 182 "src/parser.mly"
       (string Support.FileInfo.withinfo)
# 1014 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_IF = 
  | MenhirCell1_IF of 's * ('s, 'r) _menhir_state * (
# 149 "src/parser.mly"
       (Support.FileInfo.info)
# 1021 "src/parser.ml"
)

and 's _menhir_cell0_INL = 
  | MenhirCell0_INL of 's * (
# 131 "src/parser.mly"
       (Support.FileInfo.info)
# 1028 "src/parser.ml"
)

and 's _menhir_cell0_INR = 
  | MenhirCell0_INR of 's * (
# 132 "src/parser.mly"
       (Support.FileInfo.info)
# 1035 "src/parser.ml"
)

and 's _menhir_cell0_LBRACE = 
  | MenhirCell0_LBRACE of 's * (
# 107 "src/parser.mly"
       (Support.FileInfo.info)
# 1042 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_LBRACK = 
  | MenhirCell1_LBRACK of 's * ('s, 'r) _menhir_state * (
# 122 "src/parser.mly"
       (Support.FileInfo.info)
# 1049 "src/parser.ml"
)

and 's _menhir_cell0_LBRACK = 
  | MenhirCell0_LBRACK of 's * (
# 122 "src/parser.mly"
       (Support.FileInfo.info)
# 1056 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_LET = 
  | MenhirCell1_LET of 's * ('s, 'r) _menhir_state * (
# 142 "src/parser.mly"
       (Support.FileInfo.info)
# 1063 "src/parser.ml"
)

and 's _menhir_cell0_LOLLIPOP = 
  | MenhirCell0_LOLLIPOP of 's * (
# 127 "src/parser.mly"
       (Support.FileInfo.info)
# 1070 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_LPAREN = 
  | MenhirCell1_LPAREN of 's * ('s, 'r) _menhir_state * (
# 118 "src/parser.mly"
       (Support.FileInfo.info)
# 1077 "src/parser.ml"
)

and 's _menhir_cell0_LPAREN = 
  | MenhirCell0_LPAREN of 's * (
# 118 "src/parser.mly"
       (Support.FileInfo.info)
# 1084 "src/parser.ml"
)

and 's _menhir_cell0_LT = 
  | MenhirCell0_LT of 's * (
# 120 "src/parser.mly"
       (Support.FileInfo.info)
# 1091 "src/parser.ml"
)

and 's _menhir_cell0_MUL = 
  | MenhirCell0_MUL of 's * (
# 116 "src/parser.mly"
       (Support.FileInfo.info)
# 1098 "src/parser.ml"
)

and 's _menhir_cell0_OF = 
  | MenhirCell0_OF of 's * (
# 138 "src/parser.mly"
       (Support.FileInfo.info)
# 1105 "src/parser.ml"
)

and 's _menhir_cell0_OR = 
  | MenhirCell0_OR of 's * (
# 125 "src/parser.mly"
       (Support.FileInfo.info)
# 1112 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_PIPE = 
  | MenhirCell1_PIPE of 's * ('s, 'r) _menhir_state * (
# 124 "src/parser.mly"
       (Support.FileInfo.info)
# 1119 "src/parser.ml"
)

and 's _menhir_cell0_PIPE = 
  | MenhirCell0_PIPE of 's * (
# 124 "src/parser.mly"
       (Support.FileInfo.info)
# 1126 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_PRIMITIVE = 
  | MenhirCell1_PRIMITIVE of 's * ('s, 'r) _menhir_state * (
# 146 "src/parser.mly"
       (Support.FileInfo.info)
# 1133 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_PROJ1 = 
  | MenhirCell1_PROJ1 of 's * ('s, 'r) _menhir_state * (
# 177 "src/parser.mly"
       (Support.FileInfo.info)
# 1140 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_PROJ2 = 
  | MenhirCell1_PROJ2 of 's * ('s, 'r) _menhir_state * (
# 178 "src/parser.mly"
       (Support.FileInfo.info)
# 1147 "src/parser.ml"
)

and 's _menhir_cell0_RBRACE = 
  | MenhirCell0_RBRACE of 's * (
# 110 "src/parser.mly"
       (Support.FileInfo.info)
# 1154 "src/parser.ml"
)

and 's _menhir_cell0_RBRACK = 
  | MenhirCell0_RBRACK of 's * (
# 123 "src/parser.mly"
       (Support.FileInfo.info)
# 1161 "src/parser.ml"
)

and 's _menhir_cell0_RPAREN = 
  | MenhirCell0_RPAREN of 's * (
# 119 "src/parser.mly"
       (Support.FileInfo.info)
# 1168 "src/parser.ml"
)

and 's _menhir_cell0_SEMI = 
  | MenhirCell0_SEMI of 's * (
# 109 "src/parser.mly"
       (Support.FileInfo.info)
# 1175 "src/parser.ml"
)

and 's _menhir_cell0_SUB = 
  | MenhirCell0_SUB of 's * (
# 115 "src/parser.mly"
       (Support.FileInfo.info)
# 1182 "src/parser.ml"
)

and 's _menhir_cell0_THEN = 
  | MenhirCell0_THEN of 's * (
# 150 "src/parser.mly"
       (Support.FileInfo.info)
# 1189 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_UNIONCASE = 
  | MenhirCell1_UNIONCASE of 's * ('s, 'r) _menhir_state * (
# 135 "src/parser.mly"
       (Support.FileInfo.info)
# 1196 "src/parser.ml"
)

and _menhir_box_body = 
  | MenhirBox_body of (Syntax.term) [@@unboxed]

let _menhir_action_01 =
  fun _1 ->
    (
# 364 "src/parser.mly"
      ( fun _cx -> TmPrim (_1, PrimTUnit) )
# 1207 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_02 =
  fun _1 ->
    (
# 366 "src/parser.mly"
      ( fun ctx -> TmVar(_1.i, existing_var _1.i _1.v ctx) )
# 1215 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_03 =
  fun _1 ->
    (
# 368 "src/parser.mly"
      ( fun ctx -> mk_prim_app ctx _1 "p_inl" []  )
# 1223 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_04 =
  fun _1 ->
    (
# 370 "src/parser.mly"
      ( fun ctx -> mk_prim_app ctx _1 "p_inr" []  )
# 1231 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_05 =
  fun _2 ->
    (
# 372 "src/parser.mly"
      ( _2 )
# 1239 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_06 =
  fun _2 ->
    (
# 374 "src/parser.mly"
      ( fun ctx -> _2 ctx )
# 1247 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_07 =
  fun _1 _3 _5 ->
    (
# 376 "src/parser.mly"
      ( fun ctx -> TmAmpersand(_1, _3 ctx, _5 ctx) )
# 1255 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_08 =
  fun _1 ->
    (
# 378 "src/parser.mly"
      ( fun _cx -> TmPrim(_1.i, PrimTString _1.v) )
# 1263 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_09 =
  fun _1 ->
    (
# 380 "src/parser.mly"
      ( fun _cx -> TmPrim(_1.i, PrimTNum _1.v) )
# 1271 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_10 =
  fun _2 ->
    (
# 495 "src/parser.mly"
      ( _2 )
# 1279 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_11 =
  fun _1 ->
    (
# 497 "src/parser.mly"
      (	fun ctx -> let (v, _) = existing_tyvar _1.i _1.v ctx in
                   TyVar v
      )
# 1289 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_12 =
  fun () ->
    (
# 501 "src/parser.mly"
      ( fun _cx -> TyPrim PrimNum )
# 1297 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_13 =
  fun () ->
    (
# 503 "src/parser.mly"
      ( fun _cx -> TyPrim PrimInt )
# 1305 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_14 =
  fun () ->
    (
# 505 "src/parser.mly"
      ( fun _cx -> TyPrim PrimString )
# 1313 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_15 =
  fun () ->
    (
# 507 "src/parser.mly"
      ( fun _cx -> TyPrim PrimNum )
# 1321 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_16 =
  fun () ->
    (
# 509 "src/parser.mly"
      ( fun _cx -> TyPrim PrimNum )
# 1329 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_17 =
  fun () ->
    (
# 511 "src/parser.mly"
      ( fun _cx -> TyPrim PrimUnit )
# 1337 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_18 =
  fun _2 ->
    (
# 513 "src/parser.mly"
      ( fun ctx -> _2 ctx )
# 1345 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_19 =
  fun _3 _5 ->
    (
# 515 "src/parser.mly"
      ( fun ctx -> TyAmpersand(_3 ctx, _5 ctx) )
# 1353 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_20 =
  fun _1 _2 _3 ->
    (
# 298 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_add" (_1 ctx) (_3 ctx) )
# 1361 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_21 =
  fun _1 _2 _4 ->
    (
# 300 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_iadd" (_1 ctx) (_4 ctx) )
# 1369 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_22 =
  fun _1 _2 _3 ->
    (
# 302 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "string_concat" (_1 ctx) (_3 ctx) )
# 1377 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_23 =
  fun _1 _2 _3 ->
    (
# 304 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_sub" (_1 ctx) (_3 ctx) )
# 1385 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_24 =
  fun _1 _2 _4 ->
    (
# 306 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_isub" (_1 ctx) (_4 ctx) )
# 1393 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_25 =
  fun _1 ->
    (
# 308 "src/parser.mly"
      ( _1 )
# 1401 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_26 =
  fun _2 _5 ->
    (
# 244 "src/parser.mly"
      ( fun ctx -> ([(_5 ctx, _2.v, _2.i)], extend_var _2.v ctx) )
# 1409 "src/parser.ml"
     : (Ctx.context ->
  (Syntax.ty * string * Support.FileInfo.info) list * Ctx.context))

let _menhir_action_27 =
  fun _1 ->
    (
# 252 "src/parser.mly"
      ( _1 )
# 1418 "src/parser.ml"
     : (Ctx.context ->
  (Syntax.ty * string * Support.FileInfo.info) list * Ctx.context))

let _menhir_action_28 =
  fun _1 _2 ->
    (
# 254 "src/parser.mly"
      ( fun ctx ->
          let (l,  ctx')  = _1 ctx in
          let (l2, ctx'') = _2 ctx' in
          (l @ l2, ctx'')
      )
# 1431 "src/parser.ml"
     : (Ctx.context ->
  (Syntax.ty * string * Support.FileInfo.info) list * Ctx.context))

let _menhir_action_29 =
  fun _1 _2 _3 ->
    (
# 278 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_eq" (_1 ctx) (_3 ctx) )
# 1440 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_30 =
  fun _1 _2 _4 ->
    (
# 280 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_neq" (_1 ctx) (_4 ctx) )
# 1448 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_31 =
  fun _1 ->
    (
# 282 "src/parser.mly"
      ( _1 )
# 1456 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_32 =
  fun _2 ->
    (
# 418 "src/parser.mly"
      ( fun ctx -> (_2 ctx) )
# 1464 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_33 =
  fun _1 _3 ->
    (
# 475 "src/parser.mly"
      ( fun ctx -> TyLollipop(_1 ctx, _3 ctx) )
# 1472 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_34 =
  fun _1 _3 ->
    (
# 477 "src/parser.mly"
      ( fun ctx -> TyUnion(_1 ctx, _3 ctx) )
# 1480 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_35 =
  fun _1 _3 ->
    (
# 479 "src/parser.mly"
      ( fun ctx -> TyLollipop(_1 ctx, _3 ctx) )
# 1488 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_36 =
  fun _1 _6 ->
    (
# 481 "src/parser.mly"
      ( fun ctx -> TyLollipop(_1 ctx, _6 ctx) )
# 1496 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_37 =
  fun _2 ->
    (
# 483 "src/parser.mly"
      ( fun ctx -> (_2 ctx) )
# 1504 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_38 =
  fun _1 ->
    (
# 485 "src/parser.mly"
      ( _1 )
# 1512 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_39 =
  fun _1 ->
    (
# 262 "src/parser.mly"
      ( _1 )
# 1520 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_40 =
  fun _1 ->
    (
# 348 "src/parser.mly"
      ( _1 )
# 1528 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_41 =
  fun _1 ->
    (
# 320 "src/parser.mly"
      ( _1 )
# 1536 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_42 =
  fun () ->
    (
# 435 "src/parser.mly"
      ( Size )
# 1544 "src/parser.ml"
     : (Syntax.kind))

let _menhir_action_43 =
  fun () ->
    (
# 437 "src/parser.mly"
      ( Star )
# 1552 "src/parser.ml"
     : (Syntax.kind))

let _menhir_action_44 =
  fun () ->
    (
# 439 "src/parser.mly"
      ( Sens )
# 1560 "src/parser.ml"
     : (Syntax.kind))

let _menhir_action_45 =
  fun _1 ->
    (
# 443 "src/parser.mly"
      ( fun ctx -> ([(_1.i, _1.v, Star)], extend_ty_var _1.v Star ctx) )
# 1568 "src/parser.ml"
     : (Ctx.context ->
  (Support.FileInfo.info * string * Syntax.kind) list * Ctx.context))

let _menhir_action_46 =
  fun _1 _3 ->
    (
# 445 "src/parser.mly"
      ( fun ctx -> ([(_1.i, _1.v, _3)],   extend_ty_var _1.v _3 ctx) )
# 1577 "src/parser.ml"
     : (Ctx.context ->
  (Support.FileInfo.info * string * Syntax.kind) list * Ctx.context))

let _menhir_action_47 =
  fun _1 _2 _3 ->
    (
# 272 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_land" (_1 ctx) (_3 ctx) )
# 1586 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_48 =
  fun _1 ->
    (
# 274 "src/parser.mly"
      ( _1 )
# 1594 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_49 =
  fun _1 _2 _3 ->
    (
# 266 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_lor" (_1 ctx) (_3 ctx) )
# 1602 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_50 =
  fun _1 ->
    (
# 268 "src/parser.mly"
      ( _1 )
# 1610 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_51 =
  fun () ->
    (
# 426 "src/parser.mly"
      ( fun _cx -> si_infty )
# 1618 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_52 =
  fun () ->
    (
# 428 "src/parser.mly"
      ( fun _cx -> si_one )
# 1626 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_53 =
  fun _2 ->
    (
# 430 "src/parser.mly"
      ( _2 )
# 1634 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_54 =
  fun () ->
    (
# 463 "src/parser.mly"
    (fun _ctx -> None)
# 1642 "src/parser.ml"
     : (Ctx.context -> Syntax.ty option))

let _menhir_action_55 =
  fun _2 ->
    (
# 465 "src/parser.mly"
      (fun ctx -> Some (_2 ctx))
# 1650 "src/parser.ml"
     : (Ctx.context -> Syntax.ty option))

let _menhir_action_56 =
  fun _1 _2 _3 ->
    (
# 312 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_mul" (_1 ctx) (_3 ctx) )
# 1658 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_57 =
  fun _1 _2 _3 ->
    (
# 314 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_div" (_1 ctx) (_3 ctx) )
# 1666 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_58 =
  fun _1 ->
    (
# 316 "src/parser.mly"
      ( _1 )
# 1674 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_59 =
  fun _1 _2 _3 ->
    (
# 358 "src/parser.mly"
      ( fun ctx -> TmTens(_2, _1 ctx, _3 ctx)  )
# 1682 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_60 =
  fun _1 _2 _3 ->
    (
# 360 "src/parser.mly"
      ( fun ctx -> TmTens(_2, _1 ctx, _3 ctx)  )
# 1690 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_61 =
  fun _1 ->
    (
# 205 "src/parser.mly"
      ( _1 )
# 1698 "src/parser.ml"
     : (string Support.FileInfo.withinfo))

let _menhir_action_62 =
  fun _1 ->
    (
# 449 "src/parser.mly"
      ( _1 )
# 1706 "src/parser.ml"
     : (Ctx.context ->
  (Support.FileInfo.info * string * Syntax.kind) list * Ctx.context))

let _menhir_action_63 =
  fun _1 _3 ->
    (
# 451 "src/parser.mly"
      ( fun ctx -> let (tyv, ctx')  = _1 ctx  in
                   let (qf, ctx_qf) = _3 ctx' in
                   (tyv @ qf, ctx_qf)
      )
# 1718 "src/parser.ml"
     : (Ctx.context ->
  (Support.FileInfo.info * string * Syntax.kind) list * Ctx.context))

let _menhir_action_64 =
  fun () ->
    (
# 458 "src/parser.mly"
    ( fun ctx -> ([], ctx) )
# 1727 "src/parser.ml"
     : (Ctx.context ->
  (Support.FileInfo.info * string * Syntax.kind) list * Ctx.context))

let _menhir_action_65 =
  fun _3 ->
    (
# 460 "src/parser.mly"
    ( _3 )
# 1736 "src/parser.ml"
     : (Ctx.context ->
  (Support.FileInfo.info * string * Syntax.kind) list * Ctx.context))

let _menhir_action_66 =
  fun _1 _2 _3 ->
    (
# 286 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_lt" (_1 ctx) (_3 ctx) )
# 1745 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_67 =
  fun _1 _2 _3 ->
    (
# 288 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_gt" (_1 ctx) (_3 ctx) )
# 1753 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_68 =
  fun _1 _2 _4 ->
    (
# 290 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_lte" (_1 ctx) (_4 ctx) )
# 1761 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_69 =
  fun _1 _2 _4 ->
    (
# 292 "src/parser.mly"
      ( fun ctx -> mk_infix ctx _2 "op_gte" (_1 ctx) (_4 ctx) )
# 1769 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_70 =
  fun _1 ->
    (
# 294 "src/parser.mly"
      ( _1 )
# 1777 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_71 =
  fun _1 _11 _12 _2 _5 _6 _7 _8 ->
    (
# 324 "src/parser.mly"
      ( fun ctx ->
        let if_then_spec = mk_prim_ty_app ctx _1 "if_then_else" [_5 ctx] in
        let arg_list    = [_2 ctx;
                           TmAmpersand(_6,
                                       mk_lambda _7  (nb_var "thunk") (TyPrim PrimUnit) (_8  (extend_var "_" ctx)),
                                       mk_lambda _11 (nb_var "thunk") (TyPrim PrimUnit) (_12 (extend_var "_" ctx)));] in
        mk_prim_app_args _1 if_then_spec (List.rev arg_list)
      )
# 1792 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_72 =
  fun _1 _10 _14 _17 _2 _7 ->
    (
# 335 "src/parser.mly"
      ( fun ctx ->
        let ctx_l = extend_var _7.v  ctx in
        let ctx_r = extend_var _14.v ctx in
        TmUnionCase(_1, _2 ctx, nb_var _7.v, _10 ctx_l, nb_var  _14.v, _17 ctx_r) )
# 1803 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_73 =
  fun _1 _3 _4 _6 _8 ->
    (
# 342 "src/parser.mly"
      ( fun ctx -> TmAbs(_1, nb_var _3.v, _4 ctx, _6 ctx, _8 (extend_var _3.v ctx )) )
# 1811 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_74 =
  fun _1 ->
    (
# 344 "src/parser.mly"
      ( _1 )
# 1819 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_75 =
  fun _1 ->
    (
# 407 "src/parser.mly"
      ( fun ctx -> let (v, k) = existing_tyvar _1.i _1.v ctx in
                   match k with
                   | Star -> parser_error _1.i "Cannot bind a type variable in sensitivity"
                   | _    -> SiVar v
      )
# 1831 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_76 =
  fun _1 ->
    (
# 414 "src/parser.mly"
      ( fun _cx -> SiConst _1.v )
# 1839 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_77 =
  fun _1 _3 ->
    (
# 392 "src/parser.mly"
      ( fun ctx -> SiMult(_1 ctx, _3 ctx) )
# 1847 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_78 =
  fun _1 ->
    (
# 394 "src/parser.mly"
      ( _1 )
# 1855 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_79 =
  fun _1 _3 ->
    (
# 386 "src/parser.mly"
      ( fun ctx -> SiAdd(_1 ctx, _3 ctx) )
# 1863 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_80 =
  fun _1 ->
    (
# 388 "src/parser.mly"
      ( _1 )
# 1871 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_81 =
  fun _1 ->
    (
# 353 "src/parser.mly"
      ( _1 )
# 1879 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_82 =
  fun _1 _3 ->
    (
# 489 "src/parser.mly"
      ( fun ctx -> TyTensor(_1 ctx, _3 ctx) )
# 1887 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_83 =
  fun _1 _3 ->
    (
# 491 "src/parser.mly"
      ( fun ctx -> TyTensor(_1 ctx, _3 ctx) )
# 1895 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_84 =
  fun _1 _3 _5 ->
    (
# 209 "src/parser.mly"
      (
        fun ctx ->
          let ctx' = extend_var _1.v ctx in
          TmLet(_1.i, (nb_var _1.v), _3 ctx, _5 ctx')
      )
# 1907 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_85 =
  fun _1 _10 _3 _5 _8 ->
    (
# 216 "src/parser.mly"
      ( fun ctx ->
        (* TODO, what happens with let (x,x) = ...? *)
        let ctx_x  = extend_var _3.v ctx   in
        let ctx_xy = extend_var _5.v ctx_x in
        TmTensDest(_1, (nb_var _3.v), (nb_var _5.v), _8 ctx, _10 ctx_xy)
      )
# 1920 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_86 =
  fun _1 _2 ->
    (
# 223 "src/parser.mly"
      ( fun ctx -> TmAmp1(_1, _2 ctx))
# 1928 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_87 =
  fun _1 _2 ->
    (
# 225 "src/parser.mly"
      ( fun ctx -> TmAmp1(_1, _2 ctx))
# 1936 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_88 =
  fun _1 _10 _2 _3 _4 _6 _8 ->
    (
# 230 "src/parser.mly"
      ( fun ctx ->
        let (qf,   ctx_qf)   = _3 ctx                                              in
        let (args, ctx_args) = _4 ctx_qf                                           in
        let f_type           = from_args_to_type qf args (_6 ctx_args)             in
        let ctx_f_outer      = extend_var _2.v ctx                                 in
        let tm_prim          = TmPrim(_8.i, PrimTFun(_8.v, f_type))                in
        TmLet(_1, (nb_prim _2.v), tm_prim, _10 ctx_f_outer)
      )
# 1951 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_89 =
  fun _1 ->
    (
# 240 "src/parser.mly"
      ( _1 )
# 1959 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_90 =
  fun _1 ->
    (
# 469 "src/parser.mly"
      ( fun ctx -> (_1 ctx) )
# 1967 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_91 =
  fun _1 ->
    (
# 471 "src/parser.mly"
      ( _1 )
# 1975 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_92 =
  fun _1 ->
    (
# 201 "src/parser.mly"
      ( _1 Ctx.empty_context )
# 1983 "src/parser.ml"
     : (Syntax.term))

let _menhir_print_token : token -> string =
  fun _tok ->
    match _tok with
    | ADD _ ->
        "ADD"
    | AMP _ ->
        "AMP"
    | AND _ ->
        "AND"
    | ARROW _ ->
        "ARROW"
    | AT _ ->
        "AT"
    | BAG _ ->
        "BAG"
    | BANG _ ->
        "BANG"
    | BEQUAL _ ->
        "BEQUAL"
    | CLIPPED _ ->
        "CLIPPED"
    | COLON _ ->
        "COLON"
    | COMMA _ ->
        "COMMA"
    | CONS _ ->
        "CONS"
    | DBLARROW _ ->
        "DBLARROW"
    | DBLCOLON _ ->
        "DBLCOLON"
    | DBSOURCE _ ->
        "DBSOURCE"
    | DIV _ ->
        "DIV"
    | DOLLAR _ ->
        "DOLLAR"
    | DOT _ ->
        "DOT"
    | ELSE _ ->
        "ELSE"
    | EOF _ ->
        "EOF"
    | EQUAL _ ->
        "EQUAL"
    | EXISTS _ ->
        "EXISTS"
    | FALSE _ ->
        "FALSE"
    | FLOATV _ ->
        "FLOATV"
    | FOLD _ ->
        "FOLD"
    | FOR _ ->
        "FOR"
    | FORALL _ ->
        "FORALL"
    | FUN _ ->
        "FUN"
    | FUNCTION _ ->
        "FUNCTION"
    | FUZZ _ ->
        "FUZZ"
    | FUZZB _ ->
        "FUZZB"
    | FUZZY _ ->
        "FUZZY"
    | GT _ ->
        "GT"
    | HAT _ ->
        "HAT"
    | ID _ ->
        "ID"
    | IF _ ->
        "IF"
    | IN _ ->
        "IN"
    | INF _ ->
        "INF"
    | INL _ ->
        "INL"
    | INR _ ->
        "INR"
    | INT _ ->
        "INT"
    | INTV _ ->
        "INTV"
    | LBRACE _ ->
        "LBRACE"
    | LBRACK _ ->
        "LBRACK"
    | LET _ ->
        "LET"
    | LIST _ ->
        "LIST"
    | LISTCASE _ ->
        "LISTCASE"
    | LOLLIPOP _ ->
        "LOLLIPOP"
    | LPAREN _ ->
        "LPAREN"
    | LT _ ->
        "LT"
    | MU _ ->
        "MU"
    | MUL _ ->
        "MUL"
    | NAT _ ->
        "NAT"
    | NUM _ ->
        "NUM"
    | NUMCASE _ ->
        "NUMCASE"
    | OF _ ->
        "OF"
    | OR _ ->
        "OR"
    | PACK _ ->
        "PACK"
    | PIPE _ ->
        "PIPE"
    | PRIMITER _ ->
        "PRIMITER"
    | PRIMITIVE _ ->
        "PRIMITIVE"
    | PRINT _ ->
        "PRINT"
    | PROJ1 _ ->
        "PROJ1"
    | PROJ2 _ ->
        "PROJ2"
    | QUESTION _ ->
        "QUESTION"
    | RBRACE _ ->
        "RBRACE"
    | RBRACK _ ->
        "RBRACK"
    | RPAREN _ ->
        "RPAREN"
    | SAMPLE _ ->
        "SAMPLE"
    | SEMI _ ->
        "SEMI"
    | SENS _ ->
        "SENS"
    | SET _ ->
        "SET"
    | SIZE _ ->
        "SIZE"
    | STRING _ ->
        "STRING"
    | STRINGV _ ->
        "STRINGV"
    | SUB _ ->
        "SUB"
    | SUCC _ ->
        "SUCC"
    | THEN _ ->
        "THEN"
    | TRUE _ ->
        "TRUE"
    | TYPE _ ->
        "TYPE"
    | TYPEDEF _ ->
        "TYPEDEF"
    | UNFOLD _ ->
        "UNFOLD"
    | UNIONCASE _ ->
        "UNIONCASE"
    | UNPACK _ ->
        "UNPACK"
    | WITH _ ->
        "WITH"

let _menhir_fail : unit -> 'a =
  fun () ->
    Printf.eprintf "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

include struct
  
  [@@@ocaml.warning "-4-37-39"]
  
  let rec _menhir_run_210 : type  ttv_stack. ttv_stack -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _v _tok ->
      match (_tok : MenhirBasics.token) with
      | EOF _ ->
          let _1 = _v in
          let _v = _menhir_action_92 _1 in
          MenhirBox_body _v
      | _ ->
          _eRR ()
  
  let rec _menhir_run_001 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_UNIONCASE (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState001
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState001
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState001
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState001
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_001 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_122_spec_001 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState001 _tok
  
  and _menhir_run_115 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | MUL _v_0 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | DIV _v_1 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_120 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | ADD _ | AND _ | BANG _ | BEQUAL _ | COMMA _ | DOT _ | EOF _ | GT _ | HAT _ | LT _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | SUB _ | THEN _ ->
          let _1 = _v in
          let _v = _menhir_action_25 _1 in
          _menhir_goto_AddTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_116 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_MulTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_MUL (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState116
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState116
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState116
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState116
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_116 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_MulTerm _menhir_cell0_MUL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_117 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_117 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_MulTerm _menhir_cell0_MUL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_MUL (_menhir_stack, _2) = _menhir_stack in
      let MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_56 _1 _2 _3 in
      _menhir_goto_MulTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_MulTerm : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState133 ->
          _menhir_run_134 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState131 ->
          _menhir_run_132 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState129 ->
          _menhir_run_130 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState126 ->
          _menhir_run_127 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState124 ->
          _menhir_run_125 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState000 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState199 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState206 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState001 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState003 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState187 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState179 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState181 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState005 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState006 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState084 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState172 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState091 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState164 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState168 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState094 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState106 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState154 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState149 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState145 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState143 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState141 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState108 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState136 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState137 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState113 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState114 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_134 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_ADD as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | MUL _v_0 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | DIV _v_1 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_120 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | ADD _ | AND _ | BANG _ | BEQUAL _ | COMMA _ | DOT _ | EOF _ | GT _ | HAT _ | LT _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | SUB _ | THEN _ ->
          let MenhirCell0_ADD (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_20 _1 _2 _3 in
          _menhir_goto_AddTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_120 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_MulTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_DIV (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState120
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_120 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState120
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_120 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_120 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState120
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_120 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState120
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_120 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_120 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_MulTerm _menhir_cell0_DIV -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_121 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_121 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_MulTerm _menhir_cell0_DIV -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_DIV (_menhir_stack, _2) = _menhir_stack in
      let MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_57 _1 _2 _3 in
      _menhir_goto_MulTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_003 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState003
      | STRINGV _v_1 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v in
          let _v = _menhir_action_01 _1 in
          _menhir_goto_AExpr _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | PROJ2 _v_4 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState003
      | PROJ1 _v_5 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState003
      | PRIMITIVE _v_6 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState003
      | PIPE _v_7 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _menhir_stack = MenhirCell1_PIPE (_menhir_stack, MenhirState003, _v_7) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_8 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState179
          | STRINGV _v_9 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_9 in
              let _v = _menhir_action_08 _1 in
              _menhir_run_119_spec_179 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | PROJ2 _v_11 ->
              _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState179
          | PROJ1 _v_12 ->
              _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState179
          | PRIMITIVE _v_13 ->
              _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState179
          | LPAREN _v_14 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState179
          | LET _v_15 ->
              _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState179
          | INR _v_16 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_16 in
              let _v = _menhir_action_04 _1 in
              _menhir_run_119_spec_179 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | INL _v_18 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_18 in
              let _v = _menhir_action_03 _1 in
              _menhir_run_119_spec_179 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | IF _v_20 ->
              _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState179
          | ID _v_21 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_21 MenhirState179
          | FUN _v_22 ->
              _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_22 MenhirState179
          | FLOATV _v_23 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_23 in
              let _v = _menhir_action_09 _1 in
              _menhir_run_119_spec_179 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | LPAREN _v_25 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_25 MenhirState003
      | LET _v_26 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_26 MenhirState003
      | INR _v_27 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_27 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_29 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_29 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_31 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_31 MenhirState003
      | ID _v_32 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_32 MenhirState003
      | FUN _v_33 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_33 MenhirState003
      | FLOATV _v_34 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_34 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_003 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_122_spec_003 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState003 _tok
  
  and _menhir_goto_AExpr : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _1 = _v in
      let _v = _menhir_action_81 _1 in
      let _1 = _v in
      let _v = _menhir_action_40 _1 in
      let _1 = _v in
      let _v = _menhir_action_74 _1 in
      _menhir_goto_STerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_STerm : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_goto_FTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_FTerm : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState000 ->
          _menhir_run_122_spec_000 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState199 ->
          _menhir_run_122_spec_199 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState206 ->
          _menhir_run_122_spec_206 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState001 ->
          _menhir_run_122_spec_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState003 ->
          _menhir_run_122_spec_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState187 ->
          _menhir_run_122_spec_187 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState179 ->
          _menhir_run_122_spec_179 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState181 ->
          _menhir_run_122_spec_181 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState005 ->
          _menhir_run_122_spec_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState006 ->
          _menhir_run_122_spec_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState084 ->
          _menhir_run_122_spec_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState172 ->
          _menhir_run_122_spec_172 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState091 ->
          _menhir_run_122_spec_091 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState164 ->
          _menhir_run_122_spec_164 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState168 ->
          _menhir_run_122_spec_168 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState094 ->
          _menhir_run_122_spec_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState106 ->
          _menhir_run_122_spec_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState154 ->
          _menhir_run_122_spec_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState108 ->
          _menhir_run_122_spec_108 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState141 ->
          _menhir_run_122_spec_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState149 ->
          _menhir_run_122_spec_149 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState145 ->
          _menhir_run_122_spec_145 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState143 ->
          _menhir_run_122_spec_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState136 ->
          _menhir_run_122_spec_136 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState137 ->
          _menhir_run_122_spec_137 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState113 ->
          _menhir_run_122_spec_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState133 ->
          _menhir_run_122_spec_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState131 ->
          _menhir_run_122_spec_131 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState129 ->
          _menhir_run_122_spec_129 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState126 ->
          _menhir_run_122_spec_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState124 ->
          _menhir_run_122_spec_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState114 ->
          _menhir_run_122_spec_114 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState120 ->
          _menhir_run_121 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState116 ->
          _menhir_run_117 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_122_spec_000 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000 _tok
  
  and _menhir_run_122_spec_199 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState199 _tok
  
  and _menhir_run_122_spec_206 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_PIPE _menhir_cell0_INR _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState206 _tok
  
  and _menhir_run_122_spec_187 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState187 _tok
  
  and _menhir_run_122_spec_179 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState179 _tok
  
  and _menhir_run_122_spec_181 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState181 _tok
  
  and _menhir_run_122_spec_005 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_PROJ2 -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState005 _tok
  
  and _menhir_run_122_spec_006 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_PROJ1 -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState006 _tok
  
  and _menhir_run_122_spec_084 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID _menhir_cell0_Quantifiers, _menhir_box_body) _menhir_cell1_Arguments _menhir_cell0_COLON, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_LBRACE _menhir_cell0_PrimSpec _menhir_cell0_RBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState084 _tok
  
  and _menhir_run_122_spec_172 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_SEMI -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState172 _tok
  
  and _menhir_run_122_spec_091 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState091 _tok
  
  and _menhir_run_122_spec_164 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_THEN _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_RBRACK _menhir_cell0_LBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState164 _tok
  
  and _menhir_run_122_spec_168 : type  ttv_stack. ((((ttv_stack, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_THEN _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_RBRACK _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_RBRACE _menhir_cell0_ELSE _menhir_cell0_LBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState168 _tok
  
  and _menhir_run_122_spec_094 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_IF -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState094 _tok
  
  and _menhir_run_122_spec_106 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_ColType _menhir_cell0_RPAREN _menhir_cell0_MaybeType _menhir_cell0_LBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState106 _tok
  
  and _menhir_run_122_spec_154 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_ID _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_SEMI -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState154 _tok
  
  and _menhir_run_122_spec_108 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_ID _menhir_cell0_EQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState108 _tok
  
  and _menhir_run_122_spec_141 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LogOrTerm _menhir_cell0_OR -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState141 _tok
  
  and _menhir_run_122_spec_149 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_BequalTerm _menhir_cell0_BANG _menhir_cell0_EQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState149 _tok
  
  and _menhir_run_122_spec_145 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_BequalTerm _menhir_cell0_BEQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState145 _tok
  
  and _menhir_run_122_spec_143 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LogAndTerm _menhir_cell0_AND -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState143 _tok
  
  and _menhir_run_122_spec_136 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_GT -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState136 _tok
  
  and _menhir_run_122_spec_137 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_GT, _menhir_box_body) _menhir_cell1_EQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState137 _tok
  
  and _menhir_run_122_spec_113 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_LT -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState113 _tok
  
  and _menhir_run_122_spec_133 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_ADD -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_134 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState133 _tok
  
  and _menhir_run_122_spec_131 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_DOT _menhir_cell0_ADD -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_132 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState131 _tok
  
  and _menhir_run_132 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_DOT _menhir_cell0_ADD as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | MUL _v_0 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | DIV _v_1 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_120 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | ADD _ | AND _ | BANG _ | BEQUAL _ | COMMA _ | DOT _ | EOF _ | GT _ | HAT _ | LT _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | SUB _ | THEN _ ->
          let MenhirCell0_ADD (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_DOT (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _4 = _v in
          let _v = _menhir_action_21 _1 _2 _4 in
          _menhir_goto_AddTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_AddTerm : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState000 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState001 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState199 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState206 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState003 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState187 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState179 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState181 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState005 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState006 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState084 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState091 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState172 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState094 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState164 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState168 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState106 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState108 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState154 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState141 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState143 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState149 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState145 ->
          _menhir_run_147 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState136 ->
          _menhir_run_139 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState137 ->
          _menhir_run_138 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState113 ->
          _menhir_run_135 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState114 ->
          _menhir_run_123 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_147 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | SUB _v_0 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | HAT _v_1 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | DOT _v_2 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_128 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2
      | ADD _v_3 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3
      | AND _ | BANG _ | BEQUAL _ | COMMA _ | EOF _ | GT _ | LT _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let _1 = _v in
          let _v = _menhir_action_70 _1 in
          _menhir_goto_RelTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_124 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_SUB (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState124
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState124
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState124
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState124
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_124 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_SUB -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_122_spec_124 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_SUB -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_125 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState124 _tok
  
  and _menhir_run_125 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_SUB as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | MUL _v_0 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | DIV _v_1 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_120 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | ADD _ | AND _ | BANG _ | BEQUAL _ | COMMA _ | DOT _ | EOF _ | GT _ | HAT _ | LT _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | SUB _ | THEN _ ->
          let MenhirCell0_SUB (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_23 _1 _2 _3 in
          _menhir_goto_AddTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_094 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_IF (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState094
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState094
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState094
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState094
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_094 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_IF -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_096 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_FUN (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LPAREN _v_0 ->
          let _menhir_stack = MenhirCell0_LPAREN (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | ID _v_1 ->
              let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | COLON _v_2 ->
                  let _menhir_stack = MenhirCell0_COLON (_menhir_stack, _v_2) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | STRING _ ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _v = _menhir_action_14 () in
                      _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState099 _tok
                  | NUM _ ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _v = _menhir_action_12 () in
                      _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState099 _tok
                  | LPAREN _v_7 ->
                      _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState099
                  | INT _ ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _v = _menhir_action_13 () in
                      _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState099 _tok
                  | ID _v_10 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_10 in
                      let _v = _menhir_action_11 _1 in
                      _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState099 _tok
                  | FUZZY _v_12 ->
                      _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState099
                  | DBSOURCE _ ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _v = _menhir_action_16 () in
                      _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState099 _tok
                  | CLIPPED _ ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _v = _menhir_action_15 () in
                      _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState099 _tok
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_051 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | LOLLIPOP _v_0 ->
          let _menhir_stack = MenhirCell1_AType (_menhir_stack, _menhir_s, _v) in
          _menhir_run_052 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | BAG _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v in
          let _v = _menhir_action_90 _1 in
          _menhir_goto_Type _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | ARROW _v_2 ->
          let _menhir_stack = MenhirCell1_AType (_menhir_stack, _menhir_s, _v) in
          _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2
      | ADD _v_3 ->
          let _menhir_stack = MenhirCell1_AType (_menhir_stack, _menhir_s, _v) in
          _menhir_run_060 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3
      | COMMA _ | LBRACE _ | PIPE _ | RBRACK _ | RPAREN _ ->
          let _1 = _v in
          let _v = _menhir_action_38 _1 in
          _menhir_goto_ComplexType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_052 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AType -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_LOLLIPOP (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRING _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_14 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState052 _tok
      | NUM _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_12 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState052 _tok
      | LPAREN _v_4 ->
          _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState052
      | LBRACK _v_5 ->
          let _menhir_stack = MenhirCell1_LBRACK (_menhir_stack, MenhirState052, _v_5) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | ID _v_6 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_6 in
              let _v = _menhir_action_75 _1 in
              _menhir_run_036_spec_053 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | FLOATV _v_8 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_8 in
              let _v = _menhir_action_76 _1 in
              _menhir_run_036_spec_053 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | INT _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_13 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState052 _tok
      | ID _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_11 _1 in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState052 _tok
      | FUZZY _v_14 ->
          _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState052
      | DBSOURCE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_16 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState052 _tok
      | CLIPPED _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_15 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState052 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_057 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | LOLLIPOP _v_0 ->
          let _menhir_stack = MenhirCell1_AType (_menhir_stack, _menhir_s, _v) in
          _menhir_run_052 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | ARROW _v_1 ->
          let _menhir_stack = MenhirCell1_AType (_menhir_stack, _menhir_s, _v) in
          _menhir_run_058 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | ADD _v_2 ->
          let _menhir_stack = MenhirCell1_AType (_menhir_stack, _menhir_s, _v) in
          _menhir_run_060 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2
      | COMMA _ | LBRACE _ | PIPE _ | RBRACK _ | RPAREN _ ->
          let _1 = _v in
          let _v = _menhir_action_38 _1 in
          _menhir_goto_ComplexType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_058 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AType -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_ARROW (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRING _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_14 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState058 _tok
      | NUM _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_12 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState058 _tok
      | LPAREN _v_4 ->
          _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState058
      | INT _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_13 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState058 _tok
      | ID _v_7 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_7 in
          let _v = _menhir_action_11 _1 in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState058 _tok
      | FUZZY _v_9 ->
          _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState058
      | DBSOURCE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_16 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState058 _tok
      | CLIPPED _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_15 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState058 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_041 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRING _ ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_14 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState041 _tok
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_17 () in
          _menhir_goto_AType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | PIPE _v_3 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _menhir_stack = MenhirCell1_PIPE (_menhir_stack, MenhirState041, _v_3) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRING _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_14 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState043 _tok
          | NUM _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_12 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState043 _tok
          | LPAREN _v_8 ->
              _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState043
          | INT _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_13 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState043 _tok
          | ID _v_11 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_11 in
              let _v = _menhir_action_11 _1 in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState043 _tok
          | FUZZY _v_13 ->
              _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState043
          | DBSOURCE _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_16 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState043 _tok
          | CLIPPED _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_15 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState043 _tok
          | _ ->
              _eRR ())
      | NUM _ ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_12 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState041 _tok
      | LPAREN _v_20 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState041
      | INT _ ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_13 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState041 _tok
      | ID _v_23 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_23 in
          let _v = _menhir_action_11 _1 in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState041 _tok
      | FUZZY _v_25 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_25 MenhirState041
      | DBSOURCE _ ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_16 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState041 _tok
      | CLIPPED _ ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_15 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState041 _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_AType : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState052 ->
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState060 ->
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState058 ->
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState055 ->
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState079 ->
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState161 ->
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState103 ->
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState099 ->
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState038 ->
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState041 ->
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState071 ->
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState043 ->
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState065 ->
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState046 ->
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_046 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_FUZZY (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRING _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_14 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState046 _tok
      | NUM _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_12 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState046 _tok
      | LPAREN _v_4 ->
          _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState046
      | INT _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_13 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState046 _tok
      | ID _v_7 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_7 in
          let _v = _menhir_action_11 _1 in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState046 _tok
      | FUZZY _v_9 ->
          _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState046
      | DBSOURCE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_16 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState046 _tok
      | CLIPPED _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_15 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState046 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_060 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AType -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_ADD (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRING _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_14 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState060 _tok
      | NUM _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_12 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState060 _tok
      | LPAREN _v_4 ->
          _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState060
      | INT _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_13 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState060 _tok
      | ID _v_7 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_7 in
          let _v = _menhir_action_11 _1 in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState060 _tok
      | FUZZY _v_9 ->
          _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState060
      | DBSOURCE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_16 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState060 _tok
      | CLIPPED _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_15 () in
          _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState060 _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_ComplexType : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState052 ->
          _menhir_run_062 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState060 ->
          _menhir_run_061 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState058 ->
          _menhir_run_059 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState055 ->
          _menhir_run_056 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState079 ->
          _menhir_run_050_spec_079 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState161 ->
          _menhir_run_050_spec_161 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState103 ->
          _menhir_run_050_spec_103 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState099 ->
          _menhir_run_050_spec_099 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState038 ->
          _menhir_run_050_spec_038 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState041 ->
          _menhir_run_050_spec_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState071 ->
          _menhir_run_050_spec_071 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState043 ->
          _menhir_run_050_spec_043 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState065 ->
          _menhir_run_050_spec_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState046 ->
          _menhir_run_050_spec_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_062 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_LOLLIPOP -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_LOLLIPOP (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_AType (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_35 _1 _3 in
      _menhir_goto_ComplexType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_061 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_ADD -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_ADD (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_AType (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_34 _1 _3 in
      _menhir_goto_ComplexType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_059 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_ARROW -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_ARROW (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_AType (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_33 _1 _3 in
      _menhir_goto_ComplexType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_056 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_LOLLIPOP, _menhir_box_body) _menhir_cell1_LBRACK, _menhir_box_body) _menhir_cell1_SensTerm _menhir_cell0_RBRACK -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_RBRACK (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_SensTerm (_menhir_stack, _, _) = _menhir_stack in
      let MenhirCell1_LBRACK (_menhir_stack, _, _) = _menhir_stack in
      let MenhirCell0_LOLLIPOP (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_AType (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _6 = _v in
      let _v = _menhir_action_36 _1 _6 in
      _menhir_goto_ComplexType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_050_spec_079 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID _menhir_cell0_Quantifiers, _menhir_box_body) _menhir_cell1_Arguments _menhir_cell0_COLON -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_91 _1 in
      _menhir_run_080 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState079 _tok
  
  and _menhir_run_080 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID _menhir_cell0_Quantifiers, _menhir_box_body) _menhir_cell1_Arguments _menhir_cell0_COLON as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Type (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | LBRACE _v_0 ->
          let _menhir_stack = MenhirCell0_LBRACE (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRINGV _v_1 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_1 in
              let _v = _menhir_action_61 _1 in
              let _menhir_stack = MenhirCell0_PrimSpec (_menhir_stack, _v) in
              (match (_tok : MenhirBasics.token) with
              | RBRACE _v_0 ->
                  let _menhir_stack = MenhirCell0_RBRACE (_menhir_stack, _v_0) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | UNIONCASE _v_1 ->
                      _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState084
                  | STRINGV _v_2 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_2 in
                      let _v = _menhir_action_08 _1 in
                      _menhir_run_119_spec_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | PROJ2 _v_4 ->
                      _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState084
                  | PROJ1 _v_5 ->
                      _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState084
                  | PRIMITIVE _v_6 ->
                      _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState084
                  | LPAREN _v_7 ->
                      _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState084
                  | LET _v_8 ->
                      _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState084
                  | INR _v_9 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_9 in
                      let _v = _menhir_action_04 _1 in
                      _menhir_run_119_spec_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | INL _v_11 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_11 in
                      let _v = _menhir_action_03 _1 in
                      _menhir_run_119_spec_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | IF _v_13 ->
                      _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState084
                  | ID _v_14 ->
                      _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState084
                  | FUN _v_15 ->
                      _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState084
                  | FLOATV _v_16 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_16 in
                      let _v = _menhir_action_09 _1 in
                      _menhir_run_119_spec_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_084 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID _menhir_cell0_Quantifiers, _menhir_box_body) _menhir_cell1_Arguments _menhir_cell0_COLON, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_LBRACE _menhir_cell0_PrimSpec _menhir_cell0_RBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_005 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_PROJ2 (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState005
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | PROJ2 _v_3 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState005
      | PROJ1 _v_4 ->
          _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState005
      | PRIMITIVE _v_5 ->
          _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState005
      | LPAREN _v_6 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState005
      | LET _v_7 ->
          _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState005
      | INR _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_10 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_10 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_12 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState005
      | ID _v_13 ->
          _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState005
      | FUN _v_14 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState005
      | FLOATV _v_15 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_15 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_005 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_PROJ2 -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_006 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_PROJ1 (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState006
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | PROJ2 _v_3 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState006
      | PROJ1 _v_4 ->
          _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState006
      | PRIMITIVE _v_5 ->
          _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState006
      | LPAREN _v_6 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState006
      | LET _v_7 ->
          _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState006
      | INR _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_10 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_10 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_12 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState006
      | ID _v_13 ->
          _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState006
      | FUN _v_14 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState006
      | FLOATV _v_15 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_15 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_006 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_PROJ1 -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_007 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_PRIMITIVE (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | ID _v ->
          let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | FORALL _v ->
              let _menhir_stack = MenhirCell0_FORALL (_menhir_stack, _v) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | LPAREN _v ->
                  let _menhir_stack = MenhirCell0_LPAREN (_menhir_stack, _v) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | ID _v ->
                      _menhir_run_011 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState010
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | LPAREN _ ->
              let _v = _menhir_action_64 () in
              _menhir_goto_Quantifiers _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_011 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | COLON _v_0 ->
          let _menhir_stack = MenhirCell1_ID (_menhir_stack, _menhir_s, _v) in
          let _menhir_stack = MenhirCell0_COLON (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | TYPE _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_43 () in
              _menhir_goto_Kind _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | SIZE _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_42 () in
              _menhir_goto_Kind _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | SENS _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_44 () in
              _menhir_goto_Kind _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | COMMA _ | RPAREN _ ->
          let _1 = _v in
          let _v = _menhir_action_45 _1 in
          _menhir_goto_KindAnn _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_Kind : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_ID _menhir_cell0_COLON -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_COLON (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_ID (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_46 _1 _3 in
      _menhir_goto_KindAnn _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_KindAnn : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | COMMA _v_0 ->
          let _menhir_stack = MenhirCell1_KindAnn (_menhir_stack, _menhir_s, _v) in
          let _menhir_stack = MenhirCell0_COMMA (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | ID _v ->
              _menhir_run_011 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState020
          | _ ->
              _eRR ())
      | RPAREN _ ->
          let _1 = _v in
          let _v = _menhir_action_62 _1 in
          _menhir_goto_QuantifierList _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_QuantifierList : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState020 ->
          _menhir_run_021 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState010 ->
          _menhir_run_017 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_021 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_KindAnn _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_COMMA (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_KindAnn (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_63 _1 _3 in
      _menhir_goto_QuantifierList _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_017 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID _menhir_cell0_FORALL _menhir_cell0_LPAREN -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_LPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_FORALL (_menhir_stack, _) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_65 _3 in
          _menhir_goto_Quantifiers _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_goto_Quantifiers : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _menhir_stack = MenhirCell0_Quantifiers (_menhir_stack, _v) in
      match (_tok : MenhirBasics.token) with
      | LPAREN _v_0 ->
          _menhir_run_023 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState022
      | _ ->
          _eRR ()
  
  and _menhir_run_023 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | ID _v_0 ->
          let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | COLON _v_1 ->
              let _menhir_stack = MenhirCell0_COLON (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | LBRACK _v_2 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | RBRACK _ ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _v = _menhir_action_52 () in
                      _menhir_goto_MaybeSensitivity _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | ID _v_5 ->
                      let _menhir_stack = MenhirCell0_LBRACK (_menhir_stack, _v_2) in
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_5 in
                      let _v = _menhir_action_75 _1 in
                      _menhir_run_036_spec_026 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | FLOATV _v_7 ->
                      let _menhir_stack = MenhirCell0_LBRACK (_menhir_stack, _v_2) in
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_7 in
                      let _v = _menhir_action_76 _1 in
                      _menhir_run_036_spec_026 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | _ ->
                      _eRR ())
              | CLIPPED _ | DBSOURCE _ | FUZZY _ | ID _ | INT _ | LPAREN _ | NUM _ | STRING _ ->
                  let _v = _menhir_action_51 () in
                  _menhir_goto_MaybeSensitivity _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_goto_MaybeSensitivity : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN _menhir_cell0_ID _menhir_cell0_COLON -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _menhir_stack = MenhirCell0_MaybeSensitivity (_menhir_stack, _v) in
      match (_tok : MenhirBasics.token) with
      | STRING _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_14 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState038 _tok
      | NUM _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_12 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState038 _tok
      | LPAREN _v_4 ->
          _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState038
      | INT _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_13 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState038 _tok
      | ID _v_7 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_7 in
          let _v = _menhir_action_11 _1 in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState038 _tok
      | FUZZY _v_9 ->
          _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState038
      | DBSOURCE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_16 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState038 _tok
      | CLIPPED _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_15 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState038 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_036_spec_026 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN _menhir_cell0_ID _menhir_cell0_COLON _menhir_cell0_LBRACK -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_78 _1 in
      _menhir_run_037 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState026 _tok
  
  and _menhir_run_037 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | MUL _v_0 ->
          let _menhir_stack = MenhirCell1_SensMulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_034 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | ADD _ | RBRACK _ ->
          let _1 = _v in
          let _v = _menhir_action_80 _1 in
          _menhir_goto_SensTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_034 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_SensMulTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_MUL (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | ID _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_75 _1 in
          _menhir_run_035 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FLOATV _v_2 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_2 in
          let _v = _menhir_action_76 _1 in
          _menhir_run_035 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_035 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_SensMulTerm _menhir_cell0_MUL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_MUL (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_SensMulTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_77 _1 _3 in
      _menhir_goto_SensMulTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_SensMulTerm : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState053 ->
          _menhir_run_037 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState026 ->
          _menhir_run_037 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState032 ->
          _menhir_run_033 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_033 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_SensTerm _menhir_cell0_ADD as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | MUL _v_0 ->
          let _menhir_stack = MenhirCell1_SensMulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_034 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | ADD _ | RBRACK _ ->
          let MenhirCell0_ADD (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_SensTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_79 _1 _3 in
          _menhir_goto_SensTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_SensTerm : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState053 ->
          _menhir_run_054 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState026 ->
          _menhir_run_030 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_054 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_LOLLIPOP, _menhir_box_body) _menhir_cell1_LBRACK as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_SensTerm (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | RBRACK _v_0 ->
          let _menhir_stack = MenhirCell0_RBRACK (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRING _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_14 () in
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState055 _tok
          | NUM _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_12 () in
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState055 _tok
          | LPAREN _v_5 ->
              _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState055
          | INT _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_13 () in
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState055 _tok
          | ID _v_8 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_8 in
              let _v = _menhir_action_11 _1 in
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState055 _tok
          | FUZZY _v_10 ->
              _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState055
          | DBSOURCE _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_16 () in
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState055 _tok
          | CLIPPED _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_15 () in
              _menhir_run_057 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState055 _tok
          | _ ->
              _eRR ())
      | ADD _v_15 ->
          _menhir_run_032 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_032 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_SensTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_ADD (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | ID _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_75 _1 in
          _menhir_run_036_spec_032 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FLOATV _v_2 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_2 in
          let _v = _menhir_action_76 _1 in
          _menhir_run_036_spec_032 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_036_spec_032 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_SensTerm _menhir_cell0_ADD -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_78 _1 in
      _menhir_run_033 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState032 _tok
  
  and _menhir_run_030 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN _menhir_cell0_ID _menhir_cell0_COLON _menhir_cell0_LBRACK as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | RBRACK _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_LBRACK (_menhir_stack, _) = _menhir_stack in
          let _2 = _v in
          let _v = _menhir_action_53 _2 in
          _menhir_goto_MaybeSensitivity _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | ADD _v_1 ->
          let _menhir_stack = MenhirCell1_SensTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_032 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_085 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_LET (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LPAREN _v_0 ->
          let _menhir_stack = MenhirCell0_LPAREN (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | ID _v_1 ->
              let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | COMMA _v_2 ->
                  let _menhir_stack = MenhirCell0_COMMA (_menhir_stack, _v_2) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | ID _v_3 ->
                      let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_3) in
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      (match (_tok : MenhirBasics.token) with
                      | RPAREN _v_4 ->
                          let _menhir_stack = MenhirCell0_RPAREN (_menhir_stack, _v_4) in
                          let _tok = _menhir_lexer _menhir_lexbuf in
                          (match (_tok : MenhirBasics.token) with
                          | EQUAL _v_5 ->
                              let _menhir_stack = MenhirCell0_EQUAL (_menhir_stack, _v_5) in
                              let _tok = _menhir_lexer _menhir_lexbuf in
                              (match (_tok : MenhirBasics.token) with
                              | UNIONCASE _v_6 ->
                                  _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState091
                              | STRINGV _v_7 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_7 in
                                  let _v = _menhir_action_08 _1 in
                                  _menhir_run_119_spec_091 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                              | LPAREN _v_9 ->
                                  _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState091
                              | INR _v_10 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_10 in
                                  let _v = _menhir_action_04 _1 in
                                  _menhir_run_119_spec_091 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                              | INL _v_12 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_12 in
                                  let _v = _menhir_action_03 _1 in
                                  _menhir_run_119_spec_091 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                              | IF _v_14 ->
                                  _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState091
                              | ID _v_15 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_15 in
                                  let _v = _menhir_action_02 _1 in
                                  _menhir_run_119_spec_091 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                              | FUN _v_17 ->
                                  _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState091
                              | FLOATV _v_18 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_18 in
                                  let _v = _menhir_action_09 _1 in
                                  _menhir_run_119_spec_091 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                              | _ ->
                                  _eRR ())
                          | _ ->
                              _eRR ())
                      | _ ->
                          _eRR ())
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_091 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_091 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_107 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | EQUAL _v_0 ->
          let _menhir_stack = MenhirCell1_ID (_menhir_stack, _menhir_s, _v) in
          let _menhir_stack = MenhirCell0_EQUAL (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState108
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_08 _1 in
              _menhir_run_119_spec_108 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | LPAREN _v_4 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState108
          | INR _v_5 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_5 in
              let _v = _menhir_action_04 _1 in
              _menhir_run_119_spec_108 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | INL _v_7 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_7 in
              let _v = _menhir_action_03 _1 in
              _menhir_run_119_spec_108 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | IF _v_9 ->
              _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState108
          | ID _v_10 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_10 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_119_spec_108 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | FUN _v_12 ->
              _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState108
          | FLOATV _v_13 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_13 in
              let _v = _menhir_action_09 _1 in
              _menhir_run_119_spec_108 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | ADD _ | AND _ | BANG _ | BEQUAL _ | COMMA _ | DIV _ | DOT _ | EOF _ | GT _ | HAT _ | LT _ | MUL _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SUB _ ->
          let _1 = _v in
          let _v = _menhir_action_02 _1 in
          _menhir_goto_AExpr _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_108 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_ID _menhir_cell0_EQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_108 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_050_spec_161 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_THEN _menhir_cell0_LBRACK -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_91 _1 in
      _menhir_run_162 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState161 _tok
  
  and _menhir_run_162 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_THEN _menhir_cell0_LBRACK as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Type (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | RBRACK _v_0 ->
          let _menhir_stack = MenhirCell0_RBRACK (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LBRACE _v_1 ->
              let _menhir_stack = MenhirCell0_LBRACE (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | UNIONCASE _v_2 ->
                  _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState164
              | STRINGV _v_3 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_3 in
                  let _v = _menhir_action_08 _1 in
                  _menhir_run_119_spec_164 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
              | PROJ2 _v_5 ->
                  _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState164
              | PROJ1 _v_6 ->
                  _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState164
              | PRIMITIVE _v_7 ->
                  _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState164
              | LPAREN _v_8 ->
                  _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState164
              | LET _v_9 ->
                  _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState164
              | INR _v_10 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_10 in
                  let _v = _menhir_action_04 _1 in
                  _menhir_run_119_spec_164 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
              | INL _v_12 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_12 in
                  let _v = _menhir_action_03 _1 in
                  _menhir_run_119_spec_164 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
              | IF _v_14 ->
                  _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState164
              | ID _v_15 ->
                  _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState164
              | FUN _v_16 ->
                  _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState164
              | FLOATV _v_17 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_17 in
                  let _v = _menhir_action_09 _1 in
                  _menhir_run_119_spec_164 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_164 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_THEN _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_RBRACK _menhir_cell0_LBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_164 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_050_spec_103 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_ColType _menhir_cell0_RPAREN _menhir_cell0_COLON -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_91 _1 in
      _menhir_run_104 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_104 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_ColType _menhir_cell0_RPAREN _menhir_cell0_COLON -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_COLON (_menhir_stack, _) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_55 _2 in
      _menhir_goto_MaybeType _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_goto_MaybeType : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_ColType _menhir_cell0_RPAREN -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _menhir_stack = MenhirCell0_MaybeType (_menhir_stack, _v) in
      match (_tok : MenhirBasics.token) with
      | LBRACE _v_0 ->
          let _menhir_stack = MenhirCell0_LBRACE (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState106
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_08 _1 in
              _menhir_run_119_spec_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | PROJ2 _v_4 ->
              _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState106
          | PROJ1 _v_5 ->
              _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState106
          | PRIMITIVE _v_6 ->
              _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState106
          | LPAREN _v_7 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState106
          | LET _v_8 ->
              _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState106
          | INR _v_9 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_9 in
              let _v = _menhir_action_04 _1 in
              _menhir_run_119_spec_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | INL _v_11 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_11 in
              let _v = _menhir_action_03 _1 in
              _menhir_run_119_spec_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | IF _v_13 ->
              _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState106
          | ID _v_14 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState106
          | FUN _v_15 ->
              _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState106
          | FLOATV _v_16 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_16 in
              let _v = _menhir_action_09 _1 in
              _menhir_run_119_spec_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_106 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_ColType _menhir_cell0_RPAREN _menhir_cell0_MaybeType _menhir_cell0_LBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_050_spec_099 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COLON -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_91 _1 in
      _menhir_run_100 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_100 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COLON -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_COLON (_menhir_stack, _) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_32 _2 in
      let _menhir_stack = MenhirCell0_ColType (_menhir_stack, _v) in
      match (_tok : MenhirBasics.token) with
      | RPAREN _v_0 ->
          let _menhir_stack = MenhirCell0_RPAREN (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | COLON _v_1 ->
              let _menhir_stack = MenhirCell0_COLON (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | STRING _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_14 () in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState103 _tok
              | NUM _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_12 () in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState103 _tok
              | LPAREN _v_6 ->
                  _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState103
              | INT _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_13 () in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState103 _tok
              | ID _v_9 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_9 in
                  let _v = _menhir_action_11 _1 in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState103 _tok
              | FUZZY _v_11 ->
                  _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState103
              | DBSOURCE _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_16 () in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState103 _tok
              | CLIPPED _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_15 () in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState103 _tok
              | _ ->
                  _eRR ())
          | LBRACE _ ->
              let _v = _menhir_action_54 () in
              _menhir_goto_MaybeType _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_050_spec_038 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN _menhir_cell0_ID _menhir_cell0_COLON _menhir_cell0_MaybeSensitivity -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_91 _1 in
      _menhir_run_076 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_076 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN _menhir_cell0_ID _menhir_cell0_COLON _menhir_cell0_MaybeSensitivity -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_MaybeSensitivity (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_COLON (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _5 = _v in
          let _v = _menhir_action_26 _2 _5 in
          (match (_tok : MenhirBasics.token) with
          | LPAREN _v_0 ->
              let _menhir_stack = MenhirCell1_Argument (_menhir_stack, _menhir_s, _v) in
              _menhir_run_023 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState175
          | COLON _ ->
              let _1 = _v in
              let _v = _menhir_action_27 _1 in
              _menhir_goto_Arguments _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_goto_Arguments : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState175 ->
          _menhir_run_176 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState022 ->
          _menhir_run_078 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_176 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Argument -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_Argument (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_28 _1 _2 in
      _menhir_goto_Arguments _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_078 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID _menhir_cell0_Quantifiers as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Arguments (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | COLON _v_0 ->
          let _menhir_stack = MenhirCell0_COLON (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRING _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_14 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState079 _tok
          | NUM _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_12 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState079 _tok
          | LPAREN _v_5 ->
              _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState079
          | INT _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_13 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState079 _tok
          | ID _v_8 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_8 in
              let _v = _menhir_action_11 _1 in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState079 _tok
          | FUZZY _v_10 ->
              _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState079
          | DBSOURCE _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_16 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState079 _tok
          | CLIPPED _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_15 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState079 _tok
          | _ ->
              _eRR ())
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_050_spec_041 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_91 _1 in
      _menhir_run_069 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState041 _tok
  
  and _menhir_run_069 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _2 = _v in
          let _v = _menhir_action_10 _2 in
          _menhir_goto_AType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | COMMA _v_1 ->
          let _menhir_stack = MenhirCell1_Type (_menhir_stack, _menhir_s, _v) in
          _menhir_run_071 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | _ ->
          _eRR ()
  
  and _menhir_run_071 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Type -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_COMMA (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRING _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_14 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState071 _tok
      | NUM _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_12 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState071 _tok
      | LPAREN _v_4 ->
          _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState071
      | INT _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_13 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState071 _tok
      | ID _v_7 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_7 in
          let _v = _menhir_action_11 _1 in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState071 _tok
      | FUZZY _v_9 ->
          _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState071
      | DBSOURCE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_16 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState071 _tok
      | CLIPPED _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_15 () in
          _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState071 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_050_spec_071 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_91 _1 in
      _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState071 _tok
  
  and _menhir_run_072 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | COMMA _v_0 ->
          let _menhir_stack = MenhirCell1_Type (_menhir_stack, _menhir_s, _v) in
          _menhir_run_071 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | RPAREN _ ->
          let MenhirCell0_COMMA (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Type (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_82 _1 _3 in
          _menhir_goto_TPairSeq _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_TPairSeq : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState041 ->
          _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState071 ->
          _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_074 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _2 = _v in
          let _v = _menhir_action_18 _2 in
          _menhir_goto_AType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_073 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_COMMA (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_Type (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_83 _1 _3 in
      _menhir_goto_TPairSeq _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_050_spec_043 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_91 _1 in
      _menhir_run_064 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState043 _tok
  
  and _menhir_run_064 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Type (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | COMMA _v_0 ->
          let _menhir_stack = MenhirCell0_COMMA (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRING _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_14 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState065 _tok
          | NUM _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_12 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState065 _tok
          | LPAREN _v_5 ->
              _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState065
          | INT _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_13 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState065 _tok
          | ID _v_8 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_8 in
              let _v = _menhir_action_11 _1 in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState065 _tok
          | FUZZY _v_10 ->
              _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState065
          | DBSOURCE _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_16 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState065 _tok
          | CLIPPED _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_15 () in
              _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState065 _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_050_spec_065 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_91 _1 in
      _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_066 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | PIPE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | RPAREN _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let MenhirCell0_COMMA (_menhir_stack, _) = _menhir_stack in
              let MenhirCell1_Type (_menhir_stack, _, _3) = _menhir_stack in
              let MenhirCell1_PIPE (_menhir_stack, _, _) = _menhir_stack in
              let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
              let _5 = _v in
              let _v = _menhir_action_19 _3 _5 in
              _menhir_goto_AType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_050_spec_046 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_FUZZY -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_91 _1 in
      _menhir_run_049 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_049 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_FUZZY -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_FUZZY (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_37 _2 in
      _menhir_goto_ComplexType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_036_spec_053 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_LOLLIPOP, _menhir_box_body) _menhir_cell1_LBRACK -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_78 _1 in
      _menhir_run_037 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState053 _tok
  
  and _menhir_goto_Type : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState161 ->
          _menhir_run_162 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState103 ->
          _menhir_run_104 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState099 ->
          _menhir_run_100 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState079 ->
          _menhir_run_080 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState038 ->
          _menhir_run_076 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState071 ->
          _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState041 ->
          _menhir_run_069 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState065 ->
          _menhir_run_066 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState043 ->
          _menhir_run_064 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState046 ->
          _menhir_run_049 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_126 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_HAT (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState126
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState126
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState126
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState126
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_126 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_HAT -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_122_spec_126 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_HAT -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_127 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState126 _tok
  
  and _menhir_run_127 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_HAT as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | MUL _v_0 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | DIV _v_1 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_120 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | ADD _ | AND _ | BANG _ | BEQUAL _ | COMMA _ | DOT _ | EOF _ | GT _ | HAT _ | LT _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | SUB _ | THEN _ ->
          let MenhirCell0_HAT (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_22 _1 _2 _3 in
          _menhir_goto_AddTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_128 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_DOT (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | SUB _v_0 ->
          let _menhir_stack = MenhirCell0_SUB (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState129
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_08 _1 in
              _menhir_run_119_spec_129 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | LPAREN _v_4 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState129
          | INR _v_5 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_5 in
              let _v = _menhir_action_04 _1 in
              _menhir_run_119_spec_129 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | INL _v_7 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_7 in
              let _v = _menhir_action_03 _1 in
              _menhir_run_119_spec_129 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | IF _v_9 ->
              _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState129
          | ID _v_10 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_10 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_119_spec_129 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | FUN _v_12 ->
              _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState129
          | FLOATV _v_13 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_13 in
              let _v = _menhir_action_09 _1 in
              _menhir_run_119_spec_129 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | ADD _v_15 ->
          let _menhir_stack = MenhirCell0_ADD (_menhir_stack, _v_15) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_16 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState131
          | STRINGV _v_17 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_17 in
              let _v = _menhir_action_08 _1 in
              _menhir_run_119_spec_131 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | LPAREN _v_19 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState131
          | INR _v_20 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_20 in
              let _v = _menhir_action_04 _1 in
              _menhir_run_119_spec_131 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | INL _v_22 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_22 in
              let _v = _menhir_action_03 _1 in
              _menhir_run_119_spec_131 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | IF _v_24 ->
              _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState131
          | ID _v_25 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_25 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_119_spec_131 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | FUN _v_27 ->
              _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_27 MenhirState131
          | FLOATV _v_28 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_28 in
              let _v = _menhir_action_09 _1 in
              _menhir_run_119_spec_131 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_129 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_DOT _menhir_cell0_SUB -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_129 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_122_spec_129 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_DOT _menhir_cell0_SUB -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_130 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState129 _tok
  
  and _menhir_run_130 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_DOT _menhir_cell0_SUB as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | MUL _v_0 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | DIV _v_1 ->
          let _menhir_stack = MenhirCell1_MulTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_120 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | ADD _ | AND _ | BANG _ | BEQUAL _ | COMMA _ | DOT _ | EOF _ | GT _ | HAT _ | LT _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | SUB _ | THEN _ ->
          let MenhirCell0_SUB (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_DOT (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _4 = _v in
          let _v = _menhir_action_24 _1 _2 _4 in
          _menhir_goto_AddTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_131 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_DOT _menhir_cell0_ADD -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_131 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_133 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_ADD (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState133
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState133
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState133
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState133
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_133 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AddTerm _menhir_cell0_ADD -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_goto_RelTerm : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState149 ->
          _menhir_run_150 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState145 ->
          _menhir_run_146 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState000 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState199 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState206 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState001 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState003 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState187 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState179 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState181 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState005 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState006 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState084 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState172 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState091 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState164 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState168 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState094 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState106 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState154 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState143 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState141 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState108 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_150 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_BequalTerm _menhir_cell0_BANG _menhir_cell0_EQUAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | LT _v_0 ->
          let _menhir_stack = MenhirCell1_RelTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | GT _v_1 ->
          let _menhir_stack = MenhirCell1_RelTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_136 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | AND _ | BANG _ | BEQUAL _ | COMMA _ | EOF _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let MenhirCell0_EQUAL (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_BANG (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_BequalTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _4 = _v in
          let _v = _menhir_action_30 _1 _2 _4 in
          _menhir_goto_BequalTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_113 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_LT (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState113
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState113
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState113
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState113
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EQUAL _v_14 ->
          let _menhir_stack = MenhirCell1_EQUAL (_menhir_stack, MenhirState113, _v_14) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_15 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState114
          | STRINGV _v_16 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_16 in
              let _v = _menhir_action_08 _1 in
              _menhir_run_119_spec_114 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | LPAREN _v_18 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState114
          | INR _v_19 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_19 in
              let _v = _menhir_action_04 _1 in
              _menhir_run_119_spec_114 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | INL _v_21 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_21 in
              let _v = _menhir_action_03 _1 in
              _menhir_run_119_spec_114 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | IF _v_23 ->
              _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState114
          | ID _v_24 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_24 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_119_spec_114 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | FUN _v_26 ->
              _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_26 MenhirState114
          | FLOATV _v_27 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_27 in
              let _v = _menhir_action_09 _1 in
              _menhir_run_119_spec_114 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_113 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_LT -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_119_spec_114 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_LT, _menhir_box_body) _menhir_cell1_EQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_114 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_122_spec_114 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_LT, _menhir_box_body) _menhir_cell1_EQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_58 _1 in
      _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState114 _tok
  
  and _menhir_run_136 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_GT (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState136
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_136 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState136
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_136 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_136 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState136
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_136 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState136
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_136 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EQUAL _v_14 ->
          let _menhir_stack = MenhirCell1_EQUAL (_menhir_stack, MenhirState136, _v_14) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_15 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState137
          | STRINGV _v_16 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_16 in
              let _v = _menhir_action_08 _1 in
              _menhir_run_119_spec_137 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | LPAREN _v_18 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState137
          | INR _v_19 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_19 in
              let _v = _menhir_action_04 _1 in
              _menhir_run_119_spec_137 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | INL _v_21 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_21 in
              let _v = _menhir_action_03 _1 in
              _menhir_run_119_spec_137 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | IF _v_23 ->
              _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState137
          | ID _v_24 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_24 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_119_spec_137 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | FUN _v_26 ->
              _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_26 MenhirState137
          | FLOATV _v_27 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_27 in
              let _v = _menhir_action_09 _1 in
              _menhir_run_119_spec_137 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_136 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_GT -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_136 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_119_spec_137 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_GT, _menhir_box_body) _menhir_cell1_EQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_137 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_goto_BequalTerm : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState000 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState001 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState199 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState206 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState003 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState187 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState179 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState181 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState005 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState006 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState084 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState091 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState172 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState094 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState164 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState168 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState106 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState108 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState154 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState141 ->
          _menhir_run_151 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState143 ->
          _menhir_run_144 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_151 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | BEQUAL _v_0 ->
          let _menhir_stack = MenhirCell1_BequalTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_145 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | BANG _v_1 ->
          let _menhir_stack = MenhirCell1_BequalTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_148 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | AND _ | COMMA _ | EOF _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let _1 = _v in
          let _v = _menhir_action_48 _1 in
          _menhir_goto_LogAndTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_145 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_BequalTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_BEQUAL (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState145
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_145 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState145
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_145 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_145 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState145
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_145 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState145
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_145 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_145 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_BequalTerm _menhir_cell0_BEQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_145 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_148 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_BequalTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_BANG (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | EQUAL _v_0 ->
          let _menhir_stack = MenhirCell0_EQUAL (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState149
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_08 _1 in
              _menhir_run_119_spec_149 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | LPAREN _v_4 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState149
          | INR _v_5 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_5 in
              let _v = _menhir_action_04 _1 in
              _menhir_run_119_spec_149 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | INL _v_7 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_7 in
              let _v = _menhir_action_03 _1 in
              _menhir_run_119_spec_149 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | IF _v_9 ->
              _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState149
          | ID _v_10 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_10 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_119_spec_149 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | FUN _v_12 ->
              _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState149
          | FLOATV _v_13 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_13 in
              let _v = _menhir_action_09 _1 in
              _menhir_run_119_spec_149 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_149 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_BequalTerm _menhir_cell0_BANG _menhir_cell0_EQUAL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_149 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_goto_LogAndTerm : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState000 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState199 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState206 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState001 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState003 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState187 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState179 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState181 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState005 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState006 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState084 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState172 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState091 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState164 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState168 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState094 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState106 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState154 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState108 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState141 ->
          _menhir_run_142 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_152 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | AND _v_0 ->
          let _menhir_stack = MenhirCell1_LogAndTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | COMMA _ | EOF _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let _1 = _v in
          let _v = _menhir_action_50 _1 in
          _menhir_goto_LogOrTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_143 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LogAndTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_AND (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState143
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState143
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState143
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState143
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_143 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LogAndTerm _menhir_cell0_AND -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_goto_LogOrTerm : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState000 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState199 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState206 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState003 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState187 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState179 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState181 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState005 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState006 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState084 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState172 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState164 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState168 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState106 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState154 ->
          _menhir_run_156 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState001 ->
          _menhir_run_140 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState091 ->
          _menhir_run_140 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState094 ->
          _menhir_run_140 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState108 ->
          _menhir_run_140 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_156 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | OR _v_0 ->
          let _menhir_stack = MenhirCell1_LogOrTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | COMMA _ | EOF _ | PIPE _ | RBRACE _ | RPAREN _ ->
          let _1 = _v in
          let _v = _menhir_action_89 _1 in
          _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_141 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LogOrTerm -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_OR (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState141
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | LPAREN _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState141
      | INR _v_4 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_4 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_8 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState141
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_119_spec_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState141
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_141 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LogOrTerm _menhir_cell0_OR -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_goto_Term : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState000 ->
          _menhir_run_210 _menhir_stack _v _tok
      | MenhirState206 ->
          _menhir_run_207 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState199 ->
          _menhir_run_200 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState187 ->
          _menhir_run_188 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState003 ->
          _menhir_run_185 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState181 ->
          _menhir_run_182 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState179 ->
          _menhir_run_180 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState005 ->
          _menhir_run_178 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState006 ->
          _menhir_run_177 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState084 ->
          _menhir_run_174 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState172 ->
          _menhir_run_173 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState168 ->
          _menhir_run_169 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState164 ->
          _menhir_run_165 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState106 ->
          _menhir_run_157 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState154 ->
          _menhir_run_155 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_207 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_PIPE _menhir_cell0_INR _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RBRACE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_DBLARROW (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_RPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _14) = _menhir_stack in
          let MenhirCell0_LPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_INR (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_PIPE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Term (_menhir_stack, _, _10) = _menhir_stack in
          let MenhirCell0_DBLARROW (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_RPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _7) = _menhir_stack in
          let MenhirCell0_LPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_INL (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_LBRACE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_OF (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Expr (_menhir_stack, _, _2) = _menhir_stack in
          let MenhirCell1_UNIONCASE (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _17 = _v in
          let _v = _menhir_action_72 _1 _10 _14 _17 _2 _7 in
          _menhir_goto_STerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_200 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | PIPE _v_0 ->
          let _menhir_stack = MenhirCell0_PIPE (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | INR _v_1 ->
              let _menhir_stack = MenhirCell0_INR (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | LPAREN _v_2 ->
                  let _menhir_stack = MenhirCell0_LPAREN (_menhir_stack, _v_2) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | ID _v_3 ->
                      let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_3) in
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      (match (_tok : MenhirBasics.token) with
                      | RPAREN _v_4 ->
                          let _menhir_stack = MenhirCell0_RPAREN (_menhir_stack, _v_4) in
                          let _tok = _menhir_lexer _menhir_lexbuf in
                          (match (_tok : MenhirBasics.token) with
                          | DBLARROW _v_5 ->
                              let _menhir_stack = MenhirCell0_DBLARROW (_menhir_stack, _v_5) in
                              let _tok = _menhir_lexer _menhir_lexbuf in
                              (match (_tok : MenhirBasics.token) with
                              | UNIONCASE _v_6 ->
                                  _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState206
                              | STRINGV _v_7 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_7 in
                                  let _v = _menhir_action_08 _1 in
                                  _menhir_run_119_spec_206 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                              | PROJ2 _v_9 ->
                                  _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState206
                              | PROJ1 _v_10 ->
                                  _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState206
                              | PRIMITIVE _v_11 ->
                                  _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState206
                              | LPAREN _v_12 ->
                                  _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState206
                              | LET _v_13 ->
                                  _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState206
                              | INR _v_14 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_14 in
                                  let _v = _menhir_action_04 _1 in
                                  _menhir_run_119_spec_206 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                              | INL _v_16 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_16 in
                                  let _v = _menhir_action_03 _1 in
                                  _menhir_run_119_spec_206 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                              | IF _v_18 ->
                                  _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState206
                              | ID _v_19 ->
                                  _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState206
                              | FUN _v_20 ->
                                  _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState206
                              | FLOATV _v_21 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_21 in
                                  let _v = _menhir_action_09 _1 in
                                  _menhir_run_119_spec_206 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                              | _ ->
                                  _eRR ())
                          | _ ->
                              _eRR ())
                      | _ ->
                          _eRR ())
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_206 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_PIPE _menhir_cell0_INR _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_206 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_188 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_COMMA as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | COMMA _v_0 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_187 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | RPAREN _ ->
          let MenhirCell0_COMMA (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_Term (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_59 _1 _2 _3 in
          _menhir_goto_PairSeq _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_187 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Term -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_COMMA (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState187
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_187 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | PROJ2 _v_3 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState187
      | PROJ1 _v_4 ->
          _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState187
      | PRIMITIVE _v_5 ->
          _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState187
      | LPAREN _v_6 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState187
      | LET _v_7 ->
          _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState187
      | INR _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_187 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v_10 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_10 in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_187 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v_12 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState187
      | ID _v_13 ->
          _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState187
      | FUN _v_14 ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState187
      | FLOATV _v_15 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_15 in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_187 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_187 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_187 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_goto_PairSeq : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState003 ->
          _menhir_run_190 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState187 ->
          _menhir_run_189 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_190 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _2 = _v in
          let _v = _menhir_action_06 _2 in
          _menhir_goto_AExpr _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_189 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_COMMA (_menhir_stack, _2) = _menhir_stack in
      let MenhirCell1_Term (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_60 _1 _2 _3 in
      _menhir_goto_PairSeq _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_185 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _2 = _v in
          let _v = _menhir_action_05 _2 in
          _menhir_goto_AExpr _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | COMMA _v_1 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_187 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | _ ->
          _eRR ()
  
  and _menhir_run_182 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | PIPE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | RPAREN _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let MenhirCell0_COMMA (_menhir_stack, _) = _menhir_stack in
              let MenhirCell1_Term (_menhir_stack, _, _3) = _menhir_stack in
              let MenhirCell1_PIPE (_menhir_stack, _, _) = _menhir_stack in
              let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _1) = _menhir_stack in
              let _5 = _v in
              let _v = _menhir_action_07 _1 _3 _5 in
              _menhir_goto_AExpr _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_180 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | COMMA _v_0 ->
          let _menhir_stack = MenhirCell0_COMMA (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState181
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_08 _1 in
              _menhir_run_119_spec_181 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | PROJ2 _v_4 ->
              _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState181
          | PROJ1 _v_5 ->
              _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState181
          | PRIMITIVE _v_6 ->
              _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState181
          | LPAREN _v_7 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState181
          | LET _v_8 ->
              _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState181
          | INR _v_9 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_9 in
              let _v = _menhir_action_04 _1 in
              _menhir_run_119_spec_181 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | INL _v_11 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_11 in
              let _v = _menhir_action_03 _1 in
              _menhir_run_119_spec_181 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | IF _v_13 ->
              _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState181
          | ID _v_14 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState181
          | FUN _v_15 ->
              _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState181
          | FLOATV _v_16 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_16 in
              let _v = _menhir_action_09 _1 in
              _menhir_run_119_spec_181 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_181 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_181 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_178 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_PROJ2 -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_PROJ2 (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_87 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_177 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_PROJ1 -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_PROJ1 (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_86 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_174 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_PRIMITIVE _menhir_cell0_ID _menhir_cell0_Quantifiers, _menhir_box_body) _menhir_cell1_Arguments _menhir_cell0_COLON, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_LBRACE _menhir_cell0_PrimSpec _menhir_cell0_RBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_RBRACE (_menhir_stack, _) = _menhir_stack in
      let MenhirCell0_PrimSpec (_menhir_stack, _8) = _menhir_stack in
      let MenhirCell0_LBRACE (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_Type (_menhir_stack, _, _6) = _menhir_stack in
      let MenhirCell0_COLON (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_Arguments (_menhir_stack, _, _4) = _menhir_stack in
      let MenhirCell0_Quantifiers (_menhir_stack, _3) = _menhir_stack in
      let MenhirCell0_ID (_menhir_stack, _2) = _menhir_stack in
      let MenhirCell1_PRIMITIVE (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _10 = _v in
      let _v = _menhir_action_88 _1 _10 _2 _3 _4 _6 _8 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_173 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_SEMI -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_SEMI (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_Expr (_menhir_stack, _, _8) = _menhir_stack in
      let MenhirCell0_EQUAL (_menhir_stack, _) = _menhir_stack in
      let MenhirCell0_RPAREN (_menhir_stack, _) = _menhir_stack in
      let MenhirCell0_ID (_menhir_stack, _5) = _menhir_stack in
      let MenhirCell0_COMMA (_menhir_stack, _) = _menhir_stack in
      let MenhirCell0_ID (_menhir_stack, _3) = _menhir_stack in
      let MenhirCell0_LPAREN (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_LET (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _10 = _v in
      let _v = _menhir_action_85 _1 _10 _3 _5 _8 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_169 : type  ttv_stack. ((((ttv_stack, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_THEN _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_RBRACK _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_RBRACE _menhir_cell0_ELSE _menhir_cell0_LBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RBRACE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_LBRACE (_menhir_stack, _11) = _menhir_stack in
          let MenhirCell0_ELSE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_RBRACE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Term (_menhir_stack, _, _8) = _menhir_stack in
          let MenhirCell0_LBRACE (_menhir_stack, _7) = _menhir_stack in
          let MenhirCell0_RBRACK (_menhir_stack, _6) = _menhir_stack in
          let MenhirCell1_Type (_menhir_stack, _, _5) = _menhir_stack in
          let MenhirCell0_LBRACK (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_THEN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Expr (_menhir_stack, _, _2) = _menhir_stack in
          let MenhirCell1_IF (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _12 = _v in
          let _v = _menhir_action_71 _1 _11 _12 _2 _5 _6 _7 _8 in
          _menhir_goto_STerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_165 : type  ttv_stack. ((((ttv_stack, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_THEN _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_RBRACK _menhir_cell0_LBRACE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | RBRACE _v_0 ->
          let _menhir_stack = MenhirCell0_RBRACE (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | ELSE _v_1 ->
              let _menhir_stack = MenhirCell0_ELSE (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | LBRACE _v_2 ->
                  let _menhir_stack = MenhirCell0_LBRACE (_menhir_stack, _v_2) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | UNIONCASE _v_3 ->
                      _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState168
                  | STRINGV _v_4 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_4 in
                      let _v = _menhir_action_08 _1 in
                      _menhir_run_119_spec_168 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | PROJ2 _v_6 ->
                      _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState168
                  | PROJ1 _v_7 ->
                      _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState168
                  | PRIMITIVE _v_8 ->
                      _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState168
                  | LPAREN _v_9 ->
                      _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState168
                  | LET _v_10 ->
                      _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState168
                  | INR _v_11 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_11 in
                      let _v = _menhir_action_04 _1 in
                      _menhir_run_119_spec_168 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | INL _v_13 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_13 in
                      let _v = _menhir_action_03 _1 in
                      _menhir_run_119_spec_168 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | IF _v_15 ->
                      _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState168
                  | ID _v_16 ->
                      _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState168
                  | FUN _v_17 ->
                      _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState168
                  | FLOATV _v_18 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_18 in
                      let _v = _menhir_action_09 _1 in
                      _menhir_run_119_spec_168 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_168 : type  ttv_stack. ((((ttv_stack, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_THEN _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_RBRACK _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term _menhir_cell0_RBRACE _menhir_cell0_ELSE _menhir_cell0_LBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_168 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_157 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_ColType _menhir_cell0_RPAREN _menhir_cell0_MaybeType _menhir_cell0_LBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RBRACE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_LBRACE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_MaybeType (_menhir_stack, _6) = _menhir_stack in
          let MenhirCell0_RPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ColType (_menhir_stack, _4) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _3) = _menhir_stack in
          let MenhirCell0_LPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_FUN (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _8 = _v in
          let _v = _menhir_action_73 _1 _3 _4 _6 _8 in
          _menhir_goto_STerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_155 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_ID _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_SEMI -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_SEMI (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_Expr (_menhir_stack, _, _3) = _menhir_stack in
      let MenhirCell0_EQUAL (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_ID (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _5 = _v in
      let _v = _menhir_action_84 _1 _3 _5 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_140 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | OR _v_0 ->
          let _menhir_stack = MenhirCell1_LogOrTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | OF _ | SEMI _ | THEN _ ->
          let _1 = _v in
          let _v = _menhir_action_39 _1 in
          _menhir_goto_Expr _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_Expr : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState001 ->
          _menhir_run_192 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState091 ->
          _menhir_run_171 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState094 ->
          _menhir_run_159 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState108 ->
          _menhir_run_153 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_192 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Expr (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | OF _v_0 ->
          let _menhir_stack = MenhirCell0_OF (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LBRACE _v_1 ->
              let _menhir_stack = MenhirCell0_LBRACE (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | INL _v_2 ->
                  let _menhir_stack = MenhirCell0_INL (_menhir_stack, _v_2) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | LPAREN _v_3 ->
                      let _menhir_stack = MenhirCell0_LPAREN (_menhir_stack, _v_3) in
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      (match (_tok : MenhirBasics.token) with
                      | ID _v_4 ->
                          let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_4) in
                          let _tok = _menhir_lexer _menhir_lexbuf in
                          (match (_tok : MenhirBasics.token) with
                          | RPAREN _v_5 ->
                              let _menhir_stack = MenhirCell0_RPAREN (_menhir_stack, _v_5) in
                              let _tok = _menhir_lexer _menhir_lexbuf in
                              (match (_tok : MenhirBasics.token) with
                              | DBLARROW _v_6 ->
                                  let _menhir_stack = MenhirCell0_DBLARROW (_menhir_stack, _v_6) in
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  (match (_tok : MenhirBasics.token) with
                                  | UNIONCASE _v_7 ->
                                      _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState199
                                  | STRINGV _v_8 ->
                                      let _tok = _menhir_lexer _menhir_lexbuf in
                                      let _1 = _v_8 in
                                      let _v = _menhir_action_08 _1 in
                                      _menhir_run_119_spec_199 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                                  | PROJ2 _v_10 ->
                                      _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState199
                                  | PROJ1 _v_11 ->
                                      _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState199
                                  | PRIMITIVE _v_12 ->
                                      _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState199
                                  | LPAREN _v_13 ->
                                      _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState199
                                  | LET _v_14 ->
                                      _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState199
                                  | INR _v_15 ->
                                      let _tok = _menhir_lexer _menhir_lexbuf in
                                      let _1 = _v_15 in
                                      let _v = _menhir_action_04 _1 in
                                      _menhir_run_119_spec_199 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                                  | INL _v_17 ->
                                      let _tok = _menhir_lexer _menhir_lexbuf in
                                      let _1 = _v_17 in
                                      let _v = _menhir_action_03 _1 in
                                      _menhir_run_119_spec_199 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                                  | IF _v_19 ->
                                      _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState199
                                  | ID _v_20 ->
                                      _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState199
                                  | FUN _v_21 ->
                                      _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_21 MenhirState199
                                  | FLOATV _v_22 ->
                                      let _tok = _menhir_lexer _menhir_lexbuf in
                                      let _1 = _v_22 in
                                      let _v = _menhir_action_09 _1 in
                                      _menhir_run_119_spec_199 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                                  | _ ->
                                      _eRR ())
                              | _ ->
                                  _eRR ())
                          | _ ->
                              _eRR ())
                      | _ ->
                          _eRR ())
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_199 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_199 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_171 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Expr (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | SEMI _v_0 ->
          let _menhir_stack = MenhirCell0_SEMI (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState172
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_08 _1 in
              _menhir_run_119_spec_172 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | PROJ2 _v_4 ->
              _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState172
          | PROJ1 _v_5 ->
              _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState172
          | PRIMITIVE _v_6 ->
              _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState172
          | LPAREN _v_7 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState172
          | LET _v_8 ->
              _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState172
          | INR _v_9 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_9 in
              let _v = _menhir_action_04 _1 in
              _menhir_run_119_spec_172 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | INL _v_11 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_11 in
              let _v = _menhir_action_03 _1 in
              _menhir_run_119_spec_172 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | IF _v_13 ->
              _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState172
          | ID _v_14 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState172
          | FUN _v_15 ->
              _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState172
          | FLOATV _v_16 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_16 in
              let _v = _menhir_action_09 _1 in
              _menhir_run_119_spec_172 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_172 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_SEMI -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_172 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_159 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_IF as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Expr (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | THEN _v_0 ->
          let _menhir_stack = MenhirCell0_THEN (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LBRACK _v_1 ->
              let _menhir_stack = MenhirCell0_LBRACK (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | STRING _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_14 () in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState161 _tok
              | NUM _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_12 () in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState161 _tok
              | LPAREN _v_6 ->
                  _menhir_run_041 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState161
              | INT _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_13 () in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState161 _tok
              | ID _v_9 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_9 in
                  let _v = _menhir_action_11 _1 in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState161 _tok
              | FUZZY _v_11 ->
                  _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState161
              | DBSOURCE _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_16 () in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState161 _tok
              | CLIPPED _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_15 () in
                  _menhir_run_051 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState161 _tok
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_153 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_ID _menhir_cell0_EQUAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Expr (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | SEMI _v_0 ->
          let _menhir_stack = MenhirCell0_SEMI (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState154
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_08 _1 in
              _menhir_run_119_spec_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | PROJ2 _v_4 ->
              _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState154
          | PROJ1 _v_5 ->
              _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState154
          | PRIMITIVE _v_6 ->
              _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState154
          | LPAREN _v_7 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState154
          | LET _v_8 ->
              _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState154
          | INR _v_9 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_9 in
              let _v = _menhir_action_04 _1 in
              _menhir_run_119_spec_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | INL _v_11 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_11 in
              let _v = _menhir_action_03 _1 in
              _menhir_run_119_spec_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | IF _v_13 ->
              _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState154
          | ID _v_14 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState154
          | FUN _v_15 ->
              _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState154
          | FLOATV _v_16 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_16 in
              let _v = _menhir_action_09 _1 in
              _menhir_run_119_spec_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_119_spec_154 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_ID _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Expr _menhir_cell0_SEMI -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_142 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LogOrTerm _menhir_cell0_OR as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | AND _v_0 ->
          let _menhir_stack = MenhirCell1_LogAndTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | COMMA _ | EOF _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let MenhirCell0_OR (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_LogOrTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_49 _1 _2 _3 in
          _menhir_goto_LogOrTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_144 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LogAndTerm _menhir_cell0_AND as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | BEQUAL _v_0 ->
          let _menhir_stack = MenhirCell1_BequalTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_145 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | BANG _v_1 ->
          let _menhir_stack = MenhirCell1_BequalTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_148 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | AND _ | COMMA _ | EOF _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let MenhirCell0_AND (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_LogAndTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_47 _1 _2 _3 in
          _menhir_goto_LogAndTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_146 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_BequalTerm _menhir_cell0_BEQUAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | LT _v_0 ->
          let _menhir_stack = MenhirCell1_RelTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | GT _v_1 ->
          let _menhir_stack = MenhirCell1_RelTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_136 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | AND _ | BANG _ | BEQUAL _ | COMMA _ | EOF _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let MenhirCell0_BEQUAL (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_BequalTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_29 _1 _2 _3 in
          _menhir_goto_BequalTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_112 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | LT _v_0 ->
          let _menhir_stack = MenhirCell1_RelTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | GT _v_1 ->
          let _menhir_stack = MenhirCell1_RelTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_136 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | AND _ | BANG _ | BEQUAL _ | COMMA _ | EOF _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let _1 = _v in
          let _v = _menhir_action_31 _1 in
          _menhir_goto_BequalTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_139 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_GT as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | SUB _v_0 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | HAT _v_1 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | DOT _v_2 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_128 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2
      | ADD _v_3 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3
      | AND _ | BANG _ | BEQUAL _ | COMMA _ | EOF _ | GT _ | LT _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let MenhirCell0_GT (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_RelTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_67 _1 _2 _3 in
          _menhir_goto_RelTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_138 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_GT, _menhir_box_body) _menhir_cell1_EQUAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | SUB _v_0 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | HAT _v_1 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | DOT _v_2 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_128 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2
      | ADD _v_3 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3
      | AND _ | BANG _ | BEQUAL _ | COMMA _ | EOF _ | GT _ | LT _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let MenhirCell1_EQUAL (_menhir_stack, _, _) = _menhir_stack in
          let MenhirCell0_GT (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_RelTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _4 = _v in
          let _v = _menhir_action_69 _1 _2 _4 in
          _menhir_goto_RelTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_135 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_LT as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | SUB _v_0 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | HAT _v_1 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | DOT _v_2 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_128 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2
      | ADD _v_3 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3
      | AND _ | BANG _ | BEQUAL _ | COMMA _ | EOF _ | GT _ | LT _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let MenhirCell0_LT (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_RelTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_66 _1 _2 _3 in
          _menhir_goto_RelTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_123 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_RelTerm _menhir_cell0_LT, _menhir_box_body) _menhir_cell1_EQUAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | SUB _v_0 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_124 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | HAT _v_1 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | DOT _v_2 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_128 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2
      | ADD _v_3 ->
          let _menhir_stack = MenhirCell1_AddTerm (_menhir_stack, _menhir_s, _v) in
          _menhir_run_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3
      | AND _ | BANG _ | BEQUAL _ | COMMA _ | EOF _ | GT _ | LT _ | OF _ | OR _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ | THEN _ ->
          let MenhirCell1_EQUAL (_menhir_stack, _, _) = _menhir_stack in
          let MenhirCell0_LT (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_RelTerm (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _4 = _v in
          let _v = _menhir_action_68 _1 _2 _4 in
          _menhir_goto_RelTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_119_spec_179 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_179 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  let rec _menhir_run_119_spec_000 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_81 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_40 _1
      in
      let _v =
        let _1 = _v in
        _menhir_action_74 _1
      in
      let _1 = _v in
      let _v = _menhir_action_41 _1 in
      _menhir_run_122_spec_000 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  let rec _menhir_run_000 : type  ttv_stack. ttv_stack -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | STRINGV _v ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v in
          let _v = _menhir_action_08 _1 in
          _menhir_run_119_spec_000 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | PROJ2 _v ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | PROJ1 _v ->
          _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | PRIMITIVE _v ->
          _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | LPAREN _v ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | LET _v ->
          _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | INR _v ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v in
          let _v = _menhir_action_04 _1 in
          _menhir_run_119_spec_000 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | INL _v ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v in
          let _v = _menhir_action_03 _1 in
          _menhir_run_119_spec_000 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | IF _v ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | ID _v ->
          _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | FUN _v ->
          _menhir_run_096 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | FLOATV _v ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v in
          let _v = _menhir_action_09 _1 in
          _menhir_run_119_spec_000 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
end

let body =
  fun _menhir_lexer _menhir_lexbuf ->
    let _menhir_stack = () in
    let MenhirBox_body v = _menhir_run_000 _menhir_stack _menhir_lexbuf _menhir_lexer in
    v
