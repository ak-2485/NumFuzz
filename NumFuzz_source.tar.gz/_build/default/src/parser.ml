
module MenhirBasics = struct
  
  exception Error
  
  let _eRR =
    fun _s ->
      raise Error
  
  type token = 
    | UNIONCASE of (
# 103 "src/parser.mly"
       (Support.FileInfo.info)
# 15 "src/parser.ml"
  )
    | THEN of (
# 101 "src/parser.mly"
       (Support.FileInfo.info)
# 20 "src/parser.ml"
  )
    | STRINGV of (
# 111 "src/parser.mly"
       (string Support.FileInfo.withinfo)
# 25 "src/parser.ml"
  )
    | STRING of (
# 100 "src/parser.mly"
       (Support.FileInfo.info)
# 30 "src/parser.ml"
  )
    | SQRTOP of (
# 99 "src/parser.mly"
       (Support.FileInfo.info)
# 35 "src/parser.ml"
  )
    | SEMI of (
# 97 "src/parser.mly"
       (Support.FileInfo.info)
# 40 "src/parser.ml"
  )
    | RPAREN of (
# 95 "src/parser.mly"
       (Support.FileInfo.info)
# 45 "src/parser.ml"
  )
    | RND of (
# 96 "src/parser.mly"
       (Support.FileInfo.info)
# 50 "src/parser.ml"
  )
    | RET of (
# 94 "src/parser.mly"
       (Support.FileInfo.info)
# 55 "src/parser.ml"
  )
    | RBRACK of (
# 93 "src/parser.mly"
       (Support.FileInfo.info)
# 60 "src/parser.ml"
  )
    | RBRACE of (
# 92 "src/parser.mly"
       (Support.FileInfo.info)
# 65 "src/parser.ml"
  )
    | PROJ2 of (
# 91 "src/parser.mly"
       (Support.FileInfo.info)
# 70 "src/parser.ml"
  )
    | PROJ1 of (
# 90 "src/parser.mly"
       (Support.FileInfo.info)
# 75 "src/parser.ml"
  )
    | PIPE of (
# 89 "src/parser.mly"
       (Support.FileInfo.info)
# 80 "src/parser.ml"
  )
    | OF of (
# 88 "src/parser.mly"
       (Support.FileInfo.info)
# 85 "src/parser.ml"
  )
    | NUM of (
# 86 "src/parser.mly"
       (Support.FileInfo.info)
# 90 "src/parser.ml"
  )
    | MULOP of (
# 85 "src/parser.mly"
       (Support.FileInfo.info)
# 95 "src/parser.ml"
  )
    | LT of (
# 84 "src/parser.mly"
       (Support.FileInfo.info)
# 100 "src/parser.ml"
  )
    | LPAREN of (
# 83 "src/parser.mly"
       (Support.FileInfo.info)
# 105 "src/parser.ml"
  )
    | LOLLIPOP of (
# 82 "src/parser.mly"
       (Support.FileInfo.info)
# 110 "src/parser.ml"
  )
    | LET of (
# 81 "src/parser.mly"
       (Support.FileInfo.info)
# 115 "src/parser.ml"
  )
    | LBRACK of (
# 80 "src/parser.mly"
       (Support.FileInfo.info)
# 120 "src/parser.ml"
  )
    | LBRACE of (
# 79 "src/parser.mly"
       (Support.FileInfo.info)
# 125 "src/parser.ml"
  )
    | INR of (
# 78 "src/parser.mly"
       (Support.FileInfo.info)
# 130 "src/parser.ml"
  )
    | INL of (
# 76 "src/parser.mly"
       (Support.FileInfo.info)
# 135 "src/parser.ml"
  )
    | INF of (
# 77 "src/parser.mly"
       (Support.FileInfo.info)
# 140 "src/parser.ml"
  )
    | IF of (
# 75 "src/parser.mly"
       (Support.FileInfo.info)
# 145 "src/parser.ml"
  )
    | ID of (
# 107 "src/parser.mly"
       (string Support.FileInfo.withinfo)
# 150 "src/parser.ml"
  )
    | GTOP of (
# 74 "src/parser.mly"
       (Support.FileInfo.info)
# 155 "src/parser.ml"
  )
    | GT of (
# 73 "src/parser.mly"
       (Support.FileInfo.info)
# 160 "src/parser.ml"
  )
    | FUNCTION of (
# 71 "src/parser.mly"
       (Support.FileInfo.info)
# 165 "src/parser.ml"
  )
    | FUN of (
# 72 "src/parser.mly"
       (Support.FileInfo.info)
# 170 "src/parser.ml"
  )
    | FLOATV of (
# 108 "src/parser.mly"
       (float Support.FileInfo.withinfo)
# 175 "src/parser.ml"
  )
    | EQUAL of (
# 67 "src/parser.mly"
       (Support.FileInfo.info)
# 180 "src/parser.ml"
  )
    | EQOP of (
# 68 "src/parser.mly"
       (Support.FileInfo.info)
# 185 "src/parser.ml"
  )
    | EPS2 of (
# 110 "src/parser.mly"
       (float Support.FileInfo.withinfo)
# 190 "src/parser.ml"
  )
    | EPS of (
# 109 "src/parser.mly"
       (float Support.FileInfo.withinfo)
# 195 "src/parser.ml"
  )
    | EOF of (
# 69 "src/parser.mly"
       (Support.FileInfo.info)
# 200 "src/parser.ml"
  )
    | EM of (
# 66 "src/parser.mly"
       (Support.FileInfo.info)
# 205 "src/parser.ml"
  )
    | ELSE of (
# 65 "src/parser.mly"
       (Support.FileInfo.info)
# 210 "src/parser.ml"
  )
    | DIVOP of (
# 64 "src/parser.mly"
       (Support.FileInfo.info)
# 215 "src/parser.ml"
  )
    | DBLARROW of (
# 63 "src/parser.mly"
       (Support.FileInfo.info)
# 220 "src/parser.ml"
  )
    | COMMA of (
# 62 "src/parser.mly"
       (Support.FileInfo.info)
# 225 "src/parser.ml"
  )
    | COLON of (
# 61 "src/parser.mly"
       (Support.FileInfo.info)
# 230 "src/parser.ml"
  )
    | BOOL of (
# 87 "src/parser.mly"
       (Support.FileInfo.info)
# 235 "src/parser.ml"
  )
    | BANG of (
# 60 "src/parser.mly"
       (Support.FileInfo.info)
# 240 "src/parser.ml"
  )
    | AMP of (
# 59 "src/parser.mly"
       (Support.FileInfo.info)
# 245 "src/parser.ml"
  )
    | ADDOP of (
# 58 "src/parser.mly"
       (Support.FileInfo.info)
# 250 "src/parser.ml"
  )
    | ADD of (
# 57 "src/parser.mly"
       (Support.FileInfo.info)
# 255 "src/parser.ml"
  )
  
end

include MenhirBasics

# 7 "src/parser.mly"
  
open Syntax
open Support.FileInfo

let parser_error   fi = Support.Error.error_msg   Support.Options.Parser fi

  let dummy_ty  = TyPrim PrimUnit

(* look for a variable in the current context *)
let existing_var fi id ctx =
  match Ctx.lookup_var id ctx with
      None            -> parser_error fi "Identifier %s is unbound" id
    | Some (var, _bi) -> var

let existing_tyvar fi id ctx =
  match Ctx.lookup_tyvar id ctx with
      None            -> parser_error fi "Type %s is unbound" id
    | Some (var, bi)  -> (var, bi)

(* Wrap extend here in order to avoid mutually recursive
   dependencies *)
let extend_var id ctx =
  Ctx.extend_var id dummy_ty ctx


(* Create a new binder *)
let nb_var   n = {b_name = n; b_type = BiVar;  b_size = -1; b_prim = false;}

let rec list_to_term l body = match l with
    []                    -> body
  | (ty, n, i) :: tml -> TmAbs (i, nb_var n, ty, list_to_term tml body)

let from_args_to_term arg_list body = list_to_term arg_list body

let rec list_to_type l ret_ty = match l with
    []                        -> TyLollipop (TyPrim PrimUnit, ret_ty) (* Not yet allowed constant function *)
  | (ty, _n, _i) :: []    -> TyLollipop (ty, ret_ty)
  | (ty, _n, _i) :: tyl   -> TyLollipop (ty, list_to_type tyl ret_ty)

let from_args_to_type arg_list oty = match oty with
  | Some ty -> Some (list_to_type arg_list ty)
  | None -> oty



# 308 "src/parser.ml"

type ('s, 'r) _menhir_state = 
  | MenhirState000 : ('s, _menhir_box_body) _menhir_state
    (** State 000.
        Stack shape : .
        Start symbol: body. *)

  | MenhirState001 : (('s, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_state
    (** State 001.
        Stack shape : UNIONCASE.
        Start symbol: body. *)

  | MenhirState003 : (('s, _menhir_box_body) _menhir_cell1_RND, _menhir_box_body) _menhir_state
    (** State 003.
        Stack shape : RND.
        Start symbol: body. *)

  | MenhirState004 : (('s, _menhir_box_body) _menhir_cell1_RET, _menhir_box_body) _menhir_state
    (** State 004.
        Stack shape : RET.
        Start symbol: body. *)

  | MenhirState005 : (('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_state
    (** State 005.
        Stack shape : LPAREN.
        Start symbol: body. *)

  | MenhirState007 : ((('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_state
    (** State 007.
        Stack shape : LPAREN PIPE.
        Start symbol: body. *)

  | MenhirState008 : (('s, _menhir_box_body) _menhir_cell1_LBRACK, _menhir_box_body) _menhir_state
    (** State 008.
        Stack shape : LBRACK.
        Start symbol: body. *)

  | MenhirState009 : (('s, _menhir_box_body) _menhir_cell1_INR, _menhir_box_body) _menhir_state
    (** State 009.
        Stack shape : INR.
        Start symbol: body. *)

  | MenhirState010 : (('s, _menhir_box_body) _menhir_cell1_INL, _menhir_box_body) _menhir_state
    (** State 010.
        Stack shape : INL.
        Start symbol: body. *)

  | MenhirState015 : (('s, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COLON, _menhir_box_body) _menhir_state
    (** State 015.
        Stack shape : FUN LPAREN ID COLON.
        Start symbol: body. *)

  | MenhirState018 : (('s, _menhir_box_body) _menhir_cell1_LT, _menhir_box_body) _menhir_state
    (** State 018.
        Stack shape : LT.
        Start symbol: body. *)

  | MenhirState019 : (('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_state
    (** State 019.
        Stack shape : LPAREN.
        Start symbol: body. *)

  | MenhirState023 : (('s, _menhir_box_body) _menhir_cell1_EM _menhir_cell0_LBRACK, _menhir_box_body) _menhir_state
    (** State 023.
        Stack shape : EM LBRACK.
        Start symbol: body. *)

  | MenhirState024 : (('s, _menhir_box_body) _menhir_cell1_LBRACE, _menhir_box_body) _menhir_state
    (** State 024.
        Stack shape : LBRACE.
        Start symbol: body. *)

  | MenhirState034 : ((('s, _menhir_box_body) _menhir_cell1_EM _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_SensTerm _menhir_cell0_RBRACK, _menhir_box_body) _menhir_state
    (** State 034.
        Stack shape : EM LBRACK SensTerm RBRACK.
        Start symbol: body. *)

  | MenhirState037 : (('s, _menhir_box_body) _menhir_cell1_BANG _menhir_cell0_LBRACK, _menhir_box_body) _menhir_state
    (** State 037.
        Stack shape : BANG LBRACK.
        Start symbol: body. *)

  | MenhirState039 : ((('s, _menhir_box_body) _menhir_cell1_BANG _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_SensTerm _menhir_cell0_RBRACK, _menhir_box_body) _menhir_state
    (** State 039.
        Stack shape : BANG LBRACK SensTerm RBRACK.
        Start symbol: body. *)

  | MenhirState043 : (('s, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_LOLLIPOP, _menhir_box_body) _menhir_state
    (** State 043.
        Stack shape : AType LOLLIPOP.
        Start symbol: body. *)

  | MenhirState045 : (('s, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_AMP, _menhir_box_body) _menhir_state
    (** State 045.
        Stack shape : AType AMP.
        Start symbol: body. *)

  | MenhirState047 : (('s, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_ADD, _menhir_box_body) _menhir_state
    (** State 047.
        Stack shape : AType ADD.
        Start symbol: body. *)

  | MenhirState052 : (('s, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA, _menhir_box_body) _menhir_state
    (** State 052.
        Stack shape : Type COMMA.
        Start symbol: body. *)

  | MenhirState058 : ((('s, _menhir_box_body) _menhir_cell1_LT, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA, _menhir_box_body) _menhir_state
    (** State 058.
        Stack shape : LT Type COMMA.
        Start symbol: body. *)

  | MenhirState064 : (('s, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_ColType _menhir_cell0_RPAREN _menhir_cell0_LBRACE, _menhir_box_body) _menhir_state
    (** State 064.
        Stack shape : FUN LPAREN ID ColType RPAREN LBRACE.
        Start symbol: body. *)

  | MenhirState065 : (('s, _menhir_box_body) _menhir_cell1_SQRTOP, _menhir_box_body) _menhir_state
    (** State 065.
        Stack shape : SQRTOP.
        Start symbol: body. *)

  | MenhirState068 : (('s, _menhir_box_body) _menhir_cell1_PROJ2, _menhir_box_body) _menhir_state
    (** State 068.
        Stack shape : PROJ2.
        Start symbol: body. *)

  | MenhirState070 : (('s, _menhir_box_body) _menhir_cell1_PROJ1, _menhir_box_body) _menhir_state
    (** State 070.
        Stack shape : PROJ1.
        Start symbol: body. *)

  | MenhirState072 : (('s, _menhir_box_body) _menhir_cell1_MULOP, _menhir_box_body) _menhir_state
    (** State 072.
        Stack shape : MULOP.
        Start symbol: body. *)

  | MenhirState074 : (('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_state
    (** State 074.
        Stack shape : LPAREN.
        Start symbol: body. *)

  | MenhirState081 : (('s, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL, _menhir_box_body) _menhir_state
    (** State 081.
        Stack shape : LET LPAREN ID COMMA ID RPAREN EQUAL.
        Start symbol: body. *)

  | MenhirState083 : ((('s, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_SEMI, _menhir_box_body) _menhir_state
    (** State 083.
        Stack shape : LET LPAREN ID COMMA ID RPAREN EQUAL Val SEMI.
        Start symbol: body. *)

  | MenhirState084 : (('s, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_state
    (** State 084.
        Stack shape : IF.
        Start symbol: body. *)

  | MenhirState087 : ((('s, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_THEN _menhir_cell0_LBRACE, _menhir_box_body) _menhir_state
    (** State 087.
        Stack shape : IF Val THEN LBRACE.
        Start symbol: body. *)

  | MenhirState088 : (('s, _menhir_box_body) _menhir_cell1_ID, _menhir_box_body) _menhir_state
    (** State 088.
        Stack shape : ID.
        Start symbol: body. *)

  | MenhirState089 : (('s, _menhir_box_body) _menhir_cell1_COLON, _menhir_box_body) _menhir_state
    (** State 089.
        Stack shape : COLON.
        Start symbol: body. *)

  | MenhirState092 : ((('s, _menhir_box_body) _menhir_cell1_ID, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_EQUAL, _menhir_box_body) _menhir_state
    (** State 092.
        Stack shape : ID MaybeType EQUAL.
        Start symbol: body. *)

  | MenhirState093 : (('s, _menhir_box_body) _menhir_cell1_GTOP, _menhir_box_body) _menhir_state
    (** State 093.
        Stack shape : GTOP.
        Start symbol: body. *)

  | MenhirState096 : (('s, _menhir_box_body) _menhir_cell1_FUNCTION _menhir_cell0_ID, _menhir_box_body) _menhir_state
    (** State 096.
        Stack shape : FUNCTION ID.
        Start symbol: body. *)

  | MenhirState099 : (('s, _menhir_box_body) _menhir_cell1_LPAREN _menhir_cell0_ID _menhir_cell0_COLON, _menhir_box_body) _menhir_state
    (** State 099.
        Stack shape : LPAREN ID COLON.
        Start symbol: body. *)

  | MenhirState102 : ((('s, _menhir_box_body) _menhir_cell1_FUNCTION _menhir_cell0_ID, _menhir_box_body) _menhir_cell1_Arguments, _menhir_box_body) _menhir_state
    (** State 102.
        Stack shape : FUNCTION ID Arguments.
        Start symbol: body. *)

  | MenhirState104 : (((('s, _menhir_box_body) _menhir_cell1_FUNCTION _menhir_cell0_ID, _menhir_box_body) _menhir_cell1_Arguments, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_LBRACE, _menhir_box_body) _menhir_state
    (** State 104.
        Stack shape : FUNCTION ID Arguments MaybeType LBRACE.
        Start symbol: body. *)

  | MenhirState105 : (('s, _menhir_box_body) _menhir_cell1_EQOP, _menhir_box_body) _menhir_state
    (** State 105.
        Stack shape : EQOP.
        Start symbol: body. *)

  | MenhirState107 : (('s, _menhir_box_body) _menhir_cell1_DIVOP, _menhir_box_body) _menhir_state
    (** State 107.
        Stack shape : DIVOP.
        Start symbol: body. *)

  | MenhirState109 : (('s, _menhir_box_body) _menhir_cell1_ADDOP, _menhir_box_body) _menhir_state
    (** State 109.
        Stack shape : ADDOP.
        Start symbol: body. *)

  | MenhirState111 : (('s, _menhir_box_body) _menhir_cell1_Val, _menhir_box_body) _menhir_state
    (** State 111.
        Stack shape : Val.
        Start symbol: body. *)

  | MenhirState113 : ((((('s, _menhir_box_body) _menhir_cell1_FUNCTION _menhir_cell0_ID, _menhir_box_body) _menhir_cell1_Arguments, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 113.
        Stack shape : FUNCTION ID Arguments MaybeType LBRACE Term.
        Start symbol: body. *)

  | MenhirState114 : (((((('s, _menhir_box_body) _menhir_cell1_FUNCTION _menhir_cell0_ID, _menhir_box_body) _menhir_cell1_Arguments, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_RBRACE, _menhir_box_body) _menhir_state
    (** State 114.
        Stack shape : FUNCTION ID Arguments MaybeType LBRACE Term RBRACE.
        Start symbol: body. *)

  | MenhirState115 : ((((((('s, _menhir_box_body) _menhir_cell1_FUNCTION _menhir_cell0_ID, _menhir_box_body) _menhir_cell1_Arguments, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_RBRACE, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 115.
        Stack shape : FUNCTION ID Arguments MaybeType LBRACE Term RBRACE Term.
        Start symbol: body. *)

  | MenhirState117 : (('s, _menhir_box_body) _menhir_cell1_Argument, _menhir_box_body) _menhir_state
    (** State 117.
        Stack shape : Argument.
        Start symbol: body. *)

  | MenhirState119 : (((('s, _menhir_box_body) _menhir_cell1_ID, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 119.
        Stack shape : ID MaybeType EQUAL Term.
        Start symbol: body. *)

  | MenhirState120 : ((((('s, _menhir_box_body) _menhir_cell1_ID, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_SEMI, _menhir_box_body) _menhir_state
    (** State 120.
        Stack shape : ID MaybeType EQUAL Term SEMI.
        Start symbol: body. *)

  | MenhirState121 : (((((('s, _menhir_box_body) _menhir_cell1_ID, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_SEMI, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 121.
        Stack shape : ID MaybeType EQUAL Term SEMI Term.
        Start symbol: body. *)

  | MenhirState122 : (((('s, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_THEN _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 122.
        Stack shape : IF Val THEN LBRACE Term.
        Start symbol: body. *)

  | MenhirState125 : ((((('s, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_THEN _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_RBRACE _menhir_cell0_ELSE _menhir_cell0_LBRACE, _menhir_box_body) _menhir_state
    (** State 125.
        Stack shape : IF Val THEN LBRACE Term RBRACE ELSE LBRACE.
        Start symbol: body. *)

  | MenhirState126 : (((((('s, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_THEN _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_RBRACE _menhir_cell0_ELSE _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 126.
        Stack shape : IF Val THEN LBRACE Term RBRACE ELSE LBRACE Term.
        Start symbol: body. *)

  | MenhirState128 : (((('s, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_SEMI, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 128.
        Stack shape : LET LPAREN ID COMMA ID RPAREN EQUAL Val SEMI Term.
        Start symbol: body. *)

  | MenhirState132 : (('s, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LBRACK _menhir_cell0_ID _menhir_cell0_RBRACK _menhir_cell0_EQUAL, _menhir_box_body) _menhir_state
    (** State 132.
        Stack shape : LET LBRACK ID RBRACK EQUAL.
        Start symbol: body. *)

  | MenhirState134 : ((('s, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LBRACK _menhir_cell0_ID _menhir_cell0_RBRACK _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_SEMI, _menhir_box_body) _menhir_state
    (** State 134.
        Stack shape : LET LBRACK ID RBRACK EQUAL Val SEMI.
        Start symbol: body. *)

  | MenhirState135 : (((('s, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LBRACK _menhir_cell0_ID _menhir_cell0_RBRACK _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_SEMI, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 135.
        Stack shape : LET LBRACK ID RBRACK EQUAL Val SEMI Term.
        Start symbol: body. *)

  | MenhirState137 : (('s, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_ID _menhir_cell0_EQUAL, _menhir_box_body) _menhir_state
    (** State 137.
        Stack shape : LET ID EQUAL.
        Start symbol: body. *)

  | MenhirState139 : ((('s, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_ID _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_SEMI, _menhir_box_body) _menhir_state
    (** State 139.
        Stack shape : LET ID EQUAL Val SEMI.
        Start symbol: body. *)

  | MenhirState140 : (((('s, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_ID _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_SEMI, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 140.
        Stack shape : LET ID EQUAL Val SEMI Term.
        Start symbol: body. *)

  | MenhirState141 : ((('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_Val, _menhir_box_body) _menhir_state
    (** State 141.
        Stack shape : LPAREN Val.
        Start symbol: body. *)

  | MenhirState143 : ((('s, _menhir_box_body) _menhir_cell1_Val, _menhir_box_body) _menhir_cell1_COMMA, _menhir_box_body) _menhir_state
    (** State 143.
        Stack shape : Val COMMA.
        Start symbol: body. *)

  | MenhirState144 : (((('s, _menhir_box_body) _menhir_cell1_Val, _menhir_box_body) _menhir_cell1_COMMA, _menhir_box_body) _menhir_cell1_Val, _menhir_box_body) _menhir_state
    (** State 144.
        Stack shape : Val COMMA Val.
        Start symbol: body. *)

  | MenhirState146 : ((('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 146.
        Stack shape : LPAREN Term.
        Start symbol: body. *)

  | MenhirState150 : ((('s, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_ColType _menhir_cell0_RPAREN _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 150.
        Stack shape : FUN LPAREN ID ColType RPAREN LBRACE Term.
        Start symbol: body. *)

  | MenhirState154 : ((('s, _menhir_box_body) _menhir_cell1_LBRACK, _menhir_box_body) _menhir_cell1_Val, _menhir_box_body) _menhir_state
    (** State 154.
        Stack shape : LBRACK Val.
        Start symbol: body. *)

  | MenhirState158 : (((('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_COMMA, _menhir_box_body) _menhir_state
    (** State 158.
        Stack shape : LPAREN PIPE Val COMMA.
        Start symbol: body. *)

  | MenhirState162 : ((('s, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_Val, _menhir_box_body) _menhir_state
    (** State 162.
        Stack shape : LPAREN Val.
        Start symbol: body. *)

  | MenhirState172 : ((('s, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_state
    (** State 172.
        Stack shape : UNIONCASE Val OF LBRACE INL LPAREN ID RPAREN DBLARROW.
        Start symbol: body. *)

  | MenhirState173 : (((('s, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 173.
        Stack shape : UNIONCASE Val OF LBRACE INL LPAREN ID RPAREN DBLARROW Term.
        Start symbol: body. *)

  | MenhirState179 : ((((('s, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_PIPE _menhir_cell0_INR _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_state
    (** State 179.
        Stack shape : UNIONCASE Val OF LBRACE INL LPAREN ID RPAREN DBLARROW Term PIPE INR LPAREN ID RPAREN DBLARROW.
        Start symbol: body. *)

  | MenhirState180 : (((((('s, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_PIPE _menhir_cell0_INR _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 180.
        Stack shape : UNIONCASE Val OF LBRACE INL LPAREN ID RPAREN DBLARROW Term PIPE INR LPAREN ID RPAREN DBLARROW Term.
        Start symbol: body. *)

  | MenhirState183 : (('s, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_state
    (** State 183.
        Stack shape : Term.
        Start symbol: body. *)


and ('s, 'r) _menhir_cell1_AType = 
  | MenhirCell1_AType of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.ty)

and ('s, 'r) _menhir_cell1_Argument = 
  | MenhirCell1_Argument of 's * ('s, 'r) _menhir_state * (Ctx.context ->
  (Syntax.ty * string * Support.FileInfo.info) list * Ctx.context)

and ('s, 'r) _menhir_cell1_Arguments = 
  | MenhirCell1_Arguments of 's * ('s, 'r) _menhir_state * (Ctx.context ->
  (Syntax.ty * string * Support.FileInfo.info) list * Ctx.context)

and 's _menhir_cell0_ColType = 
  | MenhirCell0_ColType of 's * (Ctx.context -> Syntax.ty)

and ('s, 'r) _menhir_cell1_MaybeType = 
  | MenhirCell1_MaybeType of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.ty option)

and ('s, 'r) _menhir_cell1_SensTerm = 
  | MenhirCell1_SensTerm of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.si)

and ('s, 'r) _menhir_cell1_Term = 
  | MenhirCell1_Term of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.term)

and ('s, 'r) _menhir_cell1_Type = 
  | MenhirCell1_Type of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.ty)

and ('s, 'r) _menhir_cell1_Val = 
  | MenhirCell1_Val of 's * ('s, 'r) _menhir_state * (Ctx.context -> Syntax.term)

and 's _menhir_cell0_ADD = 
  | MenhirCell0_ADD of 's * (
# 57 "src/parser.mly"
       (Support.FileInfo.info)
# 715 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_ADDOP = 
  | MenhirCell1_ADDOP of 's * ('s, 'r) _menhir_state * (
# 58 "src/parser.mly"
       (Support.FileInfo.info)
# 722 "src/parser.ml"
)

and 's _menhir_cell0_AMP = 
  | MenhirCell0_AMP of 's * (
# 59 "src/parser.mly"
       (Support.FileInfo.info)
# 729 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_BANG = 
  | MenhirCell1_BANG of 's * ('s, 'r) _menhir_state * (
# 60 "src/parser.mly"
       (Support.FileInfo.info)
# 736 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_COLON = 
  | MenhirCell1_COLON of 's * ('s, 'r) _menhir_state * (
# 61 "src/parser.mly"
       (Support.FileInfo.info)
# 743 "src/parser.ml"
)

and 's _menhir_cell0_COLON = 
  | MenhirCell0_COLON of 's * (
# 61 "src/parser.mly"
       (Support.FileInfo.info)
# 750 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_COMMA = 
  | MenhirCell1_COMMA of 's * ('s, 'r) _menhir_state * (
# 62 "src/parser.mly"
       (Support.FileInfo.info)
# 757 "src/parser.ml"
)

and 's _menhir_cell0_COMMA = 
  | MenhirCell0_COMMA of 's * (
# 62 "src/parser.mly"
       (Support.FileInfo.info)
# 764 "src/parser.ml"
)

and 's _menhir_cell0_DBLARROW = 
  | MenhirCell0_DBLARROW of 's * (
# 63 "src/parser.mly"
       (Support.FileInfo.info)
# 771 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_DIVOP = 
  | MenhirCell1_DIVOP of 's * ('s, 'r) _menhir_state * (
# 64 "src/parser.mly"
       (Support.FileInfo.info)
# 778 "src/parser.ml"
)

and 's _menhir_cell0_ELSE = 
  | MenhirCell0_ELSE of 's * (
# 65 "src/parser.mly"
       (Support.FileInfo.info)
# 785 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_EM = 
  | MenhirCell1_EM of 's * ('s, 'r) _menhir_state * (
# 66 "src/parser.mly"
       (Support.FileInfo.info)
# 792 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_EQOP = 
  | MenhirCell1_EQOP of 's * ('s, 'r) _menhir_state * (
# 68 "src/parser.mly"
       (Support.FileInfo.info)
# 799 "src/parser.ml"
)

and 's _menhir_cell0_EQUAL = 
  | MenhirCell0_EQUAL of 's * (
# 67 "src/parser.mly"
       (Support.FileInfo.info)
# 806 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_FUN = 
  | MenhirCell1_FUN of 's * ('s, 'r) _menhir_state * (
# 72 "src/parser.mly"
       (Support.FileInfo.info)
# 813 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_FUNCTION = 
  | MenhirCell1_FUNCTION of 's * ('s, 'r) _menhir_state * (
# 71 "src/parser.mly"
       (Support.FileInfo.info)
# 820 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_GTOP = 
  | MenhirCell1_GTOP of 's * ('s, 'r) _menhir_state * (
# 74 "src/parser.mly"
       (Support.FileInfo.info)
# 827 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_ID = 
  | MenhirCell1_ID of 's * ('s, 'r) _menhir_state * (
# 107 "src/parser.mly"
       (string Support.FileInfo.withinfo)
# 834 "src/parser.ml"
)

and 's _menhir_cell0_ID = 
  | MenhirCell0_ID of 's * (
# 107 "src/parser.mly"
       (string Support.FileInfo.withinfo)
# 841 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_IF = 
  | MenhirCell1_IF of 's * ('s, 'r) _menhir_state * (
# 75 "src/parser.mly"
       (Support.FileInfo.info)
# 848 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_INL = 
  | MenhirCell1_INL of 's * ('s, 'r) _menhir_state * (
# 76 "src/parser.mly"
       (Support.FileInfo.info)
# 855 "src/parser.ml"
)

and 's _menhir_cell0_INL = 
  | MenhirCell0_INL of 's * (
# 76 "src/parser.mly"
       (Support.FileInfo.info)
# 862 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_INR = 
  | MenhirCell1_INR of 's * ('s, 'r) _menhir_state * (
# 78 "src/parser.mly"
       (Support.FileInfo.info)
# 869 "src/parser.ml"
)

and 's _menhir_cell0_INR = 
  | MenhirCell0_INR of 's * (
# 78 "src/parser.mly"
       (Support.FileInfo.info)
# 876 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_LBRACE = 
  | MenhirCell1_LBRACE of 's * ('s, 'r) _menhir_state * (
# 79 "src/parser.mly"
       (Support.FileInfo.info)
# 883 "src/parser.ml"
)

and 's _menhir_cell0_LBRACE = 
  | MenhirCell0_LBRACE of 's * (
# 79 "src/parser.mly"
       (Support.FileInfo.info)
# 890 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_LBRACK = 
  | MenhirCell1_LBRACK of 's * ('s, 'r) _menhir_state * (
# 80 "src/parser.mly"
       (Support.FileInfo.info)
# 897 "src/parser.ml"
)

and 's _menhir_cell0_LBRACK = 
  | MenhirCell0_LBRACK of 's * (
# 80 "src/parser.mly"
       (Support.FileInfo.info)
# 904 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_LET = 
  | MenhirCell1_LET of 's * ('s, 'r) _menhir_state * (
# 81 "src/parser.mly"
       (Support.FileInfo.info)
# 911 "src/parser.ml"
)

and 's _menhir_cell0_LOLLIPOP = 
  | MenhirCell0_LOLLIPOP of 's * (
# 82 "src/parser.mly"
       (Support.FileInfo.info)
# 918 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_LPAREN = 
  | MenhirCell1_LPAREN of 's * ('s, 'r) _menhir_state * (
# 83 "src/parser.mly"
       (Support.FileInfo.info)
# 925 "src/parser.ml"
)

and 's _menhir_cell0_LPAREN = 
  | MenhirCell0_LPAREN of 's * (
# 83 "src/parser.mly"
       (Support.FileInfo.info)
# 932 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_LT = 
  | MenhirCell1_LT of 's * ('s, 'r) _menhir_state * (
# 84 "src/parser.mly"
       (Support.FileInfo.info)
# 939 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_MULOP = 
  | MenhirCell1_MULOP of 's * ('s, 'r) _menhir_state * (
# 85 "src/parser.mly"
       (Support.FileInfo.info)
# 946 "src/parser.ml"
)

and 's _menhir_cell0_OF = 
  | MenhirCell0_OF of 's * (
# 88 "src/parser.mly"
       (Support.FileInfo.info)
# 953 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_PIPE = 
  | MenhirCell1_PIPE of 's * ('s, 'r) _menhir_state * (
# 89 "src/parser.mly"
       (Support.FileInfo.info)
# 960 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_PROJ1 = 
  | MenhirCell1_PROJ1 of 's * ('s, 'r) _menhir_state * (
# 90 "src/parser.mly"
       (Support.FileInfo.info)
# 967 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_PROJ2 = 
  | MenhirCell1_PROJ2 of 's * ('s, 'r) _menhir_state * (
# 91 "src/parser.mly"
       (Support.FileInfo.info)
# 974 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_RBRACE = 
  | MenhirCell1_RBRACE of 's * ('s, 'r) _menhir_state * (
# 92 "src/parser.mly"
       (Support.FileInfo.info)
# 981 "src/parser.ml"
)

and 's _menhir_cell0_RBRACK = 
  | MenhirCell0_RBRACK of 's * (
# 93 "src/parser.mly"
       (Support.FileInfo.info)
# 988 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_RET = 
  | MenhirCell1_RET of 's * ('s, 'r) _menhir_state * (
# 94 "src/parser.mly"
       (Support.FileInfo.info)
# 995 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_RND = 
  | MenhirCell1_RND of 's * ('s, 'r) _menhir_state * (
# 96 "src/parser.mly"
       (Support.FileInfo.info)
# 1002 "src/parser.ml"
)

and 's _menhir_cell0_RPAREN = 
  | MenhirCell0_RPAREN of 's * (
# 95 "src/parser.mly"
       (Support.FileInfo.info)
# 1009 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_SEMI = 
  | MenhirCell1_SEMI of 's * ('s, 'r) _menhir_state * (
# 97 "src/parser.mly"
       (Support.FileInfo.info)
# 1016 "src/parser.ml"
)

and 's _menhir_cell0_SEMI = 
  | MenhirCell0_SEMI of 's * (
# 97 "src/parser.mly"
       (Support.FileInfo.info)
# 1023 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_SQRTOP = 
  | MenhirCell1_SQRTOP of 's * ('s, 'r) _menhir_state * (
# 99 "src/parser.mly"
       (Support.FileInfo.info)
# 1030 "src/parser.ml"
)

and 's _menhir_cell0_THEN = 
  | MenhirCell0_THEN of 's * (
# 101 "src/parser.mly"
       (Support.FileInfo.info)
# 1037 "src/parser.ml"
)

and ('s, 'r) _menhir_cell1_UNIONCASE = 
  | MenhirCell1_UNIONCASE of 's * ('s, 'r) _menhir_state * (
# 103 "src/parser.mly"
       (Support.FileInfo.info)
# 1044 "src/parser.ml"
)

and _menhir_box_body = 
  | MenhirBox_body of (Syntax.term) [@@unboxed]

let _menhir_action_01 =
  fun _2 ->
    (
# 329 "src/parser.mly"
      ( _2 )
# 1055 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_02 =
  fun _1 ->
    (
# 331 "src/parser.mly"
      (	fun ctx -> let (v, _) = existing_tyvar _1.i _1.v ctx in
                   TyVar v
      )
# 1065 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_03 =
  fun () ->
    (
# 335 "src/parser.mly"
      ( fun _cx -> TyPrim PrimNum )
# 1073 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_04 =
  fun () ->
    (
# 337 "src/parser.mly"
      ( fun _cx -> TyUnion(TyPrim PrimUnit, TyPrim PrimUnit) )
# 1081 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_05 =
  fun () ->
    (
# 339 "src/parser.mly"
      ( fun _cx -> TyPrim PrimString )
# 1089 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_06 =
  fun () ->
    (
# 341 "src/parser.mly"
      ( fun _cx -> TyPrim PrimUnit )
# 1097 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_07 =
  fun _3 _5 ->
    (
# 343 "src/parser.mly"
      ( fun ctx -> TyBang (_3 ctx, _5 ctx) )
# 1105 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_08 =
  fun _3 _5 ->
    (
# 345 "src/parser.mly"
      ( fun ctx -> TyMonad (_3 ctx, _5 ctx) )
# 1113 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_09 =
  fun _2 ->
    (
# 347 "src/parser.mly"
      ( fun ctx -> _2 ctx )
# 1121 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_10 =
  fun _2 _4 ->
    (
# 349 "src/parser.mly"
      ( fun ctx -> TyAmpersand(_2 ctx, _4 ctx) )
# 1129 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_11 =
  fun _2 _4 ->
    (
# 218 "src/parser.mly"
      ( fun ctx -> ([(_4 ctx, _2.v, _2.i)], extend_var _2.v ctx) )
# 1137 "src/parser.ml"
     : (Ctx.context ->
  (Syntax.ty * string * Support.FileInfo.info) list * Ctx.context))

let _menhir_action_12 =
  fun _1 ->
    (
# 223 "src/parser.mly"
      ( _1 )
# 1146 "src/parser.ml"
     : (Ctx.context ->
  (Syntax.ty * string * Support.FileInfo.info) list * Ctx.context))

let _menhir_action_13 =
  fun _1 _2 ->
    (
# 225 "src/parser.mly"
      ( fun ctx ->
          let (l,  ctx')  = _1 ctx in
          let (l2, ctx'') = _2 ctx' in
          (l @ l2, ctx'')
      )
# 1159 "src/parser.ml"
     : (Ctx.context ->
  (Syntax.ty * string * Support.FileInfo.info) list * Ctx.context))

let _menhir_action_14 =
  fun _2 ->
    (
# 305 "src/parser.mly"
      ( fun ctx -> (_2 ctx) )
# 1168 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_15 =
  fun _1 _3 ->
    (
# 313 "src/parser.mly"
      ( fun ctx -> TyUnion(_1 ctx, _3 ctx) )
# 1176 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_16 =
  fun _1 _3 ->
    (
# 315 "src/parser.mly"
      ( fun ctx -> TyAmpersand(_1 ctx, _3 ctx) )
# 1184 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_17 =
  fun _1 _3 ->
    (
# 317 "src/parser.mly"
      ( fun ctx -> TyLollipop(_1 ctx, _3 ctx) )
# 1192 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_18 =
  fun _1 ->
    (
# 319 "src/parser.mly"
      ( _1 )
# 1200 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_19 =
  fun () ->
    (
# 292 "src/parser.mly"
    (fun _ctx -> None)
# 1208 "src/parser.ml"
     : (Ctx.context -> Syntax.ty option))

let _menhir_action_20 =
  fun _2 ->
    (
# 294 "src/parser.mly"
      (fun ctx -> Some (_2 ctx))
# 1216 "src/parser.ml"
     : (Ctx.context -> Syntax.ty option))

let _menhir_action_21 =
  fun _1 _2 _3 ->
    (
# 234 "src/parser.mly"
      ( fun ctx -> TmTens(_2, _1 ctx, _3 ctx)  )
# 1224 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_22 =
  fun _1 _2 _3 ->
    (
# 236 "src/parser.mly"
      ( fun ctx -> TmTens(_2, _1 ctx, _3 ctx)  )
# 1232 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_23 =
  fun _1 ->
    (
# 279 "src/parser.mly"
      ( fun ctx ->
        let (v, _k) = existing_tyvar _1.i _1.v ctx in SiVar v
      )
# 1242 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_24 =
  fun _1 ->
    (
# 283 "src/parser.mly"
      ( fun _cx -> SiConst ( _1.v) )
# 1250 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_25 =
  fun () ->
    (
# 285 "src/parser.mly"
      ( fun _cx -> SiInfty  )
# 1258 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_26 =
  fun _1 ->
    (
# 287 "src/parser.mly"
      ( fun _cx -> SiConst ( _1.v) )
# 1266 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_27 =
  fun _1 ->
    (
# 289 "src/parser.mly"
      ( fun _cx -> SiConst ( _1.v) )
# 1274 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_28 =
  fun _2 ->
    (
# 273 "src/parser.mly"
      ( fun ctx -> _2 ctx)
# 1282 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_29 =
  fun _1 ->
    (
# 275 "src/parser.mly"
      ( _1 )
# 1290 "src/parser.ml"
     : (Ctx.context -> Syntax.si))

let _menhir_action_30 =
  fun _1 _3 ->
    (
# 323 "src/parser.mly"
      ( fun ctx -> TyTensor(_1 ctx, _3 ctx) )
# 1298 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_31 =
  fun _1 _3 ->
    (
# 325 "src/parser.mly"
      ( fun ctx -> TyTensor(_1 ctx, _3 ctx) )
# 1306 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_32 =
  fun _1 ->
    (
# 132 "src/parser.mly"
      ( _1 )
# 1314 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_33 =
  fun _1 _2 ->
    (
# 135 "src/parser.mly"
      ( fun ctx ->
        let e1 = _1 ctx in
        let e2 = _2 ctx in
        TmApp(tmInfo e1, e1, e2)
      )
# 1326 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_34 =
  fun _1 _2 ->
    (
# 142 "src/parser.mly"
      ( fun ctx -> TmAmp1(_1, _2 ctx))
# 1334 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_35 =
  fun _1 _2 ->
    (
# 144 "src/parser.mly"
      ( fun ctx -> TmAmp2(_1, _2 ctx))
# 1342 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_36 =
  fun _1 _10 _3 _5 _8 ->
    (
# 147 "src/parser.mly"
      ( fun ctx ->
        let ctx_x  = extend_var _3.v ctx   in
        let ctx_xy = extend_var _5.v ctx_x in
        TmTensDest(_1, (nb_var _3.v), (nb_var _5.v), _8 ctx, _10 ctx_xy)
      )
# 1354 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_37 =
  fun _1 _10 _14 _17 _2 _7 ->
    (
# 154 "src/parser.mly"
      ( fun ctx ->
        let ctx_l = extend_var _7.v  ctx in
        let ctx_r = extend_var _14.v ctx in
        TmUnionCase(_1, _2 ctx, nb_var _7.v, _10 ctx_l, nb_var  _14.v, _17 ctx_r) )
# 1365 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_38 =
  fun _1 _2 _5 _9 ->
    (
# 160 "src/parser.mly"
      ( fun ctx ->
        let ctx_l = extend_var "unit" ctx in
        let ctx_r = extend_var "unit" ctx in
        TmUnionCase(_1, _2 ctx, nb_var "unit" , _5 ctx_l, nb_var "unit" , _9 ctx_r)
      )
# 1377 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_39 =
  fun _1 _3 _6 _8 ->
    (
# 167 "src/parser.mly"
      ( fun ctx ->
        let ctx_x  = extend_var _3.v ctx   in
        TmBoxDest(_1, (nb_var _3.v), _6 ctx, _8 ctx_x)
      )
# 1388 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_40 =
  fun _2 _4 _6 ->
    (
# 173 "src/parser.mly"
      ( fun ctx ->
        let ctx' = extend_var _2.v ctx in
        TmLetBind(_2.i, (nb_var _2.v), _4 ctx, _6 ctx')
      )
# 1399 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_41 =
  fun _1 _2 _4 _6 ->
    (
# 179 "src/parser.mly"
      ( fun ctx ->
        let ctx' = extend_var _1.v ctx in
        TmLet(_1.i, nb_var _1.v, _2 ctx, _4 ctx, _6 ctx')
      )
# 1410 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_42 =
  fun _2 _3 _4 _6 _8 ->
    (
# 185 "src/parser.mly"
      ( fun ctx ->
        let (args, ctx_args) = _3 ctx                 in
        let ctx_let          = extend_var _2.v ctx    in
        let f_term           = from_args_to_term args (_6 ctx_args) in
        let f_type           = from_args_to_type args (_4 ctx_args) in
        TmLet(_2.i, nb_var _2.v, f_type , f_term, _8 ctx_let)
      )
# 1424 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_43 =
  fun _1 _2 ->
    (
# 194 "src/parser.mly"
      ( fun ctx -> TmOp(_1, AddOp, _2 ctx) )
# 1432 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_44 =
  fun _1 _2 ->
    (
# 196 "src/parser.mly"
      ( fun ctx -> TmOp(_1, MulOp, _2 ctx) )
# 1440 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_45 =
  fun _1 _2 ->
    (
# 198 "src/parser.mly"
      ( fun ctx -> TmOp(_1, DivOp, _2 ctx) )
# 1448 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_46 =
  fun _1 _2 ->
    (
# 200 "src/parser.mly"
      ( fun ctx -> TmOp(_1, SqrtOp, _2 ctx) )
# 1456 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_47 =
  fun _1 _2 ->
    (
# 202 "src/parser.mly"
      ( fun ctx -> TmOp(_1, GtOp, _2 ctx) )
# 1464 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_48 =
  fun _1 _2 ->
    (
# 204 "src/parser.mly"
      ( fun ctx -> TmOp(_1, EqOp, _2 ctx) )
# 1472 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_49 =
  fun _1 _2 ->
    (
# 207 "src/parser.mly"
      ( fun ctx ->
        let e1 = _1 ctx in
        let e2 = _2 ctx in
        TmApp(tmInfo e1, e1, e2)
      )
# 1484 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_50 =
  fun _2 ->
    (
# 214 "src/parser.mly"
    ( _2 )
# 1492 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_51 =
  fun _1 ->
    (
# 309 "src/parser.mly"
      ( _1 )
# 1500 "src/parser.ml"
     : (Ctx.context -> Syntax.ty))

let _menhir_action_52 =
  fun _1 ->
    (
# 240 "src/parser.mly"
      ( fun _cx -> TmPrim (_1, PrimTUnit) )
# 1508 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_53 =
  fun _1 ->
    (
# 242 "src/parser.mly"
      ( fun ctx -> TmVar(_1.i, existing_var _1.i _1.v ctx) )
# 1516 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_54 =
  fun _1 _2 ->
    (
# 244 "src/parser.mly"
      ( fun ctx -> TmInl(_1, _2 ctx)  )
# 1524 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_55 =
  fun _1 _2 ->
    (
# 246 "src/parser.mly"
      ( fun ctx -> TmInr(_1, _2 ctx)  )
# 1532 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_56 =
  fun _2 ->
    (
# 248 "src/parser.mly"
      ( fun ctx -> _2 ctx )
# 1540 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_57 =
  fun _1 _3 _5 ->
    (
# 250 "src/parser.mly"
      ( fun ctx -> TmAmpersand(_1, _3 ctx, _5 ctx) )
# 1548 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_58 =
  fun _1 _2 _3 ->
    (
# 252 "src/parser.mly"
      ( fun ctx -> TmBox(_1, _3 ctx, _2 ctx) )
# 1556 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_59 =
  fun _1 _2 ->
    (
# 254 "src/parser.mly"
      ( fun ctx -> TmRnd(_1, _2 ctx) )
# 1564 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_60 =
  fun _1 _2 ->
    (
# 256 "src/parser.mly"
      ( fun ctx -> TmRet(_1, _2 ctx) )
# 1572 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_61 =
  fun _1 _3 _4 _7 ->
    (
# 258 "src/parser.mly"
      (
        fun ctx -> TmAbs(_1, nb_var _3.v, _4 ctx, _7 (extend_var _3.v ctx ))
      )
# 1582 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_62 =
  fun _1 ->
    (
# 262 "src/parser.mly"
      ( fun _cx -> TmPrim(_1.i, PrimTString _1.v) )
# 1590 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_63 =
  fun _1 ->
    (
# 264 "src/parser.mly"
      ( fun _cx -> TmPrim(_1.i, PrimTNum _1.v) )
# 1598 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_64 =
  fun _2 ->
    (
# 267 "src/parser.mly"
    ( _2 )
# 1606 "src/parser.ml"
     : (Ctx.context -> Syntax.term))

let _menhir_action_65 =
  fun _1 ->
    (
# 127 "src/parser.mly"
      ( _1 Ctx.empty_context )
# 1614 "src/parser.ml"
     : (Syntax.term))

let _menhir_print_token : token -> string =
  fun _tok ->
    match _tok with
    | ADD _ ->
        "ADD"
    | ADDOP _ ->
        "ADDOP"
    | AMP _ ->
        "AMP"
    | BANG _ ->
        "BANG"
    | BOOL _ ->
        "BOOL"
    | COLON _ ->
        "COLON"
    | COMMA _ ->
        "COMMA"
    | DBLARROW _ ->
        "DBLARROW"
    | DIVOP _ ->
        "DIVOP"
    | ELSE _ ->
        "ELSE"
    | EM _ ->
        "EM"
    | EOF _ ->
        "EOF"
    | EPS _ ->
        "EPS"
    | EPS2 _ ->
        "EPS2"
    | EQOP _ ->
        "EQOP"
    | EQUAL _ ->
        "EQUAL"
    | FLOATV _ ->
        "FLOATV"
    | FUN _ ->
        "FUN"
    | FUNCTION _ ->
        "FUNCTION"
    | GT _ ->
        "GT"
    | GTOP _ ->
        "GTOP"
    | ID _ ->
        "ID"
    | IF _ ->
        "IF"
    | INF _ ->
        "INF"
    | INL _ ->
        "INL"
    | INR _ ->
        "INR"
    | LBRACE _ ->
        "LBRACE"
    | LBRACK _ ->
        "LBRACK"
    | LET _ ->
        "LET"
    | LOLLIPOP _ ->
        "LOLLIPOP"
    | LPAREN _ ->
        "LPAREN"
    | LT _ ->
        "LT"
    | MULOP _ ->
        "MULOP"
    | NUM _ ->
        "NUM"
    | OF _ ->
        "OF"
    | PIPE _ ->
        "PIPE"
    | PROJ1 _ ->
        "PROJ1"
    | PROJ2 _ ->
        "PROJ2"
    | RBRACE _ ->
        "RBRACE"
    | RBRACK _ ->
        "RBRACK"
    | RET _ ->
        "RET"
    | RND _ ->
        "RND"
    | RPAREN _ ->
        "RPAREN"
    | SEMI _ ->
        "SEMI"
    | SQRTOP _ ->
        "SQRTOP"
    | STRING _ ->
        "STRING"
    | STRINGV _ ->
        "STRINGV"
    | THEN _ ->
        "THEN"
    | UNIONCASE _ ->
        "UNIONCASE"

let _menhir_fail : unit -> 'a =
  fun () ->
    Printf.eprintf "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

include struct
  
  [@@@ocaml.warning "-4-37-39"]
  
  let rec _menhir_run_001 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_UNIONCASE (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_165 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState001 _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState001
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState001
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState001
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState001
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState001
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState001
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_165 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState001 _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState001
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_165 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState001 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_165 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | OF _v_0 ->
          let _menhir_stack = MenhirCell0_OF (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LBRACE _v_1 ->
              let _menhir_stack = MenhirCell0_LBRACE (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | INL _v_2 ->
                  let _menhir_stack = MenhirCell0_INL (_menhir_stack, _v_2) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | LPAREN _v_3 ->
                      let _menhir_stack = MenhirCell0_LPAREN (_menhir_stack, _v_3) in
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      (match (_tok : MenhirBasics.token) with
                      | ID _v_4 ->
                          let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_4) in
                          let _tok = _menhir_lexer _menhir_lexbuf in
                          (match (_tok : MenhirBasics.token) with
                          | RPAREN _v_5 ->
                              let _menhir_stack = MenhirCell0_RPAREN (_menhir_stack, _v_5) in
                              let _tok = _menhir_lexer _menhir_lexbuf in
                              (match (_tok : MenhirBasics.token) with
                              | DBLARROW _v_6 ->
                                  let _menhir_stack = MenhirCell0_DBLARROW (_menhir_stack, _v_6) in
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  (match (_tok : MenhirBasics.token) with
                                  | UNIONCASE _v_7 ->
                                      _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState172
                                  | STRINGV _v_8 ->
                                      let _tok = _menhir_lexer _menhir_lexbuf in
                                      let _1 = _v_8 in
                                      let _v = _menhir_action_62 _1 in
                                      _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState172 _tok
                                  | SQRTOP _v_10 ->
                                      _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState172
                                  | RND _v_11 ->
                                      _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState172
                                  | RET _v_12 ->
                                      _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState172
                                  | PROJ2 _v_13 ->
                                      _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState172
                                  | PROJ1 _v_14 ->
                                      _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState172
                                  | MULOP _v_15 ->
                                      _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState172
                                  | LPAREN _v_16 ->
                                      _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState172
                                  | LET _v_17 ->
                                      _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState172
                                  | LBRACK _v_18 ->
                                      _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState172
                                  | INR _v_19 ->
                                      _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState172
                                  | INL _v_20 ->
                                      _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState172
                                  | IF _v_21 ->
                                      _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_21 MenhirState172
                                  | ID _v_22 ->
                                      _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_22 MenhirState172
                                  | GTOP _v_23 ->
                                      _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState172
                                  | FUNCTION _v_24 ->
                                      _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState172
                                  | FUN _v_25 ->
                                      _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_25 MenhirState172
                                  | FLOATV _v_26 ->
                                      let _tok = _menhir_lexer _menhir_lexbuf in
                                      let _1 = _v_26 in
                                      let _v = _menhir_action_63 _1 in
                                      _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState172 _tok
                                  | EQOP _v_28 ->
                                      _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_28 MenhirState172
                                  | DIVOP _v_29 ->
                                      _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_29 MenhirState172
                                  | ADDOP _v_30 ->
                                      _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_30 MenhirState172
                                  | _ ->
                                      _eRR ())
                              | _ ->
                                  _eRR ())
                          | _ ->
                              _eRR ())
                      | _ ->
                          _eRR ())
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_111 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState111
      | RET _v_3 ->
          let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState111
      | LPAREN _v_4 ->
          let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState111
      | LBRACK _v_5 ->
          let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState111
      | INR _v_6 ->
          let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState111
      | INL _v_7 ->
          let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState111
      | ID _v_8 ->
          let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState111
      | FLOATV _v_11 ->
          let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EOF _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ ->
          let _1 = _v in
          let _v = _menhir_action_32 _1 in
          _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_112 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Val -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_Val (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_33 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_Term : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState000 ->
          _menhir_run_183 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState179 ->
          _menhir_run_180 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState172 ->
          _menhir_run_173 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState064 ->
          _menhir_run_150 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState074 ->
          _menhir_run_146 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState139 ->
          _menhir_run_140 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState134 ->
          _menhir_run_135 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState083 ->
          _menhir_run_128 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState125 ->
          _menhir_run_126 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState087 ->
          _menhir_run_122 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState120 ->
          _menhir_run_121 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState092 ->
          _menhir_run_119 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState114 ->
          _menhir_run_115 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState104 ->
          _menhir_run_113 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_183 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState183
      | RET _v_3 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState183
      | LPAREN _v_4 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState183
      | LBRACK _v_5 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState183
      | INR _v_6 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState183
      | INL _v_7 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState183
      | ID _v_8 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState183
      | FLOATV _v_11 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EOF _ ->
          let _1 = _v in
          let _v = _menhir_action_65 _1 in
          MenhirBox_body _v
      | _ ->
          _eRR ()
  
  and _menhir_run_116 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Term -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_Term (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_49 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_003 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_RND (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_164 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState003
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState003
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState003
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState003
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState003
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState003
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_164 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState003
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_164 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_164 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_RND -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_RND (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_59 _1 _2 in
      _menhir_goto_Val _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_Val : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState001 ->
          _menhir_run_165 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState003 ->
          _menhir_run_164 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState004 ->
          _menhir_run_163 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState005 ->
          _menhir_run_162 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState158 ->
          _menhir_run_159 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState007 ->
          _menhir_run_157 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState008 ->
          _menhir_run_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState009 ->
          _menhir_run_153 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState010 ->
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState143 ->
          _menhir_run_144 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState074 ->
          _menhir_run_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState137 ->
          _menhir_run_138 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState132 ->
          _menhir_run_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState183 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState173 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState180 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState150 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState146 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState140 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState135 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState128 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState122 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState126 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState119 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState121 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState113 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState115 ->
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState141 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState111 ->
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState000 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState179 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState172 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState064 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState139 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState134 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState083 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState125 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState087 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState120 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState092 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState114 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState104 ->
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState109 ->
          _menhir_run_110 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState107 ->
          _menhir_run_108 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState105 ->
          _menhir_run_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState093 ->
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState084 ->
          _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState081 ->
          _menhir_run_082 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState072 ->
          _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState070 ->
          _menhir_run_071 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState068 ->
          _menhir_run_069 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState065 ->
          _menhir_run_067 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_163 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_RET -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_RET (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_60 _1 _2 in
      _menhir_goto_Val _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_162 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | RPAREN _ ->
          _menhir_run_142 _menhir_stack _menhir_lexbuf _menhir_lexer
      | COMMA _v_1 ->
          _menhir_run_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState162
      | _ ->
          _eRR ()
  
  and _menhir_run_142 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_Val -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let MenhirCell1_Val (_menhir_stack, _, _2) = _menhir_stack in
      let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _v = _menhir_action_64 _2 in
      _menhir_goto_Val _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_143 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_Val as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_COMMA (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_144 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState143 _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState143
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState143
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState143
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState143
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState143
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState143
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_144 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState143 _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState143
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_144 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState143 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_144 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_Val, _menhir_box_body) _menhir_cell1_COMMA as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | COMMA _v_0 ->
          let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
          _menhir_run_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState144
      | RPAREN _ ->
          let MenhirCell1_COMMA (_menhir_stack, _, _2) = _menhir_stack in
          let MenhirCell1_Val (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_21 _1 _2 _3 in
          _menhir_goto_PairSeq _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_PairSeq : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState005 ->
          _menhir_run_148 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState074 ->
          _menhir_run_148 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState143 ->
          _menhir_run_145 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_148 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _2 = _v in
          let _v = _menhir_action_56 _2 in
          _menhir_goto_Val _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_145 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_Val, _menhir_box_body) _menhir_cell1_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_COMMA (_menhir_stack, _, _2) = _menhir_stack in
      let MenhirCell1_Val (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_22 _1 _2 _3 in
      _menhir_goto_PairSeq _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_004 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_RET (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_163 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState004
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState004
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState004
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState004
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState004
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState004
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_163 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState004
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_163 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_005 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_162 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState005 _tok
      | RPAREN _ ->
          _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer
      | RND _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState005
      | RET _v_4 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState005
      | PIPE _v_5 ->
          _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState005
      | LPAREN _v_6 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState005
      | LBRACK _v_7 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState005
      | INR _v_8 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState005
      | INL _v_9 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState005
      | ID _v_10 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_10 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_162 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState005 _tok
      | FUN _v_12 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState005
      | FLOATV _v_13 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_13 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_162 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState005 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_006 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _v = _menhir_action_52 _1 in
      _menhir_goto_Val _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_007 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_PIPE (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_157 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState007 _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState007
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState007
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState007
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState007
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState007
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState007
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_157 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState007 _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState007
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_157 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState007 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_157 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | COMMA _v_0 ->
          let _menhir_stack = MenhirCell0_COMMA (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRINGV _v_1 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_1 in
              let _v = _menhir_action_62 _1 in
              _menhir_run_159 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | RND _v_3 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState158
          | RET _v_4 ->
              _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState158
          | LPAREN _v_5 ->
              _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState158
          | LBRACK _v_6 ->
              _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState158
          | INR _v_7 ->
              _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState158
          | INL _v_8 ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState158
          | ID _v_9 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_9 in
              let _v = _menhir_action_53 _1 in
              _menhir_run_159 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | FUN _v_11 ->
              _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState158
          | FLOATV _v_12 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_12 in
              let _v = _menhir_action_63 _1 in
              _menhir_run_159 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_159 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN, _menhir_box_body) _menhir_cell1_PIPE, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | PIPE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | RPAREN _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let MenhirCell0_COMMA (_menhir_stack, _) = _menhir_stack in
              let MenhirCell1_Val (_menhir_stack, _, _3) = _menhir_stack in
              let MenhirCell1_PIPE (_menhir_stack, _, _) = _menhir_stack in
              let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _1) = _menhir_stack in
              let _5 = _v in
              let _v = _menhir_action_57 _1 _3 _5 in
              _menhir_goto_Val _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_008 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_LBRACK (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState008 _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState008
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState008
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState008
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState008
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState008
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState008
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState008 _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState008
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState008 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_154 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LBRACK as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | LBRACE _v_0 ->
          _menhir_run_024 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState154
      | INF _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_25 () in
          _menhir_run_032_spec_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | ID _v_3 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_3 in
          let _v = _menhir_action_23 _1 in
          _menhir_run_032_spec_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FLOATV _v_5 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_5 in
          let _v = _menhir_action_24 _1 in
          _menhir_run_032_spec_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EPS2 _v_7 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_7 in
          let _v = _menhir_action_27 _1 in
          _menhir_run_032_spec_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EPS _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_26 _1 in
          _menhir_run_032_spec_154 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_024 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_LBRACE (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LBRACE _v_0 ->
          _menhir_run_024 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState024
      | INF _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_25 () in
          _menhir_run_032_spec_024 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | ID _v_3 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_3 in
          let _v = _menhir_action_23 _1 in
          _menhir_run_032_spec_024 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FLOATV _v_5 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_5 in
          let _v = _menhir_action_24 _1 in
          _menhir_run_032_spec_024 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EPS2 _v_7 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_7 in
          let _v = _menhir_action_27 _1 in
          _menhir_run_032_spec_024 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EPS _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_26 _1 in
          _menhir_run_032_spec_024 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_032_spec_024 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_29 _1 in
      _menhir_run_030 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_030 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LBRACE -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RBRACE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LBRACE (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _2 = _v in
          let _v = _menhir_action_28 _2 in
          _menhir_goto_SensTerm _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_SensTerm : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState154 ->
          _menhir_run_155 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState037 ->
          _menhir_run_038 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState023 ->
          _menhir_run_033 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState024 ->
          _menhir_run_030 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_155 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LBRACK, _menhir_box_body) _menhir_cell1_Val -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RBRACK _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_Val (_menhir_stack, _, _2) = _menhir_stack in
          let MenhirCell1_LBRACK (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_58 _1 _2 _3 in
          _menhir_goto_Val _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_038 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_BANG _menhir_cell0_LBRACK as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_SensTerm (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | RBRACK _v_0 ->
          let _menhir_stack = MenhirCell0_RBRACK (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRING _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_05 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState039 _tok
          | NUM _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_03 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState039 _tok
          | LT _v_5 ->
              _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState039
          | LPAREN _v_6 ->
              _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState039
          | ID _v_7 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_7 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState039 _tok
          | EM _v_9 ->
              _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState039
          | BOOL _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_04 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState039 _tok
          | BANG _v_12 ->
              _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState039
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_042 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | LOLLIPOP _v_0 ->
          let _menhir_stack = MenhirCell1_AType (_menhir_stack, _menhir_s, _v) in
          let _menhir_stack = MenhirCell0_LOLLIPOP (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRING _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_05 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState043 _tok
          | NUM _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_03 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState043 _tok
          | LT _v_5 ->
              _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState043
          | LPAREN _v_6 ->
              _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState043
          | ID _v_7 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_7 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState043 _tok
          | EM _v_9 ->
              _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState043
          | BOOL _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_04 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState043 _tok
          | BANG _v_12 ->
              _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState043
          | _ ->
              _eRR ())
      | AMP _v_13 ->
          let _menhir_stack = MenhirCell1_AType (_menhir_stack, _menhir_s, _v) in
          let _menhir_stack = MenhirCell0_AMP (_menhir_stack, _v_13) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRING _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_05 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState045 _tok
          | NUM _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_03 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState045 _tok
          | LT _v_18 ->
              _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState045
          | LPAREN _v_19 ->
              _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState045
          | ID _v_20 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_20 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState045 _tok
          | EM _v_22 ->
              _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_22 MenhirState045
          | BOOL _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_04 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState045 _tok
          | BANG _v_25 ->
              _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_25 MenhirState045
          | _ ->
              _eRR ())
      | ADD _v_26 ->
          let _menhir_stack = MenhirCell1_AType (_menhir_stack, _menhir_s, _v) in
          let _menhir_stack = MenhirCell0_ADD (_menhir_stack, _v_26) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRING _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_05 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState047 _tok
          | NUM _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_03 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState047 _tok
          | LT _v_31 ->
              _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_31 MenhirState047
          | LPAREN _v_32 ->
              _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_32 MenhirState047
          | ID _v_33 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_33 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState047 _tok
          | EM _v_35 ->
              _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_35 MenhirState047
          | BOOL _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_04 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState047 _tok
          | BANG _v_38 ->
              _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_38 MenhirState047
          | _ ->
              _eRR ())
      | COMMA _ | EQUAL _ | GT _ | LBRACE _ | RPAREN _ ->
          let _1 = _v in
          let _v = _menhir_action_18 _1 in
          _menhir_goto_ComplexType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_018 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_LT (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRING _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_05 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState018 _tok
      | NUM _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_03 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState018 _tok
      | LT _v_4 ->
          _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState018
      | LPAREN _v_5 ->
          _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState018
      | ID _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState018 _tok
      | EM _v_8 ->
          _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState018
      | BOOL _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_04 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState018 _tok
      | BANG _v_11 ->
          _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState018
      | _ ->
          _eRR ()
  
  and _menhir_run_019 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRING _ ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_05 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState019 _tok
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_06 () in
          _menhir_goto_AType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | NUM _ ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_03 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState019 _tok
      | LT _v_5 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState019
      | LPAREN _v_6 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState019
      | ID _v_7 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_7 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState019 _tok
      | EM _v_9 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState019
      | BOOL _ ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_04 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState019 _tok
      | BANG _v_12 ->
          let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
          _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState019
      | _ ->
          _eRR ()
  
  and _menhir_goto_AType : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_022 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_EM (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LBRACK _v_0 ->
          let _menhir_stack = MenhirCell0_LBRACK (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LBRACE _v_1 ->
              _menhir_run_024 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState023
          | INF _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_25 () in
              _menhir_run_032_spec_023 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | ID _v_4 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_4 in
              let _v = _menhir_action_23 _1 in
              _menhir_run_032_spec_023 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | FLOATV _v_6 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_6 in
              let _v = _menhir_action_24 _1 in
              _menhir_run_032_spec_023 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | EPS2 _v_8 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_8 in
              let _v = _menhir_action_27 _1 in
              _menhir_run_032_spec_023 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | EPS _v_10 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_10 in
              let _v = _menhir_action_26 _1 in
              _menhir_run_032_spec_023 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_032_spec_023 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_EM _menhir_cell0_LBRACK -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_29 _1 in
      _menhir_run_033 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState023 _tok
  
  and _menhir_run_033 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_EM _menhir_cell0_LBRACK as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_SensTerm (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | RBRACK _v_0 ->
          let _menhir_stack = MenhirCell0_RBRACK (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRING _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_05 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState034 _tok
          | NUM _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_03 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState034 _tok
          | LT _v_5 ->
              _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState034
          | LPAREN _v_6 ->
              _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState034
          | ID _v_7 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_7 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState034 _tok
          | EM _v_9 ->
              _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState034
          | BOOL _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_04 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState034 _tok
          | BANG _v_12 ->
              _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState034
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_036 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_BANG (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LBRACK _v_0 ->
          let _menhir_stack = MenhirCell0_LBRACK (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LBRACE _v_1 ->
              _menhir_run_024 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState037
          | INF _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_25 () in
              _menhir_run_032_spec_037 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | ID _v_4 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_4 in
              let _v = _menhir_action_23 _1 in
              _menhir_run_032_spec_037 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | FLOATV _v_6 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_6 in
              let _v = _menhir_action_24 _1 in
              _menhir_run_032_spec_037 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | EPS2 _v_8 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_8 in
              let _v = _menhir_action_27 _1 in
              _menhir_run_032_spec_037 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | EPS _v_10 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_10 in
              let _v = _menhir_action_26 _1 in
              _menhir_run_032_spec_037 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_032_spec_037 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_BANG _menhir_cell0_LBRACK -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_29 _1 in
      _menhir_run_038 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState037 _tok
  
  and _menhir_goto_ComplexType : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState047 ->
          _menhir_run_048 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState045 ->
          _menhir_run_046 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState043 ->
          _menhir_run_044 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState099 ->
          _menhir_run_041_spec_099 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState089 ->
          _menhir_run_041_spec_089 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState015 ->
          _menhir_run_041_spec_015 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState018 ->
          _menhir_run_041_spec_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState058 ->
          _menhir_run_041_spec_058 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState019 ->
          _menhir_run_041_spec_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState052 ->
          _menhir_run_041_spec_052 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState034 ->
          _menhir_run_041_spec_034 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState039 ->
          _menhir_run_041_spec_039 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_048 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_ADD -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_ADD (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_AType (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_15 _1 _3 in
      _menhir_goto_ComplexType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_046 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_AMP -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_AMP (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_AType (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_16 _1 _3 in
      _menhir_goto_ComplexType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_044 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_AType _menhir_cell0_LOLLIPOP -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_LOLLIPOP (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_AType (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_17 _1 _3 in
      _menhir_goto_ComplexType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_041_spec_099 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN _menhir_cell0_ID _menhir_cell0_COLON -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_51 _1
      in
      match (_tok : MenhirBasics.token) with
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_COLON (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _4 = _v in
          let _v = _menhir_action_11 _2 _4 in
          (match (_tok : MenhirBasics.token) with
          | LPAREN _v_0 ->
              let _menhir_stack = MenhirCell1_Argument (_menhir_stack, _menhir_s, _v) in
              _menhir_run_097 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState117
          | COLON _ | LBRACE _ ->
              let _1 = _v in
              let _v = _menhir_action_12 _1 in
              _menhir_goto_Arguments _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_097 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | ID _v_0 ->
          let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | COLON _v_1 ->
              let _menhir_stack = MenhirCell0_COLON (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | STRING _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_05 () in
                  _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState099 _tok
              | NUM _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_03 () in
                  _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState099 _tok
              | LT _v_6 ->
                  _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState099
              | LPAREN _v_7 ->
                  _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState099
              | ID _v_8 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_8 in
                  let _v = _menhir_action_02 _1 in
                  _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState099 _tok
              | EM _v_10 ->
                  _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState099
              | BOOL _ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_04 () in
                  _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState099 _tok
              | BANG _v_13 ->
                  _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState099
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_goto_Arguments : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState117 ->
          _menhir_run_118 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState096 ->
          _menhir_run_102 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_118 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Argument -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_Argument (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_13 _1 _2 in
      _menhir_goto_Arguments _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_102 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_FUNCTION _menhir_cell0_ID as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Arguments (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | COLON _v_0 ->
          _menhir_run_089 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState102
      | LBRACE _ ->
          let _v = _menhir_action_19 () in
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState102 _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_089 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_COLON (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRING _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_05 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState089 _tok
      | NUM _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_03 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState089 _tok
      | LT _v_4 ->
          _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState089
      | LPAREN _v_5 ->
          _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState089
      | ID _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState089 _tok
      | EM _v_8 ->
          _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState089
      | BOOL _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_04 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState089 _tok
      | BANG _v_11 ->
          _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState089
      | _ ->
          _eRR ()
  
  and _menhir_run_103 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_FUNCTION _menhir_cell0_ID, _menhir_box_body) _menhir_cell1_Arguments as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_MaybeType (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | LBRACE _v_0 ->
          let _menhir_stack = MenhirCell0_LBRACE (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState104
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_62 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState104 _tok
          | SQRTOP _v_4 ->
              _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState104
          | RND _v_5 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState104
          | RET _v_6 ->
              _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState104
          | PROJ2 _v_7 ->
              _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState104
          | PROJ1 _v_8 ->
              _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState104
          | MULOP _v_9 ->
              _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState104
          | LPAREN _v_10 ->
              _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState104
          | LET _v_11 ->
              _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState104
          | LBRACK _v_12 ->
              _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState104
          | INR _v_13 ->
              _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState104
          | INL _v_14 ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState104
          | IF _v_15 ->
              _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState104
          | ID _v_16 ->
              _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState104
          | GTOP _v_17 ->
              _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState104
          | FUNCTION _v_18 ->
              _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState104
          | FUN _v_19 ->
              _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState104
          | FLOATV _v_20 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_20 in
              let _v = _menhir_action_63 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState104 _tok
          | EQOP _v_22 ->
              _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_22 MenhirState104
          | DIVOP _v_23 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState104
          | ADDOP _v_24 ->
              _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState104
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_065 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_SQRTOP (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_067 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState065
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState065
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState065
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState065
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState065
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState065
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_067 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState065
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_067 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_067 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_SQRTOP -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_SQRTOP (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_46 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_009 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_INR (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_153 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState009
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState009
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState009
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState009
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState009
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState009
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_153 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState009
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_153 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_153 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_INR -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_INR (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_55 _1 _2 in
      _menhir_goto_Val _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_010 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_INL (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState010
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState010
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState010
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState010
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState010
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState010
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState010
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_152 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_152 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_INL -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_INL (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_54 _1 _2 in
      _menhir_goto_Val _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_012 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_FUN (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LPAREN _v_0 ->
          let _menhir_stack = MenhirCell0_LPAREN (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | ID _v_1 ->
              let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | COLON _v_2 ->
                  let _menhir_stack = MenhirCell0_COLON (_menhir_stack, _v_2) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | STRING _ ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _v = _menhir_action_05 () in
                      _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState015 _tok
                  | NUM _ ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _v = _menhir_action_03 () in
                      _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState015 _tok
                  | LT _v_7 ->
                      _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState015
                  | LPAREN _v_8 ->
                      _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState015
                  | ID _v_9 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_9 in
                      let _v = _menhir_action_02 _1 in
                      _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState015 _tok
                  | EM _v_11 ->
                      _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState015
                  | BOOL _ ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _v = _menhir_action_04 () in
                      _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState015 _tok
                  | BANG _v_14 ->
                      _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState015
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_068 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_PROJ2 (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_069 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState068
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState068
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState068
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState068
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState068
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState068
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_069 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState068
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_069 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_069 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_PROJ2 -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_PROJ2 (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_35 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_070 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_PROJ1 (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_071 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState070
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState070
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState070
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState070
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState070
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState070
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_071 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState070
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_071 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_071 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_PROJ1 -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_PROJ1 (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_34 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_072 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_MULOP (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState072
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState072
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState072
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState072
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState072
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState072
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState072
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_073 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_073 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_MULOP -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_MULOP (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_44 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_074 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v_0 ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState074
      | STRINGV _v_1 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_1 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState074 _tok
      | SQRTOP _v_3 ->
          _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState074
      | RPAREN _ ->
          _menhir_run_006 _menhir_stack _menhir_lexbuf _menhir_lexer
      | RND _v_5 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState074
      | RET _v_6 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState074
      | PROJ2 _v_7 ->
          _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState074
      | PROJ1 _v_8 ->
          _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState074
      | PIPE _v_9 ->
          _menhir_run_007 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState074
      | MULOP _v_10 ->
          _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState074
      | LPAREN _v_11 ->
          _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState074
      | LET _v_12 ->
          _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState074
      | LBRACK _v_13 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState074
      | INR _v_14 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState074
      | INL _v_15 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState074
      | IF _v_16 ->
          _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState074
      | ID _v_17 ->
          _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState074
      | GTOP _v_18 ->
          _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState074
      | FUNCTION _v_19 ->
          _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState074
      | FUN _v_20 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState074
      | FLOATV _v_21 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_21 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_141 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState074 _tok
      | EQOP _v_23 ->
          _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState074
      | DIVOP _v_24 ->
          _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState074
      | ADDOP _v_25 ->
          _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_25 MenhirState074
      | _ ->
          _eRR ()
  
  and _menhir_run_141 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RPAREN _ ->
          _menhir_run_142 _menhir_stack _menhir_lexbuf _menhir_lexer
      | RND _v_3 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState141
      | RET _v_4 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState141
      | LPAREN _v_5 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState141
      | LBRACK _v_6 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState141
      | INR _v_7 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState141
      | INL _v_8 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState141
      | ID _v_9 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState141
      | FLOATV _v_12 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_112 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | COMMA _v_14 ->
          _menhir_run_143 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState141
      | _ ->
          _eRR ()
  
  and _menhir_run_075 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_LET (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | LPAREN _v_0 ->
          let _menhir_stack = MenhirCell0_LPAREN (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | ID _v_1 ->
              let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | COMMA _v_2 ->
                  let _menhir_stack = MenhirCell0_COMMA (_menhir_stack, _v_2) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | ID _v_3 ->
                      let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_3) in
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      (match (_tok : MenhirBasics.token) with
                      | RPAREN _v_4 ->
                          let _menhir_stack = MenhirCell0_RPAREN (_menhir_stack, _v_4) in
                          let _tok = _menhir_lexer _menhir_lexbuf in
                          (match (_tok : MenhirBasics.token) with
                          | EQUAL _v_5 ->
                              let _menhir_stack = MenhirCell0_EQUAL (_menhir_stack, _v_5) in
                              let _tok = _menhir_lexer _menhir_lexbuf in
                              (match (_tok : MenhirBasics.token) with
                              | STRINGV _v_6 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_6 in
                                  let _v = _menhir_action_62 _1 in
                                  _menhir_run_082 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState081 _tok
                              | RND _v_8 ->
                                  _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState081
                              | RET _v_9 ->
                                  _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState081
                              | LPAREN _v_10 ->
                                  _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState081
                              | LBRACK _v_11 ->
                                  _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState081
                              | INR _v_12 ->
                                  _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState081
                              | INL _v_13 ->
                                  _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState081
                              | ID _v_14 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_14 in
                                  let _v = _menhir_action_53 _1 in
                                  _menhir_run_082 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState081 _tok
                              | FUN _v_16 ->
                                  _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState081
                              | FLOATV _v_17 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_17 in
                                  let _v = _menhir_action_63 _1 in
                                  _menhir_run_082 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState081 _tok
                              | _ ->
                                  _eRR ())
                          | _ ->
                              _eRR ())
                      | _ ->
                          _eRR ())
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | LBRACK _v_19 ->
          let _menhir_stack = MenhirCell0_LBRACK (_menhir_stack, _v_19) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | ID _v_20 ->
              let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_20) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | RBRACK _v_21 ->
                  let _menhir_stack = MenhirCell0_RBRACK (_menhir_stack, _v_21) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | EQUAL _v_22 ->
                      let _menhir_stack = MenhirCell0_EQUAL (_menhir_stack, _v_22) in
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      (match (_tok : MenhirBasics.token) with
                      | STRINGV _v_23 ->
                          let _tok = _menhir_lexer _menhir_lexbuf in
                          let _1 = _v_23 in
                          let _v = _menhir_action_62 _1 in
                          _menhir_run_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState132 _tok
                      | RND _v_25 ->
                          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_25 MenhirState132
                      | RET _v_26 ->
                          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_26 MenhirState132
                      | LPAREN _v_27 ->
                          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_27 MenhirState132
                      | LBRACK _v_28 ->
                          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_28 MenhirState132
                      | INR _v_29 ->
                          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_29 MenhirState132
                      | INL _v_30 ->
                          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_30 MenhirState132
                      | ID _v_31 ->
                          let _tok = _menhir_lexer _menhir_lexbuf in
                          let _1 = _v_31 in
                          let _v = _menhir_action_53 _1 in
                          _menhir_run_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState132 _tok
                      | FUN _v_33 ->
                          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_33 MenhirState132
                      | FLOATV _v_34 ->
                          let _tok = _menhir_lexer _menhir_lexbuf in
                          let _1 = _v_34 in
                          let _v = _menhir_action_63 _1 in
                          _menhir_run_133 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState132 _tok
                      | _ ->
                          _eRR ())
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | ID _v_36 ->
          let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_36) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | EQUAL _v_37 ->
              let _menhir_stack = MenhirCell0_EQUAL (_menhir_stack, _v_37) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | STRINGV _v_38 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_38 in
                  let _v = _menhir_action_62 _1 in
                  _menhir_run_138 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState137 _tok
              | RND _v_40 ->
                  _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_40 MenhirState137
              | RET _v_41 ->
                  _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_41 MenhirState137
              | LPAREN _v_42 ->
                  _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_42 MenhirState137
              | LBRACK _v_43 ->
                  _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_43 MenhirState137
              | INR _v_44 ->
                  _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_44 MenhirState137
              | INL _v_45 ->
                  _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_45 MenhirState137
              | ID _v_46 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_46 in
                  let _v = _menhir_action_53 _1 in
                  _menhir_run_138 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState137 _tok
              | FUN _v_48 ->
                  _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_48 MenhirState137
              | FLOATV _v_49 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_49 in
                  let _v = _menhir_action_63 _1 in
                  _menhir_run_138 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState137 _tok
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_082 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | SEMI _v_0 ->
          let _menhir_stack = MenhirCell0_SEMI (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState083
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_62 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState083 _tok
          | SQRTOP _v_4 ->
              _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState083
          | RND _v_5 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState083
          | RET _v_6 ->
              _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState083
          | PROJ2 _v_7 ->
              _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState083
          | PROJ1 _v_8 ->
              _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState083
          | MULOP _v_9 ->
              _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState083
          | LPAREN _v_10 ->
              _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState083
          | LET _v_11 ->
              _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState083
          | LBRACK _v_12 ->
              _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState083
          | INR _v_13 ->
              _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState083
          | INL _v_14 ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState083
          | IF _v_15 ->
              _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState083
          | ID _v_16 ->
              _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState083
          | GTOP _v_17 ->
              _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState083
          | FUNCTION _v_18 ->
              _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState083
          | FUN _v_19 ->
              _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState083
          | FLOATV _v_20 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_20 in
              let _v = _menhir_action_63 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState083 _tok
          | EQOP _v_22 ->
              _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_22 MenhirState083
          | DIVOP _v_23 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState083
          | ADDOP _v_24 ->
              _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState083
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_084 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_IF (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState084 _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState084
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState084
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState084
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState084
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState084
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState084
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState084 _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState084
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_085 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState084 _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_085 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_IF as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | THEN _v_0 ->
          let _menhir_stack = MenhirCell0_THEN (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LBRACE _v_1 ->
              let _menhir_stack = MenhirCell0_LBRACE (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | UNIONCASE _v_2 ->
                  _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState087
              | STRINGV _v_3 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_3 in
                  let _v = _menhir_action_62 _1 in
                  _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState087 _tok
              | SQRTOP _v_5 ->
                  _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState087
              | RND _v_6 ->
                  _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState087
              | RET _v_7 ->
                  _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState087
              | PROJ2 _v_8 ->
                  _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState087
              | PROJ1 _v_9 ->
                  _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState087
              | MULOP _v_10 ->
                  _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState087
              | LPAREN _v_11 ->
                  _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState087
              | LET _v_12 ->
                  _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState087
              | LBRACK _v_13 ->
                  _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState087
              | INR _v_14 ->
                  _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState087
              | INL _v_15 ->
                  _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState087
              | IF _v_16 ->
                  _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState087
              | ID _v_17 ->
                  _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState087
              | GTOP _v_18 ->
                  _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState087
              | FUNCTION _v_19 ->
                  _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState087
              | FUN _v_20 ->
                  _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState087
              | FLOATV _v_21 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_21 in
                  let _v = _menhir_action_63 _1 in
                  _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState087 _tok
              | EQOP _v_23 ->
                  _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState087
              | DIVOP _v_24 ->
                  _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState087
              | ADDOP _v_25 ->
                  _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_25 MenhirState087
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_088 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | COLON _v_0 ->
          let _menhir_stack = MenhirCell1_ID (_menhir_stack, _menhir_s, _v) in
          _menhir_run_089 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState088
      | EQUAL _ ->
          let _menhir_stack = MenhirCell1_ID (_menhir_stack, _menhir_s, _v) in
          let _v = _menhir_action_19 () in
          _menhir_run_091 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState088 _tok
      | COMMA _ | EOF _ | FLOATV _ | FUN _ | ID _ | INL _ | INR _ | LBRACK _ | LPAREN _ | PIPE _ | RBRACE _ | RET _ | RND _ | RPAREN _ | SEMI _ | STRINGV _ ->
          let _1 = _v in
          let _v = _menhir_action_53 _1 in
          _menhir_goto_Val _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_091 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_ID as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_MaybeType (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | EQUAL _v_0 ->
          let _menhir_stack = MenhirCell0_EQUAL (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState092
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_62 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState092 _tok
          | SQRTOP _v_4 ->
              _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState092
          | RND _v_5 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState092
          | RET _v_6 ->
              _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState092
          | PROJ2 _v_7 ->
              _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState092
          | PROJ1 _v_8 ->
              _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState092
          | MULOP _v_9 ->
              _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState092
          | LPAREN _v_10 ->
              _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState092
          | LET _v_11 ->
              _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState092
          | LBRACK _v_12 ->
              _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState092
          | INR _v_13 ->
              _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState092
          | INL _v_14 ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState092
          | IF _v_15 ->
              _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState092
          | ID _v_16 ->
              _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState092
          | GTOP _v_17 ->
              _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState092
          | FUNCTION _v_18 ->
              _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState092
          | FUN _v_19 ->
              _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState092
          | FLOATV _v_20 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_20 in
              let _v = _menhir_action_63 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState092 _tok
          | EQOP _v_22 ->
              _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_22 MenhirState092
          | DIVOP _v_23 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState092
          | ADDOP _v_24 ->
              _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState092
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_093 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_GTOP (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState093
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState093
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState093
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState093
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState093
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState093
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState093
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_094 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_094 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_GTOP -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_GTOP (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_47 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_095 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_FUNCTION (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | ID _v ->
          let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LPAREN _v ->
              _menhir_run_097 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState096
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_105 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_EQOP (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState105
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState105
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState105
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState105
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState105
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState105
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState105
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_106 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_106 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_EQOP -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_EQOP (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_48 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_107 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_DIVOP (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_108 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState107
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState107
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState107
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState107
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState107
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState107
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_108 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState107
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_108 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_108 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_DIVOP -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_DIVOP (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_45 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_109 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_ADDOP (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_110 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState109
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState109
      | LPAREN _v_4 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState109
      | LBRACK _v_5 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState109
      | INR _v_6 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState109
      | INL _v_7 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState109
      | ID _v_8 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_110 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState109
      | FLOATV _v_11 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_110 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_110 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_ADDOP -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_ADDOP (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_43 _1 _2 in
      _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_133 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LBRACK _menhir_cell0_ID _menhir_cell0_RBRACK _menhir_cell0_EQUAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | SEMI _v_0 ->
          let _menhir_stack = MenhirCell0_SEMI (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState134
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_62 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState134 _tok
          | SQRTOP _v_4 ->
              _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState134
          | RND _v_5 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState134
          | RET _v_6 ->
              _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState134
          | PROJ2 _v_7 ->
              _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState134
          | PROJ1 _v_8 ->
              _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState134
          | MULOP _v_9 ->
              _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState134
          | LPAREN _v_10 ->
              _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState134
          | LET _v_11 ->
              _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState134
          | LBRACK _v_12 ->
              _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState134
          | INR _v_13 ->
              _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState134
          | INL _v_14 ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState134
          | IF _v_15 ->
              _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState134
          | ID _v_16 ->
              _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState134
          | GTOP _v_17 ->
              _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState134
          | FUNCTION _v_18 ->
              _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState134
          | FUN _v_19 ->
              _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState134
          | FLOATV _v_20 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_20 in
              let _v = _menhir_action_63 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState134 _tok
          | EQOP _v_22 ->
              _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_22 MenhirState134
          | DIVOP _v_23 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState134
          | ADDOP _v_24 ->
              _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState134
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_138 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_ID _menhir_cell0_EQUAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Val (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | SEMI _v_0 ->
          let _menhir_stack = MenhirCell0_SEMI (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_1 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState139
          | STRINGV _v_2 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_2 in
              let _v = _menhir_action_62 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState139 _tok
          | SQRTOP _v_4 ->
              _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState139
          | RND _v_5 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState139
          | RET _v_6 ->
              _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState139
          | PROJ2 _v_7 ->
              _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState139
          | PROJ1 _v_8 ->
              _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState139
          | MULOP _v_9 ->
              _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState139
          | LPAREN _v_10 ->
              _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState139
          | LET _v_11 ->
              _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState139
          | LBRACK _v_12 ->
              _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState139
          | INR _v_13 ->
              _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState139
          | INL _v_14 ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState139
          | IF _v_15 ->
              _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState139
          | ID _v_16 ->
              _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState139
          | GTOP _v_17 ->
              _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState139
          | FUNCTION _v_18 ->
              _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState139
          | FUN _v_19 ->
              _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState139
          | FLOATV _v_20 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_20 in
              let _v = _menhir_action_63 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState139 _tok
          | EQOP _v_22 ->
              _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_22 MenhirState139
          | DIVOP _v_23 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState139
          | ADDOP _v_24 ->
              _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState139
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_041_spec_089 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_COLON -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_51 _1
      in
      let MenhirCell1_COLON (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_20 _2 in
      _menhir_goto_MaybeType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_MaybeType : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState102 ->
          _menhir_run_103 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState088 ->
          _menhir_run_091 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_041_spec_015 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COLON -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_51 _1
      in
      let MenhirCell0_COLON (_menhir_stack, _) = _menhir_stack in
      let _2 = _v in
      let _v = _menhir_action_14 _2 in
      let _menhir_stack = MenhirCell0_ColType (_menhir_stack, _v) in
      match (_tok : MenhirBasics.token) with
      | RPAREN _v_0 ->
          let _menhir_stack = MenhirCell0_RPAREN (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | LBRACE _v_1 ->
              let _menhir_stack = MenhirCell0_LBRACE (_menhir_stack, _v_1) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | UNIONCASE _v_2 ->
                  _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState064
              | STRINGV _v_3 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_3 in
                  let _v = _menhir_action_62 _1 in
                  _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState064 _tok
              | SQRTOP _v_5 ->
                  _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState064
              | RND _v_6 ->
                  _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState064
              | RET _v_7 ->
                  _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState064
              | PROJ2 _v_8 ->
                  _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState064
              | PROJ1 _v_9 ->
                  _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState064
              | MULOP _v_10 ->
                  _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState064
              | LPAREN _v_11 ->
                  _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState064
              | LET _v_12 ->
                  _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState064
              | LBRACK _v_13 ->
                  _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState064
              | INR _v_14 ->
                  _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState064
              | INL _v_15 ->
                  _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState064
              | IF _v_16 ->
                  _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState064
              | ID _v_17 ->
                  _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState064
              | GTOP _v_18 ->
                  _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState064
              | FUNCTION _v_19 ->
                  _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState064
              | FUN _v_20 ->
                  _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState064
              | FLOATV _v_21 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _1 = _v_21 in
                  let _v = _menhir_action_63 _1 in
                  _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState064 _tok
              | EQOP _v_23 ->
                  _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState064
              | DIVOP _v_24 ->
                  _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState064
              | ADDOP _v_25 ->
                  _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_25 MenhirState064
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_041_spec_018 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LT -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_51 _1
      in
      let _menhir_stack = MenhirCell1_Type (_menhir_stack, MenhirState018, _v) in
      match (_tok : MenhirBasics.token) with
      | COMMA _v_0 ->
          let _menhir_stack = MenhirCell0_COMMA (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | STRING _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_05 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState058 _tok
          | NUM _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_03 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState058 _tok
          | LT _v_5 ->
              _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState058
          | LPAREN _v_6 ->
              _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState058
          | ID _v_7 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_7 in
              let _v = _menhir_action_02 _1 in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState058 _tok
          | EM _v_9 ->
              _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState058
          | BOOL _ ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _v = _menhir_action_04 () in
              _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState058 _tok
          | BANG _v_12 ->
              _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState058
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_041_spec_058 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LT, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_51 _1
      in
      match (_tok : MenhirBasics.token) with
      | GT _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_COMMA (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Type (_menhir_stack, _, _2) = _menhir_stack in
          let MenhirCell1_LT (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _4 = _v in
          let _v = _menhir_action_10 _2 _4 in
          _menhir_goto_AType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_041_spec_019 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_51 _1
      in
      match (_tok : MenhirBasics.token) with
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _2 = _v in
          let _v = _menhir_action_01 _2 in
          _menhir_goto_AType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | COMMA _v_1 ->
          let _menhir_stack = MenhirCell1_Type (_menhir_stack, MenhirState019, _v) in
          _menhir_run_052 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1
      | _ ->
          _eRR ()
  
  and _menhir_run_052 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Type -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_COMMA (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | STRING _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_05 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState052 _tok
      | NUM _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_03 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState052 _tok
      | LT _v_4 ->
          _menhir_run_018 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState052
      | LPAREN _v_5 ->
          _menhir_run_019 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState052
      | ID _v_6 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_6 in
          let _v = _menhir_action_02 _1 in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState052 _tok
      | EM _v_8 ->
          _menhir_run_022 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState052
      | BOOL _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_04 () in
          _menhir_run_042 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState052 _tok
      | BANG _v_11 ->
          _menhir_run_036 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState052
      | _ ->
          _eRR ()
  
  and _menhir_run_041_spec_052 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_51 _1
      in
      match (_tok : MenhirBasics.token) with
      | COMMA _v_0 ->
          let _menhir_stack = MenhirCell1_Type (_menhir_stack, MenhirState052, _v) in
          _menhir_run_052 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0
      | RPAREN _ ->
          let MenhirCell0_COMMA (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Type (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _3 = _v in
          let _v = _menhir_action_30 _1 _3 in
          _menhir_goto_TPairSeq _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_goto_TPairSeq : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState019 ->
          _menhir_run_055 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState052 ->
          _menhir_run_054 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_055 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _2 = _v in
          let _v = _menhir_action_09 _2 in
          _menhir_goto_AType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_054 : type  ttv_stack. (ttv_stack, _menhir_box_body) _menhir_cell1_Type _menhir_cell0_COMMA -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_COMMA (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_Type (_menhir_stack, _menhir_s, _1) = _menhir_stack in
      let _3 = _v in
      let _v = _menhir_action_31 _1 _3 in
      _menhir_goto_TPairSeq _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_041_spec_034 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_EM _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_SensTerm _menhir_cell0_RBRACK -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_51 _1
      in
      let MenhirCell0_RBRACK (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_SensTerm (_menhir_stack, _, _3) = _menhir_stack in
      let MenhirCell0_LBRACK (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_EM (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _5 = _v in
      let _v = _menhir_action_08 _3 _5 in
      _menhir_goto_AType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_041_spec_039 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_BANG _menhir_cell0_LBRACK, _menhir_box_body) _menhir_cell1_SensTerm _menhir_cell0_RBRACK -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _v =
        let _1 = _v in
        _menhir_action_51 _1
      in
      let MenhirCell0_RBRACK (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_SensTerm (_menhir_stack, _, _3) = _menhir_stack in
      let MenhirCell0_LBRACK (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_BANG (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _5 = _v in
      let _v = _menhir_action_07 _3 _5 in
      _menhir_goto_AType _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_032_spec_154 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LBRACK, _menhir_box_body) _menhir_cell1_Val -> _ -> _ -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _1 = _v in
      let _v = _menhir_action_29 _1 in
      _menhir_run_155 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
  
  and _menhir_run_180 : type  ttv_stack. (((((ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_PIPE _menhir_cell0_INR _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState180
      | RET _v_3 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState180
      | RBRACE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_DBLARROW (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_RPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _14) = _menhir_stack in
          let MenhirCell0_LPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_INR (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_PIPE (_menhir_stack, _, _) = _menhir_stack in
          let MenhirCell1_Term (_menhir_stack, _, _10) = _menhir_stack in
          let MenhirCell0_DBLARROW (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_RPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _7) = _menhir_stack in
          let MenhirCell0_LPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_INL (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_LBRACE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_OF (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Val (_menhir_stack, _, _2) = _menhir_stack in
          let MenhirCell1_UNIONCASE (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _17 = _v in
          let _v = _menhir_action_37 _1 _10 _14 _17 _2 _7 in
          _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | LPAREN _v_5 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState180
      | LBRACK _v_6 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState180
      | INR _v_7 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState180
      | INL _v_8 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState180
      | ID _v_9 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState180
      | FLOATV _v_12 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_173 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_UNIONCASE, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_OF _menhir_cell0_LBRACE _menhir_cell0_INL _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_DBLARROW as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState173
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState173
      | PIPE _v_4 ->
          let _menhir_stack = MenhirCell1_PIPE (_menhir_stack, MenhirState173, _v_4) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | INR _v_5 ->
              let _menhir_stack = MenhirCell0_INR (_menhir_stack, _v_5) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | LPAREN _v_6 ->
                  let _menhir_stack = MenhirCell0_LPAREN (_menhir_stack, _v_6) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | ID _v_7 ->
                      let _menhir_stack = MenhirCell0_ID (_menhir_stack, _v_7) in
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      (match (_tok : MenhirBasics.token) with
                      | RPAREN _v_8 ->
                          let _menhir_stack = MenhirCell0_RPAREN (_menhir_stack, _v_8) in
                          let _tok = _menhir_lexer _menhir_lexbuf in
                          (match (_tok : MenhirBasics.token) with
                          | DBLARROW _v_9 ->
                              let _menhir_stack = MenhirCell0_DBLARROW (_menhir_stack, _v_9) in
                              let _tok = _menhir_lexer _menhir_lexbuf in
                              (match (_tok : MenhirBasics.token) with
                              | UNIONCASE _v_10 ->
                                  _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState179
                              | STRINGV _v_11 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_11 in
                                  let _v = _menhir_action_62 _1 in
                                  _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState179 _tok
                              | SQRTOP _v_13 ->
                                  _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState179
                              | RND _v_14 ->
                                  _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState179
                              | RET _v_15 ->
                                  _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState179
                              | PROJ2 _v_16 ->
                                  _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState179
                              | PROJ1 _v_17 ->
                                  _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState179
                              | MULOP _v_18 ->
                                  _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState179
                              | LPAREN _v_19 ->
                                  _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState179
                              | LET _v_20 ->
                                  _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState179
                              | LBRACK _v_21 ->
                                  _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_21 MenhirState179
                              | INR _v_22 ->
                                  _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_22 MenhirState179
                              | INL _v_23 ->
                                  _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState179
                              | IF _v_24 ->
                                  _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState179
                              | ID _v_25 ->
                                  _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_25 MenhirState179
                              | GTOP _v_26 ->
                                  _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_26 MenhirState179
                              | FUNCTION _v_27 ->
                                  _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_27 MenhirState179
                              | FUN _v_28 ->
                                  _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_28 MenhirState179
                              | FLOATV _v_29 ->
                                  let _tok = _menhir_lexer _menhir_lexbuf in
                                  let _1 = _v_29 in
                                  let _v = _menhir_action_63 _1 in
                                  _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState179 _tok
                              | EQOP _v_31 ->
                                  _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_31 MenhirState179
                              | DIVOP _v_32 ->
                                  _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_32 MenhirState179
                              | ADDOP _v_33 ->
                                  _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_33 MenhirState179
                              | _ ->
                                  _eRR ())
                          | _ ->
                              _eRR ())
                      | _ ->
                          _eRR ())
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | LPAREN _v_34 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_34 MenhirState173
      | LBRACK _v_35 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_35 MenhirState173
      | INR _v_36 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_36 MenhirState173
      | INL _v_37 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_37 MenhirState173
      | ID _v_38 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_38 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_40 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_40 MenhirState173
      | FLOATV _v_41 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_41 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_150 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_FUN _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_ColType _menhir_cell0_RPAREN _menhir_cell0_LBRACE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState150
      | RET _v_3 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState150
      | RBRACE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_LBRACE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_RPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ColType (_menhir_stack, _4) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _3) = _menhir_stack in
          let MenhirCell0_LPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_FUN (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _7 = _v in
          let _v = _menhir_action_61 _1 _3 _4 _7 in
          _menhir_goto_Val _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | LPAREN _v_5 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState150
      | LBRACK _v_6 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState150
      | INR _v_7 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState150
      | INL _v_8 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState150
      | ID _v_9 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState150
      | FLOATV _v_12 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_146 : type  ttv_stack. ((ttv_stack, _menhir_box_body) _menhir_cell1_LPAREN as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RPAREN _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LPAREN (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _2 = _v in
          let _v = _menhir_action_50 _2 in
          _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | RND _v_3 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState146
      | RET _v_4 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState146
      | LPAREN _v_5 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState146
      | LBRACK _v_6 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState146
      | INR _v_7 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState146
      | INL _v_8 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState146
      | ID _v_9 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState146
      | FLOATV _v_12 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_140 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_ID _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_SEMI as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState140
      | RET _v_3 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState140
      | LPAREN _v_4 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState140
      | LBRACK _v_5 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState140
      | INR _v_6 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState140
      | INL _v_7 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState140
      | ID _v_8 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState140
      | FLOATV _v_11 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EOF _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ ->
          let MenhirCell0_SEMI (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Val (_menhir_stack, _, _4) = _menhir_stack in
          let MenhirCell0_EQUAL (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_LET (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _6 = _v in
          let _v = _menhir_action_40 _2 _4 _6 in
          _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_135 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LBRACK _menhir_cell0_ID _menhir_cell0_RBRACK _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_SEMI as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState135
      | RET _v_3 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState135
      | LPAREN _v_4 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState135
      | LBRACK _v_5 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState135
      | INR _v_6 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState135
      | INL _v_7 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState135
      | ID _v_8 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState135
      | FLOATV _v_11 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EOF _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ ->
          let MenhirCell0_SEMI (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Val (_menhir_stack, _, _6) = _menhir_stack in
          let MenhirCell0_EQUAL (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_RBRACK (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _3) = _menhir_stack in
          let MenhirCell0_LBRACK (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_LET (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _8 = _v in
          let _v = _menhir_action_39 _1 _3 _6 _8 in
          _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_128 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_LET _menhir_cell0_LPAREN _menhir_cell0_ID _menhir_cell0_COMMA _menhir_cell0_ID _menhir_cell0_RPAREN _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_SEMI as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState128
      | RET _v_3 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState128
      | LPAREN _v_4 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState128
      | LBRACK _v_5 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState128
      | INR _v_6 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState128
      | INL _v_7 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState128
      | ID _v_8 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState128
      | FLOATV _v_11 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EOF _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ ->
          let MenhirCell0_SEMI (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Val (_menhir_stack, _, _8) = _menhir_stack in
          let MenhirCell0_EQUAL (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_RPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _5) = _menhir_stack in
          let MenhirCell0_COMMA (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _3) = _menhir_stack in
          let MenhirCell0_LPAREN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_LET (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _10 = _v in
          let _v = _menhir_action_36 _1 _10 _3 _5 _8 in
          _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_126 : type  ttv_stack. (((((ttv_stack, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_THEN _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_RBRACE _menhir_cell0_ELSE _menhir_cell0_LBRACE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState126
      | RET _v_3 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState126
      | RBRACE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_LBRACE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_ELSE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_RBRACE (_menhir_stack, _, _) = _menhir_stack in
          let MenhirCell1_Term (_menhir_stack, _, _5) = _menhir_stack in
          let MenhirCell0_LBRACE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell0_THEN (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_Val (_menhir_stack, _, _2) = _menhir_stack in
          let MenhirCell1_IF (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _9 = _v in
          let _v = _menhir_action_38 _1 _2 _5 _9 in
          _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | LPAREN _v_5 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState126
      | LBRACK _v_6 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState126
      | INR _v_7 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState126
      | INL _v_8 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState126
      | ID _v_9 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_9 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_11 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState126
      | FLOATV _v_12 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_12 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_122 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_IF, _menhir_box_body) _menhir_cell1_Val _menhir_cell0_THEN _menhir_cell0_LBRACE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState122
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState122
      | RBRACE _v_4 ->
          let _menhir_stack = MenhirCell1_RBRACE (_menhir_stack, MenhirState122, _v_4) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | ELSE _v_5 ->
              let _menhir_stack = MenhirCell0_ELSE (_menhir_stack, _v_5) in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | LBRACE _v_6 ->
                  let _menhir_stack = MenhirCell0_LBRACE (_menhir_stack, _v_6) in
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | UNIONCASE _v_7 ->
                      _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState125
                  | STRINGV _v_8 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_8 in
                      let _v = _menhir_action_62 _1 in
                      _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState125 _tok
                  | SQRTOP _v_10 ->
                      _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState125
                  | RND _v_11 ->
                      _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState125
                  | RET _v_12 ->
                      _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState125
                  | PROJ2 _v_13 ->
                      _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState125
                  | PROJ1 _v_14 ->
                      _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState125
                  | MULOP _v_15 ->
                      _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState125
                  | LPAREN _v_16 ->
                      _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState125
                  | LET _v_17 ->
                      _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState125
                  | LBRACK _v_18 ->
                      _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState125
                  | INR _v_19 ->
                      _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState125
                  | INL _v_20 ->
                      _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState125
                  | IF _v_21 ->
                      _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_21 MenhirState125
                  | ID _v_22 ->
                      _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_22 MenhirState125
                  | GTOP _v_23 ->
                      _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState125
                  | FUNCTION _v_24 ->
                      _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState125
                  | FUN _v_25 ->
                      _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_25 MenhirState125
                  | FLOATV _v_26 ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _1 = _v_26 in
                      let _v = _menhir_action_63 _1 in
                      _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState125 _tok
                  | EQOP _v_28 ->
                      _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_28 MenhirState125
                  | DIVOP _v_29 ->
                      _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_29 MenhirState125
                  | ADDOP _v_30 ->
                      _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_30 MenhirState125
                  | _ ->
                      _eRR ())
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | LPAREN _v_31 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_31 MenhirState122
      | LBRACK _v_32 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_32 MenhirState122
      | INR _v_33 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_33 MenhirState122
      | INL _v_34 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_34 MenhirState122
      | ID _v_35 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_35 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_37 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_37 MenhirState122
      | FLOATV _v_38 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_38 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_121 : type  ttv_stack. (((((ttv_stack, _menhir_box_body) _menhir_cell1_ID, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_EQUAL, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_SEMI as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState121
      | RET _v_3 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState121
      | LPAREN _v_4 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState121
      | LBRACK _v_5 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState121
      | INR _v_6 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState121
      | INL _v_7 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState121
      | ID _v_8 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState121
      | FLOATV _v_11 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EOF _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ ->
          let MenhirCell1_SEMI (_menhir_stack, _, _) = _menhir_stack in
          let MenhirCell1_Term (_menhir_stack, _, _4) = _menhir_stack in
          let MenhirCell0_EQUAL (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_MaybeType (_menhir_stack, _, _2) = _menhir_stack in
          let MenhirCell1_ID (_menhir_stack, _menhir_s, _1) = _menhir_stack in
          let _6 = _v in
          let _v = _menhir_action_41 _1 _2 _4 _6 in
          _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_119 : type  ttv_stack. (((ttv_stack, _menhir_box_body) _menhir_cell1_ID, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_EQUAL as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | SEMI _v_2 ->
          let _menhir_stack = MenhirCell1_SEMI (_menhir_stack, MenhirState119, _v_2) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_3 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState120
          | STRINGV _v_4 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_4 in
              let _v = _menhir_action_62 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState120 _tok
          | SQRTOP _v_6 ->
              _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState120
          | RND _v_7 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState120
          | RET _v_8 ->
              _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState120
          | PROJ2 _v_9 ->
              _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState120
          | PROJ1 _v_10 ->
              _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState120
          | MULOP _v_11 ->
              _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState120
          | LPAREN _v_12 ->
              _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState120
          | LET _v_13 ->
              _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState120
          | LBRACK _v_14 ->
              _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState120
          | INR _v_15 ->
              _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState120
          | INL _v_16 ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState120
          | IF _v_17 ->
              _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState120
          | ID _v_18 ->
              _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState120
          | GTOP _v_19 ->
              _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState120
          | FUNCTION _v_20 ->
              _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState120
          | FUN _v_21 ->
              _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_21 MenhirState120
          | FLOATV _v_22 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_22 in
              let _v = _menhir_action_63 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState120 _tok
          | EQOP _v_24 ->
              _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_24 MenhirState120
          | DIVOP _v_25 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_25 MenhirState120
          | ADDOP _v_26 ->
              _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_26 MenhirState120
          | _ ->
              _eRR ())
      | RND _v_27 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_27 MenhirState119
      | RET _v_28 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_28 MenhirState119
      | LPAREN _v_29 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_29 MenhirState119
      | LBRACK _v_30 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_30 MenhirState119
      | INR _v_31 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_31 MenhirState119
      | INL _v_32 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_32 MenhirState119
      | ID _v_33 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_33 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_35 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_35 MenhirState119
      | FLOATV _v_36 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_36 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_115 : type  ttv_stack. ((((((ttv_stack, _menhir_box_body) _menhir_cell1_FUNCTION _menhir_cell0_ID, _menhir_box_body) _menhir_cell1_Arguments, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_LBRACE, _menhir_box_body) _menhir_cell1_Term, _menhir_box_body) _menhir_cell1_RBRACE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState115
      | RET _v_3 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState115
      | LPAREN _v_4 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_4 MenhirState115
      | LBRACK _v_5 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState115
      | INR _v_6 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_6 MenhirState115
      | INL _v_7 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_7 MenhirState115
      | ID _v_8 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_8 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_10 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState115
      | FLOATV _v_11 ->
          let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_11 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | EOF _ | PIPE _ | RBRACE _ | RPAREN _ | SEMI _ ->
          let MenhirCell1_RBRACE (_menhir_stack, _, _) = _menhir_stack in
          let MenhirCell1_Term (_menhir_stack, _, _6) = _menhir_stack in
          let MenhirCell0_LBRACE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_MaybeType (_menhir_stack, _, _4) = _menhir_stack in
          let MenhirCell1_Arguments (_menhir_stack, _, _3) = _menhir_stack in
          let MenhirCell0_ID (_menhir_stack, _2) = _menhir_stack in
          let MenhirCell1_FUNCTION (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _8 = _v in
          let _v = _menhir_action_42 _2 _3 _4 _6 _8 in
          _menhir_goto_Term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_113 : type  ttv_stack. ((((ttv_stack, _menhir_box_body) _menhir_cell1_FUNCTION _menhir_cell0_ID, _menhir_box_body) _menhir_cell1_Arguments, _menhir_box_body) _menhir_cell1_MaybeType _menhir_cell0_LBRACE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_body) _menhir_state -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_Term (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | STRINGV _v_0 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_0 in
          let _v = _menhir_action_62 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | RND _v_2 ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_2 MenhirState113
      | RET _v_3 ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_3 MenhirState113
      | RBRACE _v_4 ->
          let _menhir_stack = MenhirCell1_RBRACE (_menhir_stack, MenhirState113, _v_4) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UNIONCASE _v_5 ->
              _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v_5 MenhirState114
          | STRINGV _v_6 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_6 in
              let _v = _menhir_action_62 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState114 _tok
          | SQRTOP _v_8 ->
              _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v_8 MenhirState114
          | RND _v_9 ->
              _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v_9 MenhirState114
          | RET _v_10 ->
              _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v_10 MenhirState114
          | PROJ2 _v_11 ->
              _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v_11 MenhirState114
          | PROJ1 _v_12 ->
              _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v_12 MenhirState114
          | MULOP _v_13 ->
              _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v_13 MenhirState114
          | LPAREN _v_14 ->
              _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v_14 MenhirState114
          | LET _v_15 ->
              _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v_15 MenhirState114
          | LBRACK _v_16 ->
              _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_16 MenhirState114
          | INR _v_17 ->
              _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_17 MenhirState114
          | INL _v_18 ->
              _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_18 MenhirState114
          | IF _v_19 ->
              _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v_19 MenhirState114
          | ID _v_20 ->
              _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v_20 MenhirState114
          | GTOP _v_21 ->
              _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v_21 MenhirState114
          | FUNCTION _v_22 ->
              _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v_22 MenhirState114
          | FUN _v_23 ->
              _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_23 MenhirState114
          | FLOATV _v_24 ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              let _1 = _v_24 in
              let _v = _menhir_action_63 _1 in
              _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState114 _tok
          | EQOP _v_26 ->
              _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v_26 MenhirState114
          | DIVOP _v_27 ->
              _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v_27 MenhirState114
          | ADDOP _v_28 ->
              _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v_28 MenhirState114
          | _ ->
              _eRR ())
      | LPAREN _v_29 ->
          _menhir_run_005 _menhir_stack _menhir_lexbuf _menhir_lexer _v_29 MenhirState113
      | LBRACK _v_30 ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v_30 MenhirState113
      | INR _v_31 ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v_31 MenhirState113
      | INL _v_32 ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v_32 MenhirState113
      | ID _v_33 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_33 in
          let _v = _menhir_action_53 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | FUN _v_35 ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v_35 MenhirState113
      | FLOATV _v_36 ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v_36 in
          let _v = _menhir_action_63 _1 in
          _menhir_run_116 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _eRR ()
  
  let rec _menhir_run_000 : type  ttv_stack. ttv_stack -> _ -> _ -> _menhir_box_body =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UNIONCASE _v ->
          _menhir_run_001 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | STRINGV _v ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v in
          let _v = _menhir_action_62 _1 in
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000 _tok
      | SQRTOP _v ->
          _menhir_run_065 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | RND _v ->
          _menhir_run_003 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | RET _v ->
          _menhir_run_004 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | PROJ2 _v ->
          _menhir_run_068 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | PROJ1 _v ->
          _menhir_run_070 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | MULOP _v ->
          _menhir_run_072 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | LPAREN _v ->
          _menhir_run_074 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | LET _v ->
          _menhir_run_075 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | LBRACK _v ->
          _menhir_run_008 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | INR _v ->
          _menhir_run_009 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | INL _v ->
          _menhir_run_010 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | IF _v ->
          _menhir_run_084 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | ID _v ->
          _menhir_run_088 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | GTOP _v ->
          _menhir_run_093 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | FUNCTION _v ->
          _menhir_run_095 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | FUN _v ->
          _menhir_run_012 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | FLOATV _v ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _1 = _v in
          let _v = _menhir_action_63 _1 in
          _menhir_run_111 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000 _tok
      | EQOP _v ->
          _menhir_run_105 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | DIVOP _v ->
          _menhir_run_107 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | ADDOP _v ->
          _menhir_run_109 _menhir_stack _menhir_lexbuf _menhir_lexer _v MenhirState000
      | _ ->
          _eRR ()
  
end

let body =
  fun _menhir_lexer _menhir_lexbuf ->
    let _menhir_stack = () in
    let MenhirBox_body v = _menhir_run_000 _menhir_stack _menhir_lexbuf _menhir_lexer in
    v
