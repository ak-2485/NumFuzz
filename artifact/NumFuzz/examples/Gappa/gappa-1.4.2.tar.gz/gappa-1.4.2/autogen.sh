#!/bin/sh
touch stamp-config_h.in
autoreconf -i -s
