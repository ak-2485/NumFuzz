Formalization of IEEE-754 Floating-point Numbers in HOL Light
=============================================================

The latest version of this formalization is available at
[https://github.com/skoobit/formal-ieee](https://github.com/skoobit/formal-ieee).

This formalization is not required in the current version of the
FPTaylor certificate verification procedure.